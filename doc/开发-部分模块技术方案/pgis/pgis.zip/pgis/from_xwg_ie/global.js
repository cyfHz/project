var appConfigQueryType="1";//全局查询类型变量
var isSY=false;//是否视野内搜索
var isQuery=false;//是否在查询模式下
var currentLayer=new Array();//当前的查询图层列表
var oldCenterPoint;//缓存中心坐标点
var oldzoomLevel;//缓存上次级别
var oldsyString;//缓存上次视野
var _MapApp=null;
var g_overlay=null;
var g_edit=false;
var mouseX=null;//存放鼠标X轴
var mouseY=null;//存放鼠标Y轴
var newMarkerLayer=new Array();//新增的标注列表
var pageSize = null;//每页显示的数量
var guijiQuery=new Array();//轨迹信息清理