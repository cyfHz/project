//点击右侧的查询结果时，出现的气泡窗的创建的方法
function queryFrameMarkers(mapObject){
	for ( var i = 0; i < mapObject.indexPlaceArray.length; i++) {
		var p = mapObject.indexPlaceArray[i];
		
		var showFiled = "";
		var mc = "";
		var dz = "";
		var obid = "";
		var dh = "";
		var sszzjg = "";//所属组织机构
		var xb = "";//性别
		var sfzh = "";//身份号
		var sbbh = "";//设备编号
		var sfzx = "";//是否在线
		var sfzxch = "";//是否在线中文
		var sfzxdm = "";//是否在线代码
		switch (mapObject.searchType) {
		case dic.mlph: // 门牌号
		{
			mc = p.mphmc;
			dz = "地址:" + p.mpxz;
			obid = p.dzid;
			showFiled = "<div class='queryResult'><p class='queryResultName'>"
					+ mc
					+ "</p>"
					+ "<p class='queryResultAdd'>"
					+ dz
					+ "</p><p class='queryResultBtn'><a href='###' onclick=\"getFwjg(queryFrame.indexPlaceArray["+i+"]);\">浏览</a>&nbsp;&nbsp;&nbsp;<a href='###' onclick=\"updateFwjg(queryFrame.indexPlaceArray["+i+"]);\">修改</a>&nbsp;&nbsp;&nbsp;<a href='###' onclick=\"deleteMlph(queryFrame.indexPlaceArray["+i+"]);\">注销</a></p></div>";
					// + "</p><p class='queryResultBtn'><a href='###'
					// onclick=\"alert('123')\">浏览</a></p></div>";
					mapObject.indeximgmarkersHTML[i] = showFiled;
			mapObject.indeximgMarkers[i] = mapObject.getImgMarker(new Point(p.zbx,
					p.zby), 2, showFiled, i);
			break;
		}
		case dic.jyz: // 加油站
		{
			mc = p.mc;
			dz = "地址:" + p.dz;
			obid = p.dzid;
			showFiled = "<div class='queryResult'><p class='queryResultName'>"
					+ mc
					+ "</p>"
					+ "<p class='queryResultAdd'>"
					+ dz
					//+ "</p><p class='queryResultBtn'><a href='###' onclick=\"\">浏览</a></p></div>";
					// + "</p><p class='queryResultBtn'><a href='###'
					// onclick=\"alert('123')\">浏览</a></p></div>";
					mapObject.indeximgmarkersHTML[i] = showFiled;
			        mapObject.indeximgMarkers[i] = mapObject.getImgMarker(new Point(p.zbx,
					p.zby), 2, showFiled, i);
			break;
		}
		case dic.jydw: // 警员定位
		{
			mc = p.mc;
			sfzxdm = p.sfzx;
			sfzh="公民身份号码："+p.sfzh;
			sszzjg="所属组织机构："+p.sszzjg;
			sbbh="设备编号："+p.sbbh;
			dz = "时间：" + p.gps_time;
			if(p.sfzx == 'zx'){
				sfzxch = '在线';
			}
			if(p.sfzx == 'bzx'){
				sfzxch = '不在线'
			}
			sfzx = "是否在线："+sfzxch;
			showFiled = "<div class='queryResult'><p class='queryResultName'>"
					+ mc
					+ "</p>"
					+ "<p class='queryResultAdd'>"
					+ sfzh
					+ "</p>"
					+ "<p class='queryResultAdd'>"
					+ sfzx
					+ "</p>"
					+ "<p class='queryResultAdd'>"
					+ dz
					+ "</p>"
					+ "<p class='queryResultAdd'>"
					+ sbbh
					+ "</p>"
					+ "<p class='queryResultAdd'>"
					+ sszzjg
					//+ "</p><p class='queryResultBtn'><a href='###' onclick=\"\">浏览</a></p></div>";
					// + "</p><p class='queryResultBtn'><a href='###'
					// onclick=\"alert('123')\">浏览</a></p></div>";
					mapObject.indeximgmarkersHTML[i] = showFiled;
			        mapObject.indeximgMarkers[i] = mapObject.getImgMarker(new Point(p.gps_x,
					p.gps_y), 2, showFiled, i);
			break;
		}
		case dic.jygj: // 警员轨迹
		{
			mc = p.mc;
			sfzh="公民身份号码："+p.sfzh;
			sszzjg="所属组织机构："+p.sszzjg;
			sbbh="设备编号："+p.sbbh;
			dz = "时间：" + p.gps_time;
			
			
			showFiled = "<div class='queryResult'><p class='queryResultName'>"
				+ mc
				+ "</p>"
				+ "<p class='queryResultAdd'>"
				+ sfzh
				+ "</p>"
				+ "<p class='queryResultAdd'>"
				+ dz
				+ "</p>"
				+ "<p class='queryResultAdd'>"
				+ sbbh
				+ "</p>"
				+ "<p class='queryResultAdd'>"
				+ sszzjg
					//+ "</p><p class='queryResultBtn'><a href='###' onclick=\"\">浏览</a></p></div>";
					// + "</p><p class='queryResultBtn'><a href='###'
					// onclick=\"alert('123')\">浏览</a></p></div>";
					mapObject.indeximgmarkersHTML[i] = showFiled;
			         mapObject.indeximgMarkers[i] = mapObject.getImgMarker(new Point(p.gps_x,
							p.gps_y), 2, showFiled, i);
			break;
		}
		case dic.dw: // 单位
		{
			mc = p.mc;
			dz = "地址:" + p.dz;
			obid = p.dzid;
			showFiled = "<div class='queryResult'><p class='queryResultName'>"
					+ mc
					+ "</p>"
					+ "<p class='queryResultAdd'>"
					+ dz
					 
					mapObject.indeximgmarkersHTML[i] = showFiled;
			mapObject.indeximgMarkers[i] = mapObject.getImgMarker(new Point(p.zbx,
					p.zby), 2, showFiled, i);
			break;
		}
		case dic.bw: // 保卫
		{
			mc = p.mc;
			//dz = "地址:" + p.dz;
			obid = p.dzid;
			showFiled = "<div class='queryResult'><p class='queryResultName'>"
					+ mc
					/*+ "</p>"
					+ "<p class='queryResultAdd'>"
					+ dz*/
					 
					mapObject.indeximgmarkersHTML[i] = showFiled;
			mapObject.indeximgMarkers[i] = mapObject.getImgMarker(new Point(p.zbx,
					p.zby), 2, showFiled, i);
			break;
		}
		case dic.jwry: // 境外人员
		{
			mc = p.zwm;
			dz = "地址："+p.dzmc;
			//dz = "地址:" + p.dz;
			obid = p.dzid;
			showFiled = "<div class='queryResult'><p class='queryResultName'>"
					+ mc
					+ "</p>"
					+ "<p class='queryResultAdd'>"
					+ dz
					+ "</p><p class='queryResultBtn'><a href='###' onclick=\"getJwryDetail(queryFrame.indexPlaceArray["+i+"]);\">浏览</a></p></div>";
					mapObject.indeximgmarkersHTML[i] = showFiled;
			mapObject.indeximgMarkers[i] = mapObject.getImgMarker(new Point(p.zbx,
					p.zby), 2, showFiled, i);
			break;
		}
		}

		switch (mapObject.searchType) {
		case "带照片的":
			$(mapObject.tanchuliebiao)
					.append(
							"<li id='_queryResult"
									+ i
									+ "'>"
									+ "<img src='"+urls.msUrl+"/images/icon/"
									+ (i + 1)
									+ ".gif'  width='26' height='27' /><u>"
									+ mc
									+ "</u><br />"
									+ "<span style='font-size:10px;color:#484343;cursor:default;'>"
									+ dz
									+ "</span></li><li ><span style='font-size:10px;color:#484343;cursor:default;'><img src=\""
									+ p.photourl
									+ "\"  alt=\"\" style=\"width: 50px;\"/></span></li>");
			break;
		 case  dic.jydw: // 警员定位
			 if(i<pageSize){
				 $(mapObject.tanchuliebiao)
					.append(
							"<li id='_queryResult"
									+ i
									+ "'>"
									+ "<img src='"+urls.msUrl+"/images/icon/"
									+ (i + 1)
									+ ".gif'  width='26' height='27' /><u>"
									+ mc
									+ "</u><br />"
									+"<span style='font-size:10px;color:#484343;cursor:default;'>"
									+ sfzh
									+ "</span><br />"
									+"<span style='font-size:10px;color:#484343;cursor:default;'>"
									+ dz
									+ "</span><br />"
									+ "<span style='font-size:10px;color:#484343;cursor:default;'>"
									+ sfzx
									+ "</span></li>"); 
			 }
			
			break;
		default:
			$(mapObject.tanchuliebiao)
					.append(
							"<li id='_queryResult"
									+ i
									+ "'>"
									+ "<img src='"+urls.msUrl+"/images/icon/"
									+ (i + 1)
									+ ".gif'  width='26' height='27' /><u>"
									+ mc
									+ "</u><br />"
									+ "<span style='font-size:10px;color:#484343;cursor:default;'>"
									+ dz + "</span></li>");
			break;
		}

		// 注册信息结果栏事件 样式的变动
		if(i<pageSize){
			mapObject.addEventForQueryResult(i);
		}
	}
}