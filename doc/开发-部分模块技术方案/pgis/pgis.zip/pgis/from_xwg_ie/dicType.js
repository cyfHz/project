//查询字典
var dic={	
	mlph:"1",//建筑物
	jyz:"2",//加油站
	dw:"3",//单位
	bw:"4",//保卫
    jwry:"5",//境外人员
    jydw:"6",//警员定位
    jygj:"7"//警员轨迹
};
var url_dic={
 
		mlph:urls.msUrl+"/pgis_bzdzcj/queryMLPHBySY.do",
		jyz:urls.msUrl+"/jyzQyxx/listSY.do",
		dw:urls.msUrl+"/dwxx/listForSY.do",
		bw:urls.msUrl+"/xlffYjctbw/dataList.do",
		jwry:urls.msUrl+"/sySyjwry/queryByListShowInMap.do",
		jydw:urls.msUrl+"/mobileDeviceinfo/listSY.do",
		jygj:urls.msUrl+"/mobileDeviceinfo/listSY_Gj.do"
		
};

var guijiArr=["7"];//此记录需要用到轨迹的查询
var img_dic={ 
		 jydw:urls.msUrl+"/images/icon/jydw.gif",	//警员
		 jygj:urls.msUrl+"/images/icon/jydw.gif",	//警员轨迹
		 jygjbzx:urls.msUrl+"/images/icon/jydwbzx.gif", //警员定位不在线
		 qtjy:urls.msUrl+"/images/icon/min_mark_red.gif" //不在分页上的警员
};
var cityPGIS={
		jinan:"3701", 
		weihai:"3702"
}