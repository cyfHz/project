﻿
//门楼牌地址 
mlphModel = function () {
    this.dzid = null; //地址主键
    this.mphdm = null;//编码
    this.mphmc = null;//街路项+门牌号
    this.mpxz = null;//详细地址
    this.mph = null;//门牌号
    this.zbx = null;//坐标x
    this.zby = null;//坐标y
    this.jzwmc = null;//建筑物名称
    this.url=null;//链接
}




//加油站
jyzModel = function () {

    this.id = null; //主键
    this.mc = null;//加油站名称
    this.dz = null;//加油站地址
    this.zbx = null;//坐标x
    this.zby = null;//坐标y
    this.url=null;//链接
}

//警员定位
jydwModel = function () {
	 this.mc = null;//警员姓名
    this.gps_x = null;//坐标x
    this.gps_y = null;//坐标y
    this.gps_time = null;//定位时间
    this.sszzjg = null;//所属组织机构
    this.xb = null;//性别
    this.sfzh = null;//身份号
    this.sbbh = null;//设备编号
    this.sfzx = null;//是否在线
    this.sfdqy = null;//是否在当前页显示
}
//警员轨迹
jygjModel = function () {

	 this.mc = null;//警员姓名
	 this.gps_x = null;//坐标x
	 this.gps_y = null;//坐标y
	 this.gps_time = null;//定位时间
	 this.sszzjg = null;//所属组织机构
	 this.xb = null;//性别
	 this.sfzh = null;//身份号
	 this.sbbh = null;//设备编号
    
}

dwModel=function()

{
	this.id=null;//主键
	this.dwbh=null;//单位编码
	this.mc=null;//单位名称
	this.dz=null;//单位地址
	 this.zbx = null;//坐标x
	 this.zby = null;//坐标y
	}
bwModel=function()

{
	 this.id=null;//主键
	 this.mc=null;//单位名称
	 this.dz=null;//单位地址
	 this.zbx = null;//坐标x
	 this.zby = null;//坐标y
	}
jwryModel=function()
{
	 this.id=null;//主键
	 this.ywm=null;//英文名
	 this.zwm=null;//中文名
	 this.dzmc=null;//地址名称
	 this.gj=null;//国籍
	 this.zbx = null;//坐标x
	 this.zby = null;//坐标y
	}

/********************Model List End******************/
