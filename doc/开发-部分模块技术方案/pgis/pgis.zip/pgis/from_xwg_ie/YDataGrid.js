var YDataGrid = function(config) {
	config = config || {};
	var dataGrid = config.dataGrid || {}
	var treeGrid = config.treeGrid || {}
	// Actions
	var actionUrl = config.action || {}
	var Action = {
		'save' : actionUrl.save || 'save.do',
		'getIdForEdit' : actionUrl.getIdForEdit || 'getId.do',
		'getId' : actionUrl.getId || 'getId.do',
		'remove' : actionUrl.remove || 'delete.do',
		'getAuthorize' : actionUrl.getAuthorize || 'getAuthorize.do',
		'dataAuthorize' : actionUrl.dataAuthorize || 'dataAuthorize.do',
		'goAdd' : actionUrl.goAdd || 'goAdd.do'
	}

	// Grid DataList
	var Grid = $('#data-list');
	// Form
	var Form = {
		search : $("#searchForm"),
		edit : $("#editForm"),
		detail : $("#detailForm"),
		widauth : $("#authorizeForm"),
		dataauthorize : $("#dataAuthorizeForm"),
		funauth : $("#funAuthForm"),
		appfunauth : $("#appfunForm"),
		appwidauth : $("#appwidForm")
	}
	// Win 窗口
	var Win = {
		edit : $("#edit-win")
	}
	// 查看明细窗口
	var detailWin = {
		detail : $("#detail-win")
	}
	// 查看功能控件授权窗口
	// var authorizeWin = {authorize:$("#authorize-win")}
	var adminAuthWidWin = {
		widauth : $("#authorize-win")
	}
	// 数据授权窗口
	var dataAuthorizeWin = {
		dataauthorize : $("#dataauthorize-win")
	}
	// 功能授权窗口
	var funauthWin = {
		funauth : $("#funauth-win")
	}
	// 应用功能树
	var appfunWin = {
		appfunauth : $("#appfunauth-win")
	}
	// 应用控件授权页面
	var appwidWin = {
		appwidauth : $("#appwidauth-win")
	}
	// 应用角色功能授权页面
	var approlefunWin = {
		approlefun : $("#approlefun-win")
	}
	// 应用角色控件授权页面
	var approlewidWin = {
		approlewid : $("#approlewid-win")
	}
	// 应用角色数据授权页面
	var approledataWin = {
		approledata : $("#approledata-win")
	}
	// 处理函数
	var Handler = {
		// serach 查询事件
		search : function(callback) {
			Events.refresh();
			// 回调函数
			if (jQuery.isFunction(callback)) {
				callback();
			}
			return false;
		},
		// add按钮事件
		add : function(callback) {
			sdwangge.progress();
			var data = {};
			sdwangge.getById(Action.goAdd, data, function(result) {
				sdwangge.closeProgress();
				Form.edit.form('load', result.data);
				// alert("0 "+result.data[0].area_name);
				// alert("01 "+result.data[0].appAreaList);
				// alert("02 "+result.data.appAreaList);
				// alert("03 "+result.data);
				// alert("04 "+result.data.bean);
				Form.edit.show();
				Win.edit.dialog('open');
				Form.edit.resetForm();
				if (Tools.addCallback) {
					// alert("1"+result.data);
					var flag = "add";
					Tools.addCallback(result.data, flag);
				}
				// 回调函数
				if (jQuery.isFunction(callback)) {
					callback(result);
				}
			});

		},
		// edit 按钮事件
		edit : function(callback) {
			var record = Utils.getCheckedRows();
			if (Utils.checkSelectOne(record)) {
				sdwangge.progress();
				var data = {};
				var idKey = dataGrid.idField || 'id'; // 主键名称
				data[idKey] = (record[0][idKey]);
				// alert(data);
				sdwangge.getById(Action.getIdForEdit, data, function(result) {
					sdwangge.closeProgress();
					Form.edit.form('load', result.data);
					Form.edit.show();
					Win.edit.dialog('open');
					if (Tools.addCallback) {
						// alert("1"+result.data);
						var flag = "edit";
						Tools.addCallback(result.data, flag);
					}
					// 回调函数
					if (jQuery.isFunction(callback)) {
						callback(result);
					}
				});
			}
		},
		// detail 按钮事件//查看明细事件
		detail : function(callback) {
			var record = Utils.getCheckedRows();
			if (Utils.checkSelectOne(record)) {
				sdwangge.progress();
				var data = {};
				var idKey = dataGrid.idField || 'id'; // 主键名称
				data[idKey] = (record[0][idKey]);

				sdwangge.getById(Action.getId, data, function(result) {
					sdwangge.closeProgress();
					Form.detail.form('load', result.data);// 要将这里的result.data传到页面
					Form.detail.show();
					detailWin.detail.dialog('open');
					if (Tools.detailCallback) {
						Tools.detailCallback(result.data);
					}

					// 回调函数
					if (jQuery.isFunction(callback)) {

						callback(result);
					}
				});
			}
		},
		// 管理员功能授权
		funauth : function(callback) {
			var oldFunAuth = [];
			var record = Utils.getCheckedRows();
			if (Utils.checkSelectOne(record)) {
				sdwangge.progress();
				var data = {};
				var idKey = dataGrid.idField || 'id'; // 主键名称
				data[idKey] = (record[0][idKey]);
				var admin_id = record[0][idKey];
				$("#admin_id").val(admin_id);
				sdwangge
						.getById(
								Action.getId,
								data,
								function(result) {
									sdwangge.closeProgress();
									Form.funauth.form('load', result.data);
									$('#funmenu-tree')
											.tree(
													{
														checkbox : true,
														url : '../adminResource/getTreeJson.do',
														onLoadSuccess : function() {
															var id = $(
																	"#user_id")
																	.val();
															// 绑定权限
															$
																	.ajax({
																		url : 'getFunAuth.do?id='
																				+ admin_id,
																		cache : false,
																		dataType : 'json',
																		success : function f(
																				data) {
																			for (var b = 0; b < data.length; b++) {
																				var c = data[b];
																				if (c.id != undefined) {
																					oldFunAuth
																							.push(c.id
																									.substring(
																											5,
																											c.id.length));
																					var node = $(
																							'#funmenu-tree')
																							.tree(
																									'find',
																									c.id);
																					if (node != null) {
																						$(
																								'#funmenu-tree')
																								.tree(
																										'check',
																										node.target);
																					}
																				}
																			}
																		}
																	})
														}
													});
									funauthWin.funauth.dialog('open');
									// 回调函数
									if (jQuery.isFunction(callback)) {
										callback(result);
									}
								});
			}

		},

		// 管理员控件授权事件
		widauth : function(callback) {

			var oldWidAuth = [];
			var record = Utils.getCheckedRows();
			if (Utils.checkSelectOne(record)) {
				sdwangge.progress();
				var data = {};
				var idKey = dataGrid.idField || 'id'; // 主键名称
				var admin_id = record[0][idKey];
				data[idKey] = (record[0][idKey]);
				sdwangge
						.getById(
								Action.getId,
								data,
								function(result) {
									sdwangge.closeProgress();
									// alert(admin_id+"aaa")
									Form.widauth.form('load', result.data);
									var id = $("#admin_id").val();
									// alert(id+"bbb");
									$('#menu-tree')
											.tree(
													{
														checkbox : true,
														url : '../adminResource/getFunAuthMenuTree.do?id='
																+ admin_id,
														onLoadSuccess : function() {
															var id = $(
																	"#admin_id")
																	.val();
															// 绑定权限
															$
																	.ajax({
																		url : 'getAuthorize.do?admin_id='
																				+ id,
																		cache : false,
																		dataType : 'json',
																		success : function f(
																				data) {
																			// var
																			// nodes
																			// =
																			// $('#menu-tree').tree('getChecked',
																			// 'unchecked');

																			for (var b = 0; b < data.length; b++) {
																				var c = data[b];
																				// alert("idd:"+c.id);
																				if (c.id != undefined) {
																					// oldWidAuth.push(c.id.substring(4,c.id.length));
																					var node = $(
																							'#menu-tree')
																							.tree(
																									'find',
																									c.id);
																					if (node != null) {
																						$(
																								'#menu-tree')
																								.tree(
																										'check',
																										node.target);
																					}
																				}
																			}
																		}
																	})
														}
													});
									adminAuthWidWin.widauth.dialog('open');
									// 回调函数
									if (jQuery.isFunction(callback)) {
										callback(result);
									}
								});
			}
			//			
		},
		// 数据授权事件

		dataauthorize : function(callback) {
			$("#ifrm1").attr("src", "");
			$('#menudg').datagrid('reload');
			var record = Utils.getCheckedRows();

			if (Utils.checkSelectOne(record)) {
				var data = {};
				var idKey = dataGrid.idField || 'id'; // 主键名称
				var user_id = record[0][idKey];
				$("#user_id").val(user_id);
				data[idKey] = (record[0][idKey]);
				dataAuthorizeWin.dataauthorize.dialog('open');

			}
		},
		// 应用功能树
		appfunauth : function(callback) {
			var record = Utils.getCheckedRows();
			if (Utils.checkSelectOne(record)) {
				var data = {};
				var idKey = dataGrid.idField || 'id'; // 主键名称
				var user_id = record[0][idKey];
				$("#user_id").val(user_id);
				data[idKey] = (record[0][idKey]);
				appfunWin.appfunauth.dialog('open');
				$('#menu-tree').tree({
					checkbox : true,
					url : '../appResource/getAppMenuTree.do',
					onLoadSuccess : function() {
						var id = $("#user_id").val();

					}
				});

			}
		},
		// 应用控件授权
		appwidauth : function(callback) {
			var record = Utils.getCheckedRows();
			if (Utils.checkSelectOne(record)) {
				var data = {};
				var idKey = dataGrid.idField || 'id'; // 主键名称
				var areaKey = dataGrid.idField || 'area_id'
				var res_id = record[0][idKey];
				var area_id = record[0][areaKey];
				data[idKey] = (record[0][idKey]);
				appwidWin.appwidauth.dialog('open');
				var url = '../appWidgetrule/list.do?res_id=' + res_id
						+ '&area_id=' + area_id;
				// alert("地址是："+url);
				$("#ifrm1").attr("src", url);
			}
		},
	/*	// 应用角色授权
		approleauth : function(callback) {
			var record = Utils.getCheckedRows();
			if (Utils.checkSelectOne(record)) {
				var idKey = dataGrid.idField || 'id'; // 主键名称
				var res_id = record[0][idKey];
				approleWin.approleauth.dialog('open');
				var url = '../appRole/approlelist.do?res_id=' + res_id
				// alert("地址是："+url);
				$("#ifrmrole").attr("src", url);
				// $("#user_id").val(user_id);`
			}

		},*/
		// 应用用户应用角色授权
		appuser_approleauth : function(callback) {
			var record = Utils.getCheckedRows();
			if (Utils.checkSelectOne(record)) {
				var idKey = dataGrid.idField || 'id'; // 主键名称
				var res_id = record[0][idKey];
				appuser_approleWin.approleauth.dialog('open');
				var url = 'appuser_approlelist.do?appuser_id=' + res_id
				// alert("地址是："+url);
				$("#ifrmrole").attr("src", url);
				// $("#user_id").val(user_id);`
			}

		},
		// 应用角色功能授权
		approlefun : function(callback) {
			// alert("功能授权dialog")
			var record = Utils.getCheckedRows();
			if (Utils.checkSelectOne(record)) {
				var idKey = dataGrid.idField || 'id'; // 主键名称
				var role_id = record[0][idKey];
				$("#role_id").val(role_id);
				// approlefunWin.approlefun.dialog('open');
				OpenDialog('角色功能授权', 'RoleForResourceAuth.do?role_id='
						+ role_id);
				/*
				 * $('#appfun-tree').tree({ checkbox:true,
				 * url:'../appResource/getAppFunParentAuth.do?role_id='+role_id,
				 * onLoadSuccess:function(){
				 * oldParentFun=$('#appfun-tree').tree('getChecked');
				 * //alert(oldParentFun); //alert("role_id的值是："+role_id); //绑定权限
				 * 
				 * $.ajax({
				 * url:'../appResource/appRoleFunAuth.do?role_id='+role_id,
				 * cache:false, dataType:'json', success:function f(data){
				 * for(var b=0;b<data.length;b++){ var c=data[b];
				 * //alert("ssss"+c.id); var node =
				 * $('#appfun-tree').tree('find',c.id); if(node!=null){
				 * $('#appfun-tree').tree('check',node.target); } } } }) } });
				 */
			}
			// 回调函数
			if (callback && jQuery.isFunction(callback)) {
				callback(result);
			}

		},
		// 应用角色控件授权
		approlewid : function(callback) {
			var record = Utils.getCheckedRows();
			if (Utils.checkSelectOne(record)) {
			var idKey = dataGrid.idField || 'id'; // 主键名称
			var role_id = record[0][idKey];
			$("#role_id").val(role_id);
			// approlefunWin.approlefun.dialog('open');
			OpenDialog('角色功能授权', 'WidForResourceAuth.do?role_id='
					+ role_id);
			/*
				// alert("role_id是："+role_id);
				/*$("#role_id").val(role_id);
				approlewidWin.approlewid.dialog('open');
				$('#widmenu-tree')
						.tree(
								{
									checkbox : true,
									url : '../appResource/appRoleWidTree.do?role_id='
											+ role_id,
									onLoadSuccess : function() {
										$
												.ajax({
													url : '../appWidgetrule/queryWidByRoleId.do?role_id='
															+ role_id,
													cache : false,
													dataType : 'json',
													success : function f(data) {
														for (var b = 0; b < data.length; b++) {
															var c = data[b];
															// alert("wid"+c.id);
															if (c.id != undefined) {
																var node = $(
																		'#widmenu-tree')
																		.tree(
																				'find',
																				c.id);
																if (node != null) {
																	$(
																			'#widmenu-tree')
																			.tree(
																					'check',
																					node.target);
																}
															}
														}
													}
												});
									}
								});*/
			}

		},
		/*// 应用角色数据授权
		approleuser : function(callback) {

			var record = Utils.getCheckedRows();
			if (Utils.checkSelectOne(record)) {
				var idKey = dataGrid.idField || 'id'; // 主键名称
				var role_id = record[0][idKey];
				// alert(role_id);
				approleuserWin.approleuser.dialog('open');
				$('#menudg').datagrid('clearSelections');
				$('#menudg').datagrid('clearChecked');
				$.ajax({
					type : "post",
					url : '../appRoleUser/queryUserByRoleId.do',
					data : {
						role_id : role_id
					},
					cache : false,
					async : false,
					dataType : 'json',
					success : function f(data) {
						// alert(data.length);
						for (var b = 0; b < data.data.length; b++) {
							var c = data.data[b];
							var index = $('#menudg').datagrid('getRowIndex',
									c.appuser_id);
							$('#menudg').datagrid('checkRow', index);
						}
						// $.messager.alert('My Title','成功','info');
					},
					error : function() {
						$.messager.alert('My Title', '失败', 'error');
					}

				});
				// var url='../appRole/approlelist.do?res_id='+res_id
				// alert("地址是："+url);
				// $("#ifrmrole").attr("src",url);
				// $("#user_id").val(user_id);`
			}

		},*/
		/*resetpwd : function(callback) {
			var record = Utils.getCheckedRows();
			if (Utils.checkSelectOne(record)) {
				var idKey = dataGrid.idField || 'id'; // 主键名称
				var admin_id = record[0][idKey];
				approleuserWin.approleuser.dialog('open');
				$.ajax({
					url : '../adminUser/initPwd.do?admin_id=' + admin_id,
					cache : false,
					async : false,
					dataType : 'json',
					success : function f(data) {
						$.messager.alert('My Title', '初始化密码成功', 'info');
					},
					error : function() {
						$.messager.alert('My Title', '初始化密码失败', 'error');
					}

				});
			}
		},
*/
		// 刷新Grid 数据
		refresh : function(callback) {
			if (!valiForm()) {
				return;
			}
			if (Form.search.form('validate')) {
			var param = Form.search.serializeObject();
			Grid.datagrid('load', param);
			}
			// 回调函数
			if (jQuery.isFunction(callback)) {
				callback();
			}
		},
		// 删除记录
		remove : function(callback) {
			var records = Utils.getCheckedRows();
			if (Utils.checkSelect(records)) {
				$.messager.confirm('确认', '确认删除记录?', function(r) {
					if (r) {
						sdwangge.progress();
						var arr = [], idKey = dataGrid.idField || 'id'; // 主键名称
						$.each(records, function(i, record) {
							arr.push('id=' + record[idKey]);
						});
						var data = arr.join("&");
						sdwangge.deleteForm(Action.remove, data, function(
								result) {
							sdwangge.closeProgress();
							Events.refresh();
							// 回调函数
							if (jQuery.isFunction(callback)) {
								callback(result);
							}
						});
					}
				});
			}
		},// 保存调用方法
		save : function(callback) {
			if (!valiForm()) {
				return;
			}
			if (Form.edit.form('validate')) {
				sdwangge.progress();
				Form.edit.attr('action', Action.save);
				var parentId = $('#search_parentId').val();
				$("#edit_parentId").val(parentId)
				sdwangge.saveForm(Form.edit, function(data) {
					sdwangge.closeProgress();
					Win.edit.dialog('close');
					$(".validatebox-tip").remove();
					if (Tools.saveCallbackBeforRefresh) {
						Tools.saveCallbackBeforRefresh(data);
					}
					Events.refresh();
					Form.edit.resetForm();
					// 回调函数
					if (jQuery.isFunction(callback)) {
						callback(data);
					}
					if (Tools.saveCallback) {
						Tools.saveCallback(data);
					}
				});
			}
		},
		// 关闭按钮事件
		close : function(callback) {
			$.messager.confirm('提示', '您确定要取消编辑?', function(r) {
				if (r) {
					$(".gips-container").css({
						"display" : "none"
					});
					Win.edit.dialog('close');
					$(".validatebox-tip").remove();
					// 回调函数
					if (jQuery.isFunction(callback)) {
						callback(data);
					}
				}
			});
		},
		// 详细页关闭按钮事件
		detailclose : function(callback) {
			detailWin.detail.dialog('close');
			$(".validatebox-tip").remove();
			// 回调函数
			if (jQuery.isFunction(callback)) {
				callback(data);
			}
		}
	}
	var Tools = config.tools || {};
	// Grid 工具类
	var Utils = {
		getCheckedRows : function() {
			return Grid.datagrid('getChecked');
		},
		checkSelect : function(rows) {// 检查grid是否有勾选的行, 有返回 true,没有返回true
			var records = rows;
			if (records && records.length > 0) {
				return true;
			}
			sdwangge.alert('警告', '未选中记录.', 'warning');
			return false;

		},
		checkSelectOne : function(rows) {// 检查grid是否只勾选了一行,是返回 true,否返回true
			var records = rows;
			if (!Utils.checkSelect(records)) {
				return false;
			}
			if (records.length == 1) {
				return true;
			}
			sdwangge.alert('警告', '只能选择一行记录.', 'warning');
			return false;
		}
	}

	// 自定义事件
	var evt = config.event || {};

	// 默认事件
	var Events = {
		// serach 查询事件
		search : evt.search || Handler.search,
		// add按钮事件
		add : evt.add || Handler.add,
		// edit 按钮事件
		edit : evt.edit || Handler.edit,
		// detail 按钮事件
		detail : evt.detail || Handler.detail,
		// funauh 管理员功能授权按钮事件
		funauth : evt.funauth || Handler.funauth,
		// widauth 管理员功能授权按钮事件
		widauth : evt.widauth || Handler.widauth,
		// 管理员功能授权按钮事件按钮事件
		dataauthorize : evt.dataauthorize || Handler.dataauthorize,
		// resetpassword 管理员重置密码事件
		resetpwd : evt.resetpwd || Handler.resetpwd,
		// appfunauth应用资源功能树
		appfunauth : evt.appfunauth || Handler.appfunauth,
		// appwidauth应用资源控件授权
		appwidauth : evt.appwidauth || Handler.appwidauth,
		// approleauth应用资源角色授权
		approleauth : evt.approleauth || Handler.approleauth,
		// appuser_approleauth 应用用户中应用角色授权
		appuser_approleauth : evt.appuser_approleauth
				|| Handler.appuser_approleauth,
		// 应用角色功能授权
		approlefun : evt.approlefun || Handler.approlefun,
		// 应用角色控件授权
		approlewid : evt.approlewid || Handler.approlewid,
		// 应用角色数据授权
		approledata : evt.approledata || Handler.approledata,
		// 刷新Grid 数据
		refresh : evt.refresh || Handler.refresh,
		// 删除记录
		remove : evt.remove || Handler.remove,
		// 保存调用方法
		save : evt.save || Handler.save,
		// 关闭按钮事件
		close : evt.close || Handler.close,
		// 详细界面关闭按钮事件
		detailclose : evt.detailclose || Handler.detailclose
	}

	// 按钮控制 btnType 用来控制按钮是否显示,后台根据授权控制是否显示
	var bar_add = {
		id : 'btnadd',
		text : 'Add',
		iconCls : 'icon-add',
		btnType : 'add',
		handler : Events.add
	};
	var bar_edit = {
		id : 'btnedit',
		text : 'Edit',
		iconCls : 'icon-edit',
		btnType : 'edit',
		handler : Events.edit
	};
	var bar_remove = {
		id : 'btnremove',
		text : 'Remove',
		iconCls : 'icon-remove',
		btnType : 'remove',
		handler : Events.remove
	};
	var bar_detail = {
		id : 'btn',
		text : 'Detail',
		iconCls : 'icon-detail',
		btnType : 'detail',
		handler : Events.detail
	};
	var bar_funauth = {
		id : 'btnfunauth',
		text : 'FunAuth',
		iconCls : 'icon-function',
		btnType : 'funauth',
		handler : Events.funauth
	};
	var bar_widauth = {
		id : 'btnwidauth',
		text : 'Detail',
		iconCls : 'icon-widget',
		btnType : 'widauth',
		handler : Events.widauth
	};
	var bar_dataauthorize = {
		id : 'btndataauthorize',
		text : 'DataAuthorize',
		iconCls : 'icon-data',
		btnType : 'dataauthorize',
		handler : Events.dataauthorize
	};
	var bar_resetpwd = {
		id : 'btnresetpwd',
		text : 'ResetPwd',
		iconCls : 'icon-password',
		btnType : 'resetpwd',
		handler : Events.resetpwd
	};
	var bar_appfunauth = {
		id : 'btnappfunauth',
		text : 'AppFunAuth',
		iconCls : 'icon-function',
		btnType : 'appfunauth',
		handler : Events.appfunauth
	};
	var bar_appwidauth = {
		id : 'btnappwidauth',
		text : 'AppWidAuth',
		iconCls : 'icon-widget',
		btnType : 'appwidauth',
		handler : Events.appwidauth
	};
	var bar_approleauth = {
		id : 'btnapproleauth',
		text : 'AppRoleAuth',
		iconCls : 'icon-data',
		btnType : 'approleauth',
		handler : Events.approleauth
	};
	var bar_appuser_approleauth = {
		id : 'btnappuser_approleauth',
		text : 'AppUserAppRoleAuth',
		iconCls : 'icon-data',
		btnType : 'appuser_approleauth',
		handler : Events.appuser_approleauth
	};
	var bar_userauth = {
		id : 'btnuserauth',
		text : 'UserAuth',
		iconCls : 'icon-user',
		btnType : 'userauth',
		handler : Events.userauth
	};
	var bar_approlefun = {
		id : 'btnapprolefun',
		text : 'AppRoleFun',
		iconCls : 'icon-function',
		btnType : 'approlefun',
		handler : Events.approlefun
	};
	var bar_approlewid = {
		id : 'btnapprolewid',
		text : 'AppRoleWid',
		iconCls : 'icon-edit',
		btnType : 'approlewid',
		handler : Events.approlewid
	};
	var bar_approledata = {
		id : 'btnapproledata',
		text : 'AppRoleData',
		iconCls : 'icon-data',
		btnType : 'approledata',
		handler : Events.approledata
	};
	var toolbarConfig = [ bar_add, bar_edit, bar_remove, bar_detail,
			bar_funauth, bar_widauth, bar_dataauthorize, bar_resetpwd,
			bar_appfunauth, bar_appwidauth, bar_approleauth,
			bar_appuser_approleauth, bar_approlefun,
			bar_approlewid, bar_approledata ];
	var getToolbar = function() {
		var tbars = [];
		if (dataGrid.toolbar != undefined && dataGrid.toolbar.length > 0) {
			for (var i = 0; i < dataGrid.toolbar.length; i++) {
				var bar = dataGrid.toolbar[i];
				if (!bar) {
					continue;
				}
				if (bar.btnType == 'add') {
					tbars.push({
						id : bar.id || bar_add.id,
						text : bar.text || bar_add.text,
						iconCls : bar.iconCls || bar_add.iconCls,
						btnType : bar.btnType || bar_add.btnType,
						handler : bar.handler || bar_add.handler
					});
					continue;
				}
				if (bar.btnType == 'edit') {
					tbars.push({
						id : bar.id || bar_edit.id,
						text : bar.text || bar_edit.text,
						iconCls : bar.iconCls || bar_edit.iconCls,
						btnType : bar.btnType || bar_edit.btnType,
						handler : bar.handler || bar_edit.handler
					});
					continue;
				}
				/*if (bar.btnType == 'edit') {
					tbars.push({
						id : bar.id || bar_edit.id,
						text : bar.text || bar_edit.text,
						iconCls : bar.iconCls || bar_edit.iconCls,
						btnType : bar.btnType || bar_edit.btnType,
						handler : bar.handler || bar_edit.handler
					});
					continue;
				}*/
				if (bar.btnType == 'remove') {
					tbars.push({
						id : bar.id || bar_remove.id,
						text : bar.text || bar_remove.text,
						iconCls : bar.iconCls || bar_remove.iconCls,
						btnType : bar.btnType || bar_remove.btnType,
						handler : bar.handler || bar_remove.handler
					});
					continue;
				}
				if (bar.btnType == 'detail') {
					tbars.push({
						id : bar.id || bar_detail.id,
						text : bar.text || bar_detail.text,
						iconCls : bar.iconCls || bar_detail.iconCls,
						btnType : bar.btnType || bar_detail.btnType,
						handler : bar.handler || bar_detail.handler
					});
					continue;
				}
				if (bar.btnType == 'funauth') {
					tbars.push({
						id : bar.id || bar_funauth.id,
						text : bar.text || bar_funauth.text,
						iconCls : bar.iconCls || bar_funauth.iconCls,
						btnType : bar.btnType || bar_funauth.btnType,
						handler : bar.handler || bar_funauth.handler
					});
					continue;
				}
				if (bar.btnType == 'widauth') {
					tbars.push({
						id : bar.id || bar_widauth.id,
						text : bar.text || bar_widauth.text,
						iconCls : bar.iconCls || bar_widauth.iconCls,
						btnType : bar.btnType || bar_widauth.btnType,
						handler : bar.handler || bar_widauth.handler
					});
					continue;
				}
				if (bar.btnType == 'dataauthorize') {
					tbars.push({
						id : bar.id || bar_.id,
						text : bar.text || bar_dataauthorize.text,
						iconCls : bar.iconCls || bar_dataauthorize.iconCls,
						btnType : bar.btnType || bar_dataauthorize.btnType,
						handler : bar.handler || bar_dataauthorize.handler
					});
					continue;
				}
				if (bar.btnType == 'resetpwd') {
					tbars.push({
						id : bar.id || bar_.id,
						text : bar.text || bar_resetpwd.text,
						iconCls : bar.iconCls || bar_resetpwd.iconCls,
						btnType : bar.btnType || bar_resetpwd.btnType,
						handler : bar.handler || bar_resetpwd.handler
					});
					continue;
				}
				if (bar.btnType == 'appfunauth') {
					tbars.push({
						id : bar.id || bar_.id,
						text : bar.text || bar_appfunauth.text,
						iconCls : bar.iconCls || bar_appfunauth.iconCls,
						btnType : bar.btnType || bar_appfunauth.btnType,
						handler : bar.handler || bar_appfunauth.handler
					});
					continue;
				}
				if (bar.btnType == 'appwidauth') {
					tbars.push({
						id : bar.id || bar_.id,
						text : bar.text || bar_appwidauth.text,
						iconCls : bar.iconCls || bar_appwidauth.iconCls,
						btnType : bar.btnType || bar_appwidauth.btnType,
						handler : bar.handler || bar_appwidauth.handler
					});
					continue;
				}
				if (bar.btnType == 'approleauth') {
					tbars.push({
						id : bar.id || bar_.id,
						text : bar.text || bar_approleauth.text,
						iconCls : bar.iconCls || bar_approleauth.iconCls,
						btnType : bar.btnType || bar_approleauth.btnType,
						handler : bar.handler || bar_approleauth.handler
					});
					continue;
				}
				if (bar.btnType == 'appuser_approleauth') {
					tbars.push({
						id : bar.id || bar_.id,
						text : bar.text || bar_appuser_approleauth.text,
						iconCls : bar.iconCls
								|| bar_appuser_approleauth.iconCls,
						btnType : bar.btnType
								|| bar_appuser_approleauth.btnType,
						handler : bar.handler
								|| bar_appuser_approleauth.handler
					});
					continue;
				}
				if (bar.btnType == 'approlefun') {
					tbars.push({
						id : bar.id || bar_.id,
						text : bar.text || bar_approlefun.text,
						iconCls : bar.iconCls || bar_approlefun.iconCls,
						btnType : bar.btnType || bar_approlefun.btnType,
						handler : bar.handler || bar_approlefun.handler
					});
					continue;
				}
				if (bar.btnType == 'approlewid') {
					tbars.push({
						id : bar.id || bar_.id,
						text : bar.text || bar_approlewid.text,
						iconCls : bar.iconCls || bar_approlewid.iconCls,
						btnType : bar.btnType || bar_approlewid.btnType,
						handler : bar.handler || bar_approlewid.handler
					});
					continue;
				}
				if (bar.btnType == 'approledata') {
					tbars.push({
						id : bar.id || bar_.id,
						text : bar.text || bar_approledata.text,
						iconCls : bar.iconCls || bar_approledata.iconCls,
						btnType : bar.btnType || bar_approledata.btnType,
						handler : bar.handler || bar_approledata.handler
					});
					continue;
				}
				tbars.push({
					id : bar.id,
					text : bar.text,
					iconCls : bar.iconCls,
					btnType : bar.btnType,
					handler : bar.handler,
					disabled : bar.disabled
				});
			}
		} else {
			tbars = toolbarConfig;
		}
		return tbars;
	}

	// 初始化表格
	var initGrid = function() {
		var config = {
			toolbar : dataGrid.toolbar,
			title : dataGrid.title || 'Data List',
			iconCls : dataGrid.iconCls || 'icon-save',
			fit : true,
			// height: dataGrid.height || 365,
			border : false,
			nowrap : true,
			autoRowHeight : false,
			striped : false,
			collapsible : false,
			remoteSort : false,
			pagination : dataGrid.pagination || true,
			rownumbers : true,
			singleSelect : dataGrid.singleSelect || false,
			checkOnSelect : dataGrid.checkOnSelect || false,
			selectOnCheck : dataGrid.selectOnCheck || false,
			url : dataGrid.url,
			method : dataGrid.method || 'post',
			loadMsg : dataGrid.loadMsg || 'Loading in ...',
			idField : dataGrid.idField,
			columns : dataGrid.columns,
			// toolbar: getToolbar(),
			onLoadSuccess : dataGrid.onLoadSuccess || function() {
				Grid.datagrid('unselectAll');
				Grid.datagrid('uncheckAll');
				Grid.datagrid("fixRownumber");
			},
			onSelect : dataGrid.onSelect || function(rowIndex, rowData) {
				// 选择一行
				var rows = Grid.datagrid('getRows');
				$.each(rows, function(i) {
					if (i != rowIndex) {
						Grid.datagrid('uncheckRow', i);
						Grid.datagrid('unselectRow', i);
					}
				})
				Grid.datagrid('checkRow', rowIndex);
			}
		};
		Grid.datagrid(config);
	}
	// 初始化Grid按钮 按钮控制
	var initTbar = function(callback) {
		var tbars = getToolbar();
		dataGrid.toolbar = tbars;
		var _url = urls['msUrl'] + '/getActionBtn.do';
		if(_url.indexOf("//getActionBtn.do")==-1){
			_url=_url.replace("//getActionBtn.do","/getActionBtn.do");
		}
		var data = {
			'url' : window.location.href
		};

		// 查询页面授权的btnType
		sdwangge.ajaxJson(_url, data, function(data) {
			if (data.success) {
				if (!data.allType) {
					/*Grid.datagrid({
					'toolbar' : tbars
					});*/
					dataGrid.toolbar=tbars;
				} else {
					var newBars = [];
					var a=data.types;
					var authwid=[];
					var allwid=[];
					for(var i=0;i<data.types.length;i++){
						authwid.push(data.types[i].rule_name);
					}
					for(var j=0;j<tbars.length;j++){
						allwid.push(tbars[j].text);
					}
					  var newauthwid=[];
					  for(var s in authwid){
					    for(var x in tbars){
					        if(authwid[s]==tbars[x].text){
					        	newBars.push(tbars[x]);
					        }
					    }
					  }
					//jQuery.inArray("John", data.types);
					/*for (var i = 0; i < tbars.length; i++) {
						var bar = tbars[i];
						// btnType 为空显示
						if (!bar.btnType) {
							// alert(bar);
							// newBars.push(bar);
						} else {
							// 判断btnType是否存在,存在则显示
							if ($.inArray(bar.btnType, data.types) >= 0) {
								newBars.push(bar);
							}
						}
					}*/	
					// newBars.splice(2, 2, "dd","33");
					if (newBars.length > 0) {
						// Grid.datagrid({
						// 'toolbar' : newBars
						// });
						tbars = newBars;
						dataGrid.toolbar = tbars;
					}
				}
				if (callback && callback instanceof Function) {
					callback();
				}
			} else {
				sdwangge.alert('提示', data.msg);
			}
		});
		// return tbars;
	}

	// 初始话form
	var initForm = function() {
		if (Form.search && Form.search[0]) {
			Form.search.find("#btn-search").hover(
				function(){
					$(this).addClass("hover");
				},
				function(){
					$(this).removeClass("hover");
				}
			).click(Events.search);
			Form.search.find("#btn-reset").hover(
				function(){
					$(this).addClass("hover");
				},
				function(){
					$(this).removeClass("hover");
				}
			);
		}
	}

	var initWin = function() {
		if (Win.edit && Win.edit[0]) {
			// 判断页面是否设置buttons，如果没有设置默认按钮
			var btns = Win.edit.attr("buttons");
			if (!btns) {
				// 设置 保存,关闭按钮
				Win.edit.dialog({
					buttons : [ {
						text : '保存',
						id : 'editsave',
						handler : Events.save
					}, {
						text : '取消',
						handler : Events.close
					} ]
				});
			}
			// Win.edit.find("#btn-submit").click(Events.save); //保存事件
			// Win.edit.find("#btn-close").click(Events.close);//关闭窗口
		}
		if (detailWin.detail && detailWin.detail[0]) {
			// 判断页面是否设置buttons，如果没有设置默认按钮
			var btns = detailWin.detail.attr("buttons");
			if (!btns) {
				// 设置 保存,关闭按钮
				detailWin.detail.dialog({
					buttons : [ {
						text : '关闭',
						handler : Events.detailclose
					} ]
				});
			}
			// Win.edit.find("#btn-submit").click(Events.save); //保存事件
			// Win.edit.find("#btn-close").click(Events.close);//关闭窗口
		}

		// if(funauthWin.funauth && funauthWin.funauth[0]){
		// //判断页面是否设置buttons，如果没有设置默认按钮
		// var btns = funauthWin.funauth.attr("buttons");
		// if(!btns){
		// //设置 保存,关闭按钮
		// funauthWin.funauth.dialog({
		// buttons:[
		// {
		// text:'保存',
		// id:'funauthbtn',
		// handler:Events.save
		// },{
		// text:'关闭',
		// handler:function(){
		// $('#funauth-win').dialog('close');
		// }
		// }
		// ]
		// });
		// }
		// //Win.edit.find("#btn-submit").click(Events.save); //保存事件
		// //Win.edit.find("#btn-close").click(Events.close);//关闭窗口
		// }

	}

	// this 返回属性
	this.win = Win;
	this.form = Form;
	this.grid = Grid;
	this.utils = Utils;
	this.handler = Handler;

	// 初始化方法
	this.init = function() {
		// initGrid();
		initTbar(initGrid);
		initForm();
		initWin();
	}
	// 调用初始化
	return this;
};