	//判断点是否在划定范围内的方法
		function Point1(x,y){
			var opoint1=new Object();
			opoint1.x=x;
			opoint1.y=y;
			return opoint1;
		}
		//targetPoint,ptArry,ptArry.length-1
function  PtInPolygon(p,pt,nCount){
	var nCross=0;
	var p1;
	var p2;
	for(var i=0;i<nCount;i++){
		p1=pt[i];
		p2=pt[(i+1)%nCount];
		if(p1.y==p2.y){
			if(p.y==p1.y&&p.x>=min(p1.x,p2.x)&&p.x<=max(p1.x,p2.x))
				return true;
			continue;
		}
		if(p.y<min(p1.y,p2.y)||p.y>max(p1.y,p2.y))
			continue;
		var x=(p.y-p1.y)*(p2.x-p1.x)/(p2.y-p1.y)+p1.x;
		if(x>p.x)nCross++;
		else if(x==p.x)
			return true;
	}
	if(nCross%2==1)
		return true;
	
	
	return false;
}

function min(x,y){
	if(x<y)return x;
	return y;
}

function max(x,y){
	if(x>y)return x;
	return y;
}

function getJWQByPoint(zuobiaoArray,mouseX,mouseY,jwqNameArray,jwqIdArray){
	//return;
	for(var m=0;m<zuobiaoArray.length;m++){	 
  		if("null"!=zuobiaoArray[m] && ""!=zuobiaoArray[m]){
  	         var zuobiaoList=new Array();
  	         zuobiaoList=zuobiaoArray[m].split(",");
  	       var ptArry=new Array();
  	     var k=0;
		   for(var i=0;i<zuobiaoList.length;i=i+2){
               var pt=Point1(zuobiaoList[i]*1,zuobiaoList[i+1]*1);
			   ptArry[k]=pt;
			   k++;			
		      }
		   var ss=Point1(mouseX,mouseY);
		   var flag=PtInPolygon(ss,ptArry,ptArry.length-1); 
		  // alert(flag);
		   var jwqXinXi=new Array();
		   jwqXinXi[0]=jwqNameArray[m];
		   jwqXinXi[1]=jwqIdArray[m];
		   if(flag==true){
			   return jwqXinXi;
			   } 
		}
		
  	  	}
	  	return null;
    }


function isPermissionbyPoint(zuobiaoArray,mouseX,mouseY){
	//try{
		
	//	alert(parent.parent.parent.parent.parent.tempB);
	//}catch(e){
	//	alert('aaaaaaaaaaaaaaaaa');
	//}
	//return;
	//alert("zuobiaoArray:::"+zuobiaoArray);
	//alert(zuobiaoArray.length);
	for(var m=0;m<zuobiaoArray.length;m++){	 
  		if("null"!=zuobiaoArray[m] && ""!=zuobiaoArray[m]){
  	         var zuobiaoList=new Array();
  	         zuobiaoList=zuobiaoArray[m].split(",");
  	       var ptArry=new Array();
  	     var k=0;
		   for(var i=0;i<zuobiaoList.length;i=i+2){
               var pt=Point1(zuobiaoList[i]*1,zuobiaoList[i+1]*1);
			   ptArry[k]=pt;
			   k++;			
		      }
		   var ss=Point1(mouseX,mouseY);
		   var flag=PtInPolygon(ss,ptArry,ptArry.length-1);
		   //alert()
		   //alert(flag);
		  // var jwqName=jwqNameArray[m];
		   if(flag==true){
			   return true;
			   } 
		}
		
  	  	}
	  	return false;
    }

function isSspcsPermissionbyPoint(zuobiao,mouseX,mouseY){
	//try{
		
	//	alert(parent.parent.parent.parent.parent.tempB);
	//}catch(e){
	//	alert('aaaaaaaaaaaaaaaaa');
	//}
	//return;
	//alert("zuobiaoArray:::"+zuobiaoArray);
	//alert(zuobiaoArray.length);
	 
  		if("null"!=zuobiao && ""!=zuobiao){
  	         var zuobiaoList=new Array();
  	         zuobiaoList=zuobiao.split(",");
  	       var ptArry=new Array();
  	     var k=0;
		   for(var i=0;i<zuobiaoList.length;i=i+2){
               var pt=Point1(zuobiaoList[i]*1,zuobiaoList[i+1]*1);
			   ptArry[k]=pt;
			   k++;			
		      }
		   var ss=Point1(mouseX,mouseY);
		   var flag=PtInPolygon(ss,ptArry,ptArry.length-1);
		   //alert()
		   //alert(flag);
		  // var jwqName=jwqNameArray[m];
		   if(flag==true){
			   return true;
			   } 
		}
		
  	  	
	  	return false;
    }



