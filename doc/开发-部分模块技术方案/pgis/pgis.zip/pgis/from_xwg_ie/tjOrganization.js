var tjOrgan=function (jb,ssfj,sspcs,ssjwq) {
	
			if(jb==0){
				getOrganise('370100000000',"ssfj");
			}else if(jb==1){
				getOrganise('370100000000',"ssfj");
			}else if(jb==2){
				getOrganId(ssfj,"ssfj",ssfj);
				$("#ssjwq").combobox('clear');
				$("#ssjwq").combobox('disable');
				$("#sspcs").combobox('clear');
				getOrganise(ssfj,"sspcs");
				
			}else if(jb==3){
				getOrganId(ssfj,"ssfj",ssfj);
				getOrganId(sspcs,"sspcs");
				$("#ssjwq").combobox('clear');
				$("#ssjwq").combobox('enable');
				getOrganise(sspcs,"ssjwq");
		
			}else if(jb==4){
				getOrganId(ssfj,"ssfj");
				getOrganId(sspcs,"sspcs");
				getOrganId(ssjwq,"ssjwq");
			}
}