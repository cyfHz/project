function onLoad() {
	if(typeof EzMap =="undefined"){
		window.setTimeout("onLoad()",10);
		return;
	}
  	if(_compatIE()){		
		_MapApp = new EzMap(document.getElementById("mymap"));
		var pOverview=new OverView();
		pOverview.minLevel=8;
		pOverview.maxLevel=14;
		_MapApp.addOverView(pOverview);
		_MapApp.showMapControl(); 
		_MapApp.switchMapServer(1);//使地图以矢量叠加的方式显示
		_MapApp.showOverView();//显示鹰眼	 	 
	}else if(_MapApp==null){
		var pEle=document.getElementById("mymap");		 
	}	
}
//按钮清除实现功能的方法
function clearIcon() {	  
	  _MapApp.clear();
}



