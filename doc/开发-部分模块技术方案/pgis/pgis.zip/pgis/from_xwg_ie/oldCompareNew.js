var Return_AddStrFn=function (oldArr, newArr) {
        var t = this;
　　　　　　　//去重复的方法
        Array.prototype.unique4 = function () {
            // this = arr;
            var temp = new Array();
            this.sort();
            for (i = 0; i < this.length; i++) {
                if (this[i] == this[i + 1]) {
                    continue;
                }
                temp[temp.length] = this[i];
            }
            return temp;
        }
        var a = d = oldArr.unique4(); //旧数组
        var b = e = newArr.unique4();//新数组
        var c = [];
        var dels = [];
        function f() {
            a.sort();
            b.sort();
            var i = 0;
            var j = 0;
            while (i < a.length && j < b.length) {
                if (a[i] < b[j]) {
                    c.push(a[i]);
                    i++;
                } else if (b[j] < a[i]) {
                    c.push(b[j]);
                    j++;
                } else {
                    i++;
                    j++;
                }
            }
            while (i < a.length) {
                c.push(a[i]);
                i++;
            }
            while (j < b.length) {
                c.push(b[j]);
                j++;
            }
        }
        f();
        var addstr = [];
        for (var i = 0; i < c.length; i++) {
            for (var j = 0; j < e.length; j++) {
                if (e[j] == c[i]) {
                    addstr.push("add"+e[j]);
                }
            }
        }
        return addstr; //新增的
    };
    
var Return_DelStrFn=function (oldArr, newArr) {
        var t = this;
　　　　　　　//去重复的方法
        Array.prototype.unique4 = function () {
            // this = arr;
            var temp = new Array();
            this.sort();
            for (i = 0; i < this.length; i++) {
                if (this[i] == this[i + 1]) {
                    continue;
                }
                temp[temp.length] = this[i];
            }
            return temp;
        }
        var a = d = oldArr.unique4(); //旧数组
        var b = e = newArr.unique4();//新数组
        var c = [];
        var dels = [];
        function f() {
            a.sort();
            b.sort();
            var i = 0;
            var j = 0;
            while (i < a.length && j < b.length) {
                if (a[i] < b[j]) {
                    c.push(a[i]);
                    i++;
                } else if (b[j] < a[i]) {
                    c.push(b[j]);
                    j++;
                } else {
                    i++;
                    j++;
                }
            }
            while (i < a.length) {
                c.push(a[i]);
                i++;
            }
            while (j < b.length) {
                c.push(b[j]);
                j++;
            }
        }
        f();
   
        for (var i = 0; i < c.length; i++) {
          for (var j = 0; j < d.length; j++) {
               if (d[j] == c[i]) {
                   dels.push("del"+d[j]);
               }
           }
       }
        //alert("dels:" + dels); //删除的
	return dels;
    };
    
    Array.prototype.del = function() { 
    	var a = {}, c = [], l = this.length; 
    	for (var i = 0; i < l; i++) { 
    	var b = this[i]; 
    	var d = (typeof b) + b; 
    	if (a[d] === undefined) { 
    	c.push(b); 
    	a[d] = 1; 
    	} 
    	} 
    	return c; 
    	} 