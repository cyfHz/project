// 动态显示线
if (typeof EzServerClient == "undefined" || !EzServerClient) {
	var EzServerClient = {};
}
if (typeof EzServerClient.GlobeParams == "undefined" || !EzServerClient.GlobeParams) {
	EzServerClient.GlobeParams = {};
}
if (typeof EzServerClient.GlobeFunction == "undefined" || !EzServerClient.GlobeFunction) {
	EzServerClient.GlobeFunction = {};
}
/**
  * 函数功能：动态绘制线
  * @param {Polyline} vPolyline 要动态绘制的线
  * @param {String} vGrowLineStyle 动态绘制过程中线的样式，取值："none","dash","dashdot","dot","longdash","longdashdot","shortdash","shortdashdot","shortdashdotdot","longdashdotdot","shortdot"
  * @param {EzMap} vEzMap 要将线绘制到的地图对象
  * @param {Int} vIntervalPixel 每次动态生长的像素，单位为px
  * @param {Int} vSpeed 每次动态生长的时间，单位为ms
  */
EzServerClient.GlobeFunction.displayDynamicPolyline = function (vPolyline, vGrowLineStyle, vEzMap, vIntervalPixel, vSpeed) {
	 
	// 在线上每15个像素截取一个点，组成子线段数组
	var uLines = EzServerClient.GlobeFunction.getLinePoints(vPolyline.getPoints(), vIntervalPixel, vEzMap);
	vPolyline._IIII = 0;
	vPolyline._TempLineList = [];
	vPolyline._MMMM = setInterval(function () {
		if (vPolyline._IIII < uLines.length) {
			//ezfunction.InterFace.isClear = false;
			EzServerClient.GlobeFunction.addLine(vPolyline, uLines[vPolyline._IIII], vEzMap, vPolyline.getColor(), vPolyline.getWidth(), vPolyline.getOpacity(), vGrowLineStyle);
		} else {
			clearInterval(vPolyline._MMMM);
			vPolyline._IIII = 0;
			for (var i = 0; i < vPolyline._TempLineList.length; i++) {
				vEzMap.removeOverlay(vPolyline._TempLineList[i]);
			}
			vPolyline._TempLineList.clear();
			vEzMap.addOverlay(vPolyline);// 此处为动态绘制完毕后将原始的polyline绘制在地图上
			//ezfunction.InterFace.isClear = true;
			vPolyline.setDashStyle(vGrowLineStyle);
			vPolyline.flash();//增加动态轨迹闪烁
			return;
		}
		vPolyline._IIII++;
	}, vSpeed);
	return vPolyline._MMMM;
};
	// 绘制子线
EzServerClient.GlobeFunction.addLine = function (vPolyline, vLineStr, vEzMap, vColor, vWidth, vTransp, vGrowLineStyle) {
	var uPolyline1 = new Polyline(vLineStr, vColor, vWidth, vTransp);
	uPolyline1.setLineStyle(vGrowLineStyle);
	vPolyline._TempLineList.push(uPolyline1);
	vEzMap.addOverlay(uPolyline1);
};
	// 获得线段的坐标对
EzServerClient.GlobeFunction.getLinePoints = function (vPoints, vPixel, vEzMap) {
	var uResultLineList = [];
	for (var i = 1; i < vPoints.length; i++) {
		var uPoints = EzServerClient.GlobeFunction.getInnerPoints(vPoints[i - 1], vPoints[i], vPixel, vEzMap);
		for (var j = 1; j < uPoints.length; j++) {
			uResultLineList.push(uPoints[j - 1].toString() + "," + uPoints[j].toString());
		}
	}
	return uResultLineList;
};
	// 获得内部点
EzServerClient.GlobeFunction.getInnerPoints = function (vPoint1, vPoint2, vPixel, vEzMap) {
	var uResultList = [vPoint1];
	var uP1 = vEzMap.mapCoord2container(vPoint1);//在当地图前级别下，将地图坐标换成地图容器中的像素坐标
	var uP2 = vEzMap.mapCoord2container(vPoint2);
	var uLen = Math.sqrt(Math.pow((uP1.x - uP2.x), 2) + Math.pow((uP1.y - uP2.y), 2));
	if (uLen > vPixel) {
		var uScale = vPixel / uLen;
		for (var i = 1; i < 1 / uScale; i++) {
			var uDeltaX = uScale * i * (vPoint2.x - vPoint1.x);
			var uDeltaY = uScale * i * (vPoint2.y - vPoint1.y);
			var uPoint = new Point(vPoint1.x + uDeltaX, vPoint1.y + uDeltaY);
			uResultList.push(uPoint);
		}
	}
	uResultList.push(vPoint2);
	return uResultList;
};

