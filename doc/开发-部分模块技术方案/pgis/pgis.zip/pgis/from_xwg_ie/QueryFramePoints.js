function queryFramePoints(mapObject, data) {
	$.each(data, function(i, a) {
		var zbx = "";
		var zby = "";
		var mc = "";
		var dz = "";
		var sszzjg = "";//所属组织机构
		var xb = "";//性别
		var sfzh = "";//身份号
		var sbbh = "";//设备编号
		switch (mapObject.searchType) {
		case dic.mlph: {// 门楼牌号对象
			var p = new mlphModel();
			p.dzid = a.ywlsh;
			p.mphdm = a.dzyslxdm;
			p.mphmc = a.qhnxxdz;
			p.mpxz = a.dzmc;
			p.mph = a.mlph;
			p.zbx = a.zxdhzb;
			p.zby = a.zxdzzb;
			p.jzwmc = a.jzwmc;
			p.url = "/建筑物信息界面?dzid=" + a.ywlsh;
			//var point = new Point(p.zbx, p.zby);
			// mapObject.pointArray_qwjs.push(point);
			mapObject.pointQueryArray.push(point);
			mapObject.indexPlaceArray.push(p);
			
			break;
		}
		case dic.jyz: {// 加油站处理
			var p = new jyzModel();
			p.id = a.KEY;// 主键
			p.dz = a.JYDZ;// 加油站地址
			p.mc = a.QYMC;// 加油站名称
			p.zbx = a.XZB;
			p.zby = a.YZB;
			p.url = "";// 点击marker挑战地址
			//var point = new Point(p.zbx, p.zby);
			 
			mapObject.indexPlaceArray.push(p);
			break;
		}
		case dic.jydw: {// 警员定位处理
			var p = new jydwModel();
			p.sfzh=a.user_sfzh;
			p.sfzx = a.sfzx;
			p.sbbh=a.client_sb_no;
			p.sszzjg=a.orgna_name;
			p.mc = a.user_name;
			p.gps_x = a.gps_x;
			p.gps_y = a.gps_y;
			p.gps_time = a.gps_time;
			p.sfdqy = a.sfdqy;
			
			p.url = "";// 点击marker挑战地址
			//var point = new Point(p.gps_x, p.gps_y);
			 
			mapObject.indexPlaceArray.push(p);
			break;
		}
		case dic.jygj: {// 警员轨迹处理
			var p = new jygjModel();
			p.sfzh=a.user_sfzh
			p.sbbh=a.client_sb_no;
			p.sszzjg=a.orgna_name;
			p.mc = a.user_name;
			p.gps_x = a.gps_x;
			p.gps_y = a.gps_y;
			p.gps_time = a.gps_time;
			p.url = "";// 点击marker挑战地址
			var point = new Point(p.gps_x, p.gps_y);
			mapObject.pointQueryArray.push(point);
			mapObject.indexPlaceArray.push(p);
			break;
		}
		case dic.dw:{//单位
			var p = new dwModel();
			p.id = a.dwid;// 主键
			p.dz = a.dwxxdz;//  
			p.mc = a.dwmc;//  
			p.zbx = a.zbx;
			p.zby = a.zby;
			 
			var point = new Point(p.zbx, p.zby);
			 
			mapObject.indexPlaceArray.push(p);
			break;
		}
		case dic.bw:{//保卫
			var p = new bwModel();
			p.id = a.yjid;// 主键
			p.mc = a.rwdd;//  
			p.zbx = a.zbx;
			p.zby = a.zby;
			//var point = new Point(p.zbx, p.zby);
			 
			mapObject.indexPlaceArray.push(p);
			break;
		}
		case dic.jwry:{//境外人员
			var p = new jwryModel();
			p.id = a.jwryid;// 主键
			p.gj = a.gj;
			p.ywm = a.ywm;//  
			p.zwm = a.zwm;
			p.dzmc = a.dzmc;
			p.zbx = a.zbx;
			p.zby = a.zby;
			//var point = new Point(p.zbx, p.zby);
			 
			mapObject.indexPlaceArray.push(p);
			break;
		}
		}

	});
}