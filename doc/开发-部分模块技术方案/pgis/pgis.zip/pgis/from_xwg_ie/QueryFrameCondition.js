function queryFrameCondition(searchType,pagenum,exPramas)
{
	var randomStr = parseInt(10000 * Math.random()).toString();
	var paramsJson = {
		"randoms" : randomStr,
		"searchWord" : $("#texQuery").val(),//模糊查询文本框的内容，即like的条件
		"syString" : syString,
		"isSY" : isSY,
		"pageIndex" : pagenum,
		"organbh" : $("#organbh").val(),//选择组织机构，暂时只有警员定位用到
		"exPramas":exPramas
	};	
	if(searchType==dic.jygj){
		paramsJson.gps_time_Start=$("#gps_time_Start").datetimebox("getValue");
		paramsJson.gps_time_End=$("#gps_time_End").datetimebox("getValue")
	}

	//exPramas格式  此值是扩展二级搜索
	//{params1:'1',params2:'2'}数据格式
	return paramsJson;
}