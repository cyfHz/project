$.extend($.fn.validatebox.defaults.rules, {
	validateIdCard: {
	validator:function(value,param){
		var requeired = param[1]
		var validate = true;
		if(requeired){
			if(value.length==15||value.length==18){
				validate = validateIdCard(value,requeired);
				if(!validate)
					this.message="身份证格式不正确";
			}else{
				this.message="15位或18位公民身份号码"
				return false;
			}
		}
		return validate;
	},
	message:'身份证格式不正确'
}
}); 

	var powers_val=new Array("7","9","10","5","8","4","2","1","6","3","7","9","10","5","8","4","2");   
    var parityBit_val=new Array("1","0","X","9","8","7","6","5","4","3","2");   
    // var sex="male";
    // 校验公民身份号码的主调用
    function validateIdCard(value,required){   

        var _validate=false;  
        
        if(required){
            if(value.length==15){   
                _validate=validateId15(value);   
            }else if(value.length==18){   
                _validate=validateId18(value);   
            }
            return _validate;
        }
        return true;        	
     }       
    // 校验18位的公民身份号码
  
    function validateId18(_id){   
         _id=_id+"";   
        var _num=_id.substr(0,17);   
        var _parityBit=_id.substr(17);   
        var _power=0;   
        for(var i=0;i< 17;i++){   
            // 校验每一位的合法性
  
            if(_num.charAt(i)<'0'||_num.charAt(i)>'9'){   
                return false;   
                break;   
             }else{   
                // 加权
  
                 _power+=parseInt(_num.charAt(i))*parseInt(powers_val[i]);   
                // 设置性别
  
                // if(i==16&&parseInt(_num.charAt(i))%2==0){
                // sex="female";
                // }else{
                // sex="male";
                // }
             }   
         }   
        // 取模
  
        var mod=parseInt(_power)%11;   
        if(parityBit_val[mod]==_parityBit){   
            return true;   
         }   
        return false;   
     }   
    // 校验15位的公民身份号码
  
    function validateId15(_id){   
         _id=_id+"";   
        for(var i=0;i<_id.length;i++){   
            // 校验每一位的合法性
  
            if(_id.charAt(i)<'0'||_id.charAt(i)>'9'){   
                return false;   
                break;   
             }   
         }   
        var year=_id.substr(6,2);   
        var month=_id.substr(8,2);   
        var day=_id.substr(10,2);   
        var sexBit=_id.substr(14);   
        // 校验年份位
  
        if(year<01||year >90)return false;   
        // 校验月份
  
        if(month<01||month >12)return false;   
        // 校验日
  
        if(day<01||day >31)return false;   
        // 设置性别
  
        // if(sexBit%2==0){
        // sex="female";
        // }else{
        // sex="male";
        // }
        return true;   
    }   