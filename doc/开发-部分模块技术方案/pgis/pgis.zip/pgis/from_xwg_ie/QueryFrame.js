﻿/* 
 * 全文索引业务模版查询
 *  
 * 
 */
QueryFrame = function(mapObj, callBack) {
	if (!mapObj) {
		alert(typeof (mapObj) + "Not Map Object!");
		return;
	}
	this.mapObject = mapObj; //地图对象
	var indexPageTotol = 0;
	var indexPageNow = 0;
	//var indexPageSize = 30;
	this.indexPlaceArray = new Array(); //用来存放获取的数据列表，进行数据的绑定
	this.indeximgMarkers = new Array(); //进行数据记录的图标集的存放
	this.indeximgmarkersHTML = new Array(); //进行数据记录的图标集的显示内容存放
	this.indexTitleArray = new Array(); //用来存放多区域图层的title
	this.lucene_msj_html = "";
	this.shijiliebiao = getEleById("shijiliebiao");
	this.tanchuliebiao = getEleById("tanchuliebiao");
	this.lucene_html_result = "";
	this.callBack = callBack;
	this.isDisplayTilte = false;
	this.isAddLayer=false;//是否叠加图层 如果是就不清空原有图层
	//分页设置S
	this.pagenum = 1; //当前页码
	this.totalpage = null; //总页数
	this.totalNum = null; // 共多少条
	this.page_start = null; //分页最小的选择数
	this.page_end = null; //分页最大的选择数
	this.searchType = appConfigQueryType;
	this.clickInfoNow = 0; //记录当前操作编号
	this.isFirst = true; //首次查询
	this.isGuiji = false;
	this.syString = null;
    this.pointQueryArray=new Array();//查询的pointdian
}
QueryFrame.prototype.setsyString = function (systring) {
    this.syString = systring;
}
QueryFrame.prototype.getMapObject = function() {
	return this.mapObject;
}
//设置当前视野查询是否显示标题
QueryFrame.prototype.setIsDisplayTilte = function(isDisplayTilte) {
	this.isDisplayTilte = isDisplayTilte;

}
//设置是否叠加图层
QueryFrame.prototype.setIsAddLayer = function(isAddLayer) {
	this.isAddLayer = isAddLayer;

}
//设置当前是否轨迹查询
QueryFrame.prototype.setIsGuiji = function(isguiji) {
	this.isGuiji = isguiji;

}
/**
 *  为内容添加事件
 * @param {} index
 */
QueryFrame.prototype.addEventForQueryResult = function(index) {
	var self = this;
	var _queryResult = $('#_queryResult' + index % pageSize);
	if (_queryResult != null) {
		_queryResult.bind('mouseover', function() {
			self.changeImgForMarker(1, index);
			_queryResult.removeClass("queryResutlForOnmouseout");
			_queryResult.addClass("queryResutlForOnmouseover");
		});
		_queryResult.bind('mouseout', function() {
			self.changeImgForMarker(2, index);
			_queryResult.removeClass("queryResutlForOnmouseover");
			_queryResult.addClass("queryResutlForOnmouseout");
		});

		_queryResult.bind('click', function() {
				showResults(); //隐藏左侧
				self.showInfoWindowForMarker(index);
			});
	}
}
/**
 * marker图片变更事件
 * @param {} imgKind
 * @param {} index
 */
QueryFrame.prototype.changeImgForMarker = function(imgKind, index) {
	// alert(index);
	switch (this.searchType) {
	case dic.mlph: {
		if (this.indeximgMarkers[index] != null) {
			var point = this.indeximgMarkers[index].getPoint();
			var html = this.indeximgmarkersHTML[index];
			this.mapObject.removeOverlay(this.indeximgMarkers[index]);
			this.indeximgMarkers[index] = this.getImgMarker(point, imgKind,
					html, index);
			this.mapObject.addOverlay(this.indeximgMarkers[index]);
		}
		break;
	}
	default: {
		if (this.indeximgMarkers[index] != null) {
			var point = this.indeximgMarkers[index].getPoint();
			var html = this.indeximgmarkersHTML[index];

			this.mapObject.removeOverlay(this.indeximgMarkers[index]);
			this.indeximgMarkers[index] = this.getImgMarker(point, imgKind,
					html, index);
			this.mapObject.addOverlay(this.indeximgMarkers[index]);
		}
		break;
	}
	}

}
// marker弹出气泡框事件 定位到地图上
QueryFrame.prototype.showInfoWindowForMarker = function(index) {
	switch (this.searchType) {
	case dic.mlph: {
		if (this.indeximgMarkers[index] != null) {
			if ($('#_queryDailog' + index) != null) {
				$('#_queryDailog' + index).html("");
			}
			this.mapObject.centerAndZoom(this.indeximgMarkers[index].point, 17);
			this.indeximgMarkers[index]
					.openInfoWindowHtml(this.indeximgmarkersHTML[index]);
		}
		//return;
		//this.addOnclickEventsForInfoWindow(this.indeximgMarkers[index].point, index);
		break;
	}
	case dic.jwq: {
		if (this.indeximgMarkers[index] != null) {
			if ($('#_queryDailog' + index) != null) {
				$('#_queryDailog' + index).html("");
				if (this.indeximgMarkers[index].getPoints() != null) {
					//this.mapObject.removeOverlay(this.indeximgMarkers[index]);
					//this.indeximgMarkers[index] = this.getPolygonMarker(this.indeximgmarkersHTML[index], index);
					//this.mapObject.addOverlay(this.indeximgMarkers[index]);
					//this.mapObject.stopOverlayBlink(this.indeximgMarkers[i]);
					var strPoints = this.indexPlaceArray[index].bjzbz;
					//this.mapObject.centerAndZoomToBorder(strPoints);
					this.indeximgMarkers[index]
							.openInfoWindowHtml(this.indeximgmarkersHTML[index]);
				}
			}
		}
		break;
	}
	default: {
		if (this.indeximgMarkers[index] != null) {
			if ($('#_queryDailog' + index) != null) {
				$('#_queryDailog' + index).html("");
			}
			this.mapObject.centerAndZoom(this.indeximgMarkers[index].point, 17);
			this.indeximgMarkers[index]
					.openInfoWindowHtml(this.indeximgmarkersHTML[index]);
		}
		//return;
		//this.addOnclickEventsForInfoWindow(this.indeximgMarkers[index].point, index);
		break;
	}
	}
}

//获取不同表示的不同图标
QueryFrame.prototype.getImgMarkerIcon = function(imgKind,index) { //1 蓝色  2 红色 3开始  4结束
	var imgAddr;
	var topOffset = 0;
	var leftOffset = 0;
	var height = 0;
	var width = 0;
	// 红色marker

	switch (imgKind) {
	case 1:
		imgAddr = urls.msUrl + "/images/icon/min_mark_blue.gif";
		break;
	case 2:
		imgAddr = urls.msUrl + "/images/icon/min_mark_red.gif";
		break;
	case 3:
		imgAddr = urls.msUrl + "/images/icon/mark_start.gif";
		break;
	case 4:
		imgAddr = urls.msUrl + "/images/icon/mark_end.gif";
		break;

	default:
		imgAddr = urls.msUrl + "/images/icon/min_mark_red.gif";
	}
	switch (this.searchType) {
	case dic.jygj: // 人员轨迹
		{
		imgAddr = img_dic.jygj;
		break;
		}
	case dic.jydw: // 警员定位
	{
		var pInfojydw = this.indexPlaceArray[index];
		if(pInfojydw.sfzx == 'zx'){
			imgAddr = img_dic.jydw;
		}
		if(pInfojydw.sfzx == 'bzx'){
			imgAddr = img_dic.jygjbzx;
		}
	break;
	}
		default:
			break;
		}
	height = 16;
	width = 16;
	if(this.searchType == dic.jydw){
		if(pInfojydw.sfzx == 'zx'){
			height = 24;
			 width = 24;
		}
		if(pInfojydw.sfzx == 'bzx'){
			height = 24;
			 width = 12;
		}
	}
	if(this.searchType == dic.jygj){
		 height = 24;
		 width = 24;
	}
	topOffset = -4;
	leftOffset = 2;
	var imgIcon = new Icon();
	imgIcon.image = imgAddr;
	imgIcon.height = height;
	imgIcon.width = width;
	imgIcon.topOffset = topOffset;
	imgIcon.leftOffset = leftOffset;
	return imgIcon;
}

//获取地图中的标识
QueryFrame.prototype.getPolygonMarker = function(titleContent, index) {
	var self = this;
	var pInfo = self.indexPlaceArray[index];
	if (pInfo.bjzbz != null) {
		//var pPloyObjcet = new Polygon(pInfo.bjzbz, lineColorJwq, 1, 0.1, "blue");
		var pPloyObjcet = new Polyline(pInfo.bjzbz, lineColorJwq, 2, 1, 0);
		// 添加事件
		//pPloyObjcet.addListener("mouseover", function () { });
		if (titleContent != null) {
			pPloyObjcet
					.addListener(
							"click",
							function() {
								pPloyObjcet
										.openInfoWindowHtml(self.indeximgmarkersHTML[index]);
							});
		}
		if (self.isDisplayTilte) {
			var mbrpolyLine = pPloyObjcet.getMBR();
			var titlePolyLine = new Title(pInfo.mc, 14, 8,
					"宋体, arial, helvetica, sans-serif", "#000", "#e4f2fc",
					"#fff", "1");
			titlePolyLine.setPoint(mbrpolyLine.getCenterPoint());
			titlePolyLine.bIsTransparent = true;
			titlePolyLine.setOpacity(0.9);
			titlePolyLine.addListener("click", function() {
				titlePolyLine
						.openInfoWindowHtml(self.indeximgmarkersHTML[index]);
			});
			self.indexTitleArray.push(titlePolyLine);

		}
		return pPloyObjcet;
	}
	return null;

}
//获取地图中的标识
QueryFrame.prototype.getImgMarker = function(point, imgKind, titleContent,
		index) {
	var self = this;
	var pInfo = self.indexPlaceArray[index];
	var imgMarkerIcon = this.getImgMarkerIcon(imgKind,index); // 获取Icon图标
	var titleinfo = "";
	var titleinfoName = "";
	var title = null;
	var titleSum = "";
	switch (this.searchType) {
	case dic.mlph: {
		titleinfoName = pInfo.jzwmc;
		/*titleinfo = pInfo.mph;
		if(null ==titleinfoName){
			titleinfoName = "";
		}
		if(null == titleinfo){
			titleinfo = "";
		}
		if(null != titleinfo || null != titleinfoName){
			titleSum = titleinfo+titleinfoName;
		}else{
			titleSum = "无";
		}*/
		if(null == titleinfoName){
			titleinfoName = '无名建筑'
		}
		title = new Title(titleinfoName, 12, 8, "宋体", "#000", "#e4f2fc", "#fff",
				"1");
		break;
	}
	case dic.jwry: {
		titleinfo = pInfo.zwm;
		title = new Title(titleinfo, 12, 8, "宋体", "#000", "#e4f2fc", "#fff",
				"1");
		break;
	}
	default: {
		titleinfo = pInfo.mc;
		title = new Title(titleinfo, 12, 8, "宋体", "#000", "#e4f2fc", "#fff",
				"1");
		break;
	}
	}
	if (titleinfo == null) {
		titleContent = "";
		titleinfo = "";
	}
	var imgMarker;

	imgMarker = new Marker(point, imgMarkerIcon, title);

	// 添加事件
	imgMarker.addListener("mouseover", function() {
	});
	if (titleContent != null) {
		imgMarker.addListener("click", function() {
			switch (this.searchType) {
			case dic.mlph: {
				imgMarker.openInfoWindowHtml(self.indeximgmarkersHTML[index]);
				break;
			}
			default:
			{
				imgMarker.openInfoWindowHtml(self.indeximgmarkersHTML[index]);
				break;
			}
			}
			

			});
	}
	return imgMarker;
}

//获取分页的相关内容
QueryFrame.prototype.getPagingHTML = function() {
	var start;
	var end;
	var up = "&nbsp;&nbsp;<img id='viewQuery_paging_up' src='"+urls.msUrl+"/images/prepage.gif' style='cursor:hand;vertical-align: middle' >";
	var down = "&nbsp;&nbsp;&nbsp;&nbsp;"
			+ "<img  id='viewQuery_paging_down' src='"+urls.msUrl+"/images/nextpage.gif' style='cursor:hand;vertical-align: middle' >";
	if (this.totalpage <= 4) {
		start = 1;
		end = this.totalpage;

	} else {
		if (this.pagenum == 1) {
			start = 1;
			end = 4;
		} else {
			if (this.pagenum <= this.totalpage - 2) {
				end = this.pagenum + 2;
				start = this.pagenum - 1;
			} else if (this.pagenum <= this.totalpage - 1) {
				end = this.pagenum + 1;
				start = this.pagenum - 2;
			} else {
				end = this.pagenum;
				start = this.pagenum - 3;
			}

		}

	}
	this.page_start = start;
	this.page_end = end;
	var center = "";
	for ( var i = start; i <= end; i++) {
		if (i == this.pagenum) {
			center += "<span >&nbsp;&nbsp;" + i + "&nbsp;&nbsp;</span>";
		} else {
			center += "<span id='viewQuery_paging_" + i
					+ "' style='cursor:hand;color:#0000aa'>&nbsp;&nbsp;" + i
					+ "&nbsp;&nbsp;</span>";
		}

	}
	if (this.pagenum == 1) {
		up = "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;";
	}
	if (this.totalpage == 0 || this.pagenum == this.totalpage) {
		down = "&nbsp;&nbsp;&nbsp;&nbsp;";
	}
	if(this.totalNum>pageSize)
	return "</br><div width='100%'><table  width='100%'><tr><td align=\"center\" valign=\"middle\">"
			+ up + center + down + "</td></tr></table></div>";
}

/*******************地图标志 函数**************************************/
/**
 *  画marker
 */
QueryFrame.prototype.drawMarkers = function(index) {
	var map = this.mapObject;
	var markers = this.indeximgMarkers;
	var start = pageSize * (index - 1);
	var end = pageSize * index - 1;
	for ( var i = 0; i < markers.length; i++) {
		if (i >= start && i <= end) {
			continue;
		}
		if (markers[i] != null) {
			map.addOverlay(markers[i], false);
		}
	}
	for ( var i = start; i <= end; i++) {
		if (markers[i] != null) {
			map.addOverlay(markers[i], false);//画点
		}

	}
	if (this.isDisplayTilte == true) {
		for ( var i = 0; i < this.indexTitleArray.length; i++) {
			map.addOverlay(this.indexTitleArray[i]);
		}
	}
}
//刪除地图上的maker
QueryFrame.prototype.removeMarkers = function () {
    try {
        var map = this.mapObject;
        var markers = this.indeximgMarkers;

        for (var i = 0; i < markers.length; i++) {
             
            if (markers[i] != null) {
                map.removeOverlay(markers[i]);
            }
        }
    } catch (e) {
    }   
}
QueryFrame.prototype.getPagingData = function() {
	syString = oldsyString;	
    // 根据t(1门牌号2场所3人口)
    if (isSY == false) {
        if ($("#texQuery").val() == undefined || $("#texQuery").val() == null || $("#texQuery").val().length == 0) {
            alert('请输入关键字搜索!');
            return;
        }
    }
    if (appConfigQueryType == null || appConfigQueryType == undefined) {
        alert('请先选择查询类型!');
        return;
    }
    isQuery=true;//设置当前搜索状态
    var searchURL = null;
    //var searchCountAction = null; //查询和统计结果分开的情况   
    showTips('数据加载中，请稍候...');
    $("#shijiliebiao").html("共找到<span style=\"color:#FF0000\"><img src=\""+urls.msUrl+"/images/icon/loading.gif\" style=\"height=10px;width=10px;\"/></span>条结果  <span style=\"float:inherit\"></span>");
    openResults(); //左侧内容； 
	var self = this;
	var searchURL = null; 
	var paramsJson =queryFrameCondition(self.searchType,self.pagenum);//获得查询的条件
	//alert(paramsJson);
	searchURL=queryFrameSearchType(self.searchType);
    //清除查询结果数据
	try{
		self.removeMarkers();		
	}catch(e){};
	
	$.ajax( {
		method : "post",
		dataType : "json",
		url : searchURL,//请求地址
		data : paramsJson,
		success : function(message) {
			self.queryResultCall(message);
			closeTips();
			isComplete = true;
			currentLayer.push(self);
		},
		error : function(XMLHttpRequest, textStatus, errorThrown) {
			alert(textStatus);
			closeTips();
			isComplete = true;
		}
	});
}
/**
 * 为分页按钮添加事件处理
 */

QueryFrame.prototype.addPagingListener = function() {
	var self = this;
	if(self.totalNum<=pageSize)
		return;
	if ($('#go2Qeury') != null) {
		$('#go2Qeury').bind('click', function() {
			self.showModeDiv();
		});

	}
	if ($('#viewQuery_paging_up') != null) {
		$('#viewQuery_paging_up').bind('click', function() {
			//alert("请求上一页");
				self.pagenum = self.pagenum - 1;
				self.getPagingData();
			});

	}
	
		if ($('#viewQuery_paging_down') != null) {
			$('#viewQuery_paging_down').bind('click', function() {
				//alert("请求下一页");
					self.pagenum = self.pagenum + 1;
					self.getPagingData();
				});

		}
	
	for ( var i = this.page_start; i <= this.page_end; i++) {
		if ($('#viewQuery_paging_' + i) != null) {
			self.bindAction($('#viewQuery_paging_' + i), i);

		}

	}
}
/**
 * 对数据循环绑定事件
 * @param {} btn
 * @param {} index
 */
QueryFrame.prototype.bindAction = function(btn, index) {
	var self = this;
	btn.bind('click', function() {
		//alert("请求第" + index + "页数据");
			self.pagenum = index;
			self.getPagingData();
		});
}

/*
 进行地图marker 显示
 */
QueryFrame.prototype.showMarker = function() {
	var pagenum = this.pagenum; //当前页   
    var self=this;
	var jieguo_html = "共找到<span style=\"color:#FF0000\">"+this.totalNum+"</span>条结果  <span style=\"float:inherit\"></span>";
	if (!this.totalNum > 0) {
		       $(this.shijiliebiao).html(jieguo_html);
		       $(this.tanchuliebiao).append(this.lucene_msj_html);
		       return;
	} else {
		var resultHtml = "";
		var totalpage = this.totalNum % pageSize > 0 ? Math
				.floor(this.totalNum / pageSize) + 1
				: (this.totalNum / pageSize);
		//this.totalpage = totalpage;
		var curpageIndex = (pagenum - 1) * pageSize + 1;
		//$(this.shijiliebiao).html(jieguo_html);
		if (this.indexPlaceArray.length <= 0) {
			$(this.tanchuliebiao).html(this.lucene_msj_html);
			return;
		}
		$(this.tanchuliebiao).html("");
		//组装marker数据
		queryFrameMarkers(self);//左侧

		// 画marker
		self.drawMarkers(1);//描点		 
			$(self.tanchuliebiao).append(this.getPagingHTML());
			//注册分页事件
			self.addPagingListener();
		//this.addGoBackListener();
		this.callBack();
	}
}
// 分析查询结果
QueryFrame.prototype.queryResultCall = function(message) {

	 
	var self = this;
	self.indexPlaceArray = new Array();
	self.indeximgMarkers = new Array();
	self.indeximgmarkersHTML = new Array();
	self.indexTitleArray = new Array();
	if(self.isAddLayer==false)
	{
		sysclear();
	}
	 
	self.lucene_html_result = "";
	var jsonData = message;
	var rel = 0;
	if (jsonData == null) {
		$(self.shijiliebiao).html(self.lucene_msj_html);
		return;
	}
	var total;
	 var total = jsonData.totalCount;
	 if(jsonData.pageSize !=null && jsonData.pageSize != "" ){
		 pageSize = jsonData.pageSize;	 
	 }else{
		 pageSize = 10;
	 }
     if (!total || typeof (total) == "underfined" || total == 0 || total == "0" || total == "null") {
         //alert("查询无结果！");

         var jieguo_html = "共找到<span style=\"color:#FF0000\">0</span>条结果  <span style=\"float:inherit\"></span>";
         $(self.shijiliebiao).html(jieguo_html);
           
         return;
     }
     else
     {
    	 var jieguo_html = "共找到<span style=\"color:#FF0000\">"+total+"</span>条结果  <span style=\"float:inherit\"></span>";
         $(self.shijiliebiao).html(jieguo_html);
         
     }

	self.totalNum = total;

	var data = jsonData.data;

	//var pointArray_qwjs = new Array();
	if (data != null && data != "null" && data.length>0) {
		//初始化model对象的数据
		queryFramePoints(self,data);
		//var mapZoomLevel = _MapApp.getZoomLevel(); 
		//if (pointArray_qwjs.length > 2) {
			//临时屏蔽
		//	var polygon = new Polygon(pointArray_qwjs, "green", 1, 0.8, "green");
		//	var queryMbr = polygon.getMBR();
			////            self.mapObject.centerAtMBR(queryMbr.minX, queryMbr.minY, queryMbr.maxX, queryMbr.maxY);
			////self.mapObject.centerAtLatLng(polygon.getMBR().getCenterPoint());
			////self.mapObject.recenterOrPanToLatLng(pointArray_qwjs[0]);
		//} else {
			////self.mapObject.recenterOrPanToLatLng(pointArray_qwjs[0]);
		//}

		self.showMarker();
		//轨迹测试
		/*alert(guijiArr.length);
		alert(appConfigQueryType);
		alert($.inArray(appConfigQueryType, guijiArr));*/
		try {
			if(guijiQuery!=null && guijiQuery.length>0)
			{
			_MapApp.removeOverlay(guijiQuery);
			}
			
		} catch (e) {
			// TODO: handle exception
		}
		
		if ($.inArray(appConfigQueryType, guijiArr)>=0) {
            //alert(self.pointQueryArray);
		    var guijiLine = new Polyline(self.pointQueryArray, "green", 8, 1, 0);
		    guijiLine.setLineStyle("dashdot");
		    //_MapApp.addOverlay(guijiLine);
		    guijiQuery=guijiLine;
		 EzServerClient.GlobeFunction.displayDynamicPolyline(guijiQuery, "dashdot", _MapApp, 60, 50); //调用动态轨迹方法

		  }
	}
}