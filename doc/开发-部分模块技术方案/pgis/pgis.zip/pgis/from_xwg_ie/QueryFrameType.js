function queryFrameSearchType(searchType) {
	switch (searchType) {
	case dic.mlph://建筑物
	{
		return url_dic.mlph;
	}
	case dic.jyz://加油站
	{
		return url_dic.jyz;
	}
	case dic.jydw://警员定位
	{
		return url_dic.jydw;
	}
	case dic.jygj://警员轨迹
	{
		return url_dic.jygj;
	}
	case dic.dw://单位
	{
	return url_dic.dw;
	}
	case dic.bw://保卫
	{
	return url_dic.bw;
	}
	case dic.jwry://境外人员
	{
	return url_dic.jwry;
	}
	}
}