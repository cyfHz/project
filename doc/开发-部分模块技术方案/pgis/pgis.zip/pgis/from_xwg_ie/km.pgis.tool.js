function currentSY() {
    var mLine = _MapApp.getBoundsLatLng(); 
    return mLine.minX.toString() + "," + mLine.minY.toString() + "," + mLine.maxX.toString() + "," + mLine.maxY.toString();
}

