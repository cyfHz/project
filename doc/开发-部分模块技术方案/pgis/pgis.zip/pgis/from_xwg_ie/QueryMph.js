﻿
/* 
* 业务模版-业务门楼牌显示
* author dzs 2013.11.23 cao
* 
*/
QueryMph = function (mapObj, callBack) {
    if (!mapObj) {
        alert(typeof (mapObj) + "Not Map Object!");
        return;
    }
    this.mapObject = mapObj; //地图对象
    this.indexPlaceArray = new Array(); //用来存放获取的数据列表，进行数据的绑定
    this.indeximgMarkers = new Array(); //进行数据记录的图标集的存放
    this.indeximgmarkersHTML = new Array(); //进行数据记录的图标集的显示内容存放
    this.callBack = callBack;
    //this.queryType = appConfigOperType; //当前操作的业务种类
    this.totalNum = null; // 共多少条
    this.isDisplayMhp = false;
    this.syString = null;
}

QueryMph.prototype.getMapObject = function () {
    return this.mapObject;
}
QueryMph.prototype.setsyString = function (systring) {
    this.syString = systring;
}
//判断当前操作的业务是否是显示门楼牌号的业务功能
QueryMph.prototype.getDisplayMph = function () {
    var isdisplayMphIndex = false;
    for (var i = 0; i < appConfigDisplayMph.length; i++) {
        if (appConfigOperType == appConfigDisplayMph[i]) {
            isdisplayMphIndex = true;
            break;
        }
    }
    return isdisplayMphIndex;
}
//设置当前视野查询是否有效
QueryMph.prototype.setIsDisplayMhp = function (isDisplayMhp) {
    this.isDisplayMhp = isDisplayMhp;
}
//获取不同表示的不同图标（为组装maker是试用）
QueryMph.prototype.getImgMarkerIcon = function () {
    var imgAddr;
    var topOffset = 0;
    var leftOffset = 0;
    var height = 0;
    var width = 0;
    imgAddr = urls.msUrl + "/js/pgis/address.gif";
    height = 16;
    width = 16;
    topOffset = -4;
    leftOffset = 2; 
    var imgIcon = new Icon(); //PGIS地图图标类
    imgIcon.image = imgAddr;
    imgIcon.height = height;
    imgIcon.width = width;
    imgIcon.topOffset = topOffset;
    imgIcon.leftOffset = leftOffset;
    return imgIcon;
}
//组装maker并添加相应的监听事件
QueryMph.prototype.getImgMarker = function (point, index) {
    var self = this;
    var pInfo = self.indexPlaceArray[index];
    var imgMarkerIcon = this.getImgMarkerIcon(); // 获取Icon图标
    var titleinfo = "";
    titleinfo = pInfo.mph;
    var titleinfoBig = pInfo.mphmc;
    var title = new Title(titleinfo, 12, 8, "宋体", "#000", "#e4f2fc", "#fff", "1");
    imgMarker = new Marker(point, imgMarkerIcon, title);

    // 添加事件
    imgMarker.addListener("mouseover", function () {
        //鼠标滑过记录当前的信息
       // var dzmpInfo = self.indexPlaceArray[index];
       // DZID_MOUSEOVER = dzmpInfo.dzid;
        //alert(DZID_MOUSEOVER);

        //imgMarker.openInfoWindowHtml(titleinfoBig);
        //showTip(titleinfoBig);
 
    });
    imgMarker.addListener("mouseout", function () {
        //closeTip();
    });
    imgMarker.addListener("click", function(){
    	getFwjg(pInfo);
    	//self.queryCall(pInfo);
    	
    });

    return imgMarker;
}

/*******************地图标志 函数**************************************/
/**
*  将组装好的maker在地图上显示出来
*/
QueryMph.prototype.drawMarkers = function (index) {

    var map = this.mapObject;
    var markers = this.indeximgMarkers;
    var start = this.pageSize * (index - 1);
    var end = this.pageSize * index - 1;
    for (var i = 0; i < markers.length; i++) {
        //if (i >= start && i <= end) {
       //     continue;
       // }
        if (markers[i] != null) {
            map.addOverlay(markers[i], false);
        }
    }
    //for (var i = start; i <= end; i++) {
    //    if (markers[i] != null) {
    //        map.addOverlay(markers[i], false);
     //   }
    //}
}
//刪除地图上的maker
QueryMph.prototype.removeMarkers = function () {
    try {
        var map = this.mapObject;
        var markers = this.indeximgMarkers;
 
        for (var i = 0; i < markers.length; i++) {
             
            if (markers[i] != null) {
                map.removeOverlay(markers[i]);
            }
        }
    } catch (e) {
    	 
    }
    
   
}
/*
通过调用组装maker的方法将maker组装好
*/
QueryMph.prototype.showMarker = function () {
    this.imgmarkersHTML = new Array();
    
        if (this.indexPlaceArray.length <= 0) {
            return;
        }
        var controlStr = "";
       
        var reg = new RegExp("obperid", "g");
        for (var i = 0; i < this.indexPlaceArray.length; i++) {
            var p = this.indexPlaceArray[i];
            var showFiled = "";
            var mc = "";
            var dz = "";
            var obid = "";
            var dh = "";
            obid = p.dzid;
            var message = "<div class='queryResult'><p class='queryResultName'>"
					+ p.jzwmc
                    + "</p>"
					+ "<p class='queryResultAdd'>门牌详址:&nbsp;&nbsp;"
					+ p.mpxz
					+ "</p><p class='queryResultBtn'></p></div>";
            this.indeximgmarkersHTML[i] = message;
            var marker = this.getImgMarker(new Point(p.zbx, p.zby), i);
            this.indeximgMarkers[i] = marker;
        }
        // 画marker
        this.drawMarkers(1);
        //this.callBack();

     
}
//获取视野内建筑物信息（暂时未用到）
QueryMph.prototype.queryCall = function (message) {
    var self = this;
    var ywlsh = pInfo.dzid;
    if (this.isDisplayMhp || this.getDisplayMph()) {
        var randomStr = parseInt(10000 * Math.random()).toString();
        $.ajax({
            method: "post",
            dataType: "json",
            url: urls.msUrl + "/dzJzwjbxx/fwjg_Ajax.do",
            data: { "randoms": randomStr, "ywlsh": ywlsh}, //"key": strPoints
            success: function (messageMph) {
            	if(data.jzwflag){
                	$("#jzwid").val(messageMph.dzbm);
    				$("#zxdhzb2").val(messageMph.zxdhzb);
    				$("#zxdzzb2").val(messageMph.zxdzzb);
    				$("#jzwmc2").val(messageMph.jzwmc);
    				$("#dzmc2").val(messageMph.dzmc);
    				$("#edit-win2").dialog("open");
                }else if(!messageMph.jzwflag){
    				var jzwjgid = messageMph.jzwjgid;
    				window.open(urls.msUrl+"/dzJzwjbxx/fwjg.do?jzwid="+ywlsh+"&&jzwjgid="+jzwjgid,"title","height=1024px,width=1024px,scrollbars=no,status=no,menubar=no,scrollbars=no,resizable=yes,location=no");
    	        }
    			},
    			error: function (XMLHttpRequest, textStatus, errorThrown) {
    			    // 通常 textStatus 和 errorThrown 之中
    			    // 只有一个会包含信息
    			}
        });
    }
    
}
//获得门楼牌号的信息数据的方法
QueryMph.prototype.queryCallByCurrentSY = function (message) {
    var self = this;
        var randomStr = parseInt(10000 * Math.random()).toString();
        $.ajax({
            method: "post",
            dataType: "json",
            url: urls.msUrl + "/pgis_bzdzcj/selectInView.do",
            data: { "randoms": randomStr,"syString": this.syString }, //"key": strPoints，syString是获得当前视野坐标的传输的方法，真正的方法在toll.js中
            success: function (messageMph) {
                self.queryResultCall(messageMph.data);//将查询结果组装成js中的model
                self.setIsDisplayMhp(false);
            },
            error: function (XMLHttpRequest, textStatus, errorThrown) {
                 //alert(textStatus);
            }
        });
    
}
// 分析查询结果
QueryMph.prototype.queryResultCall = function (message) {
    var self = this;
    self.indexPlaceArray = new Array();
    self.indeximgMarkers = new Array();
    self.indeximgmarkersHTML = new Array();
    //searchDiv();
    
    //var total = jsonData.totalCount;
    //if (!total || typeof (total) == "underfined" || total == 0 || total == "0") {
    //    //alert("登录失败");
    //    return;
    //}
    //self.totalNum = total;
    var pointArray = new Array();
    $.each(message, function (i, a) {
        var zbx = "";
        var zby = "";
        var mc = "";
        var dz = "";
        var p = new mlphModel();
         
        p.dzid = a.ywlsh;
        p.mphdm = a.dzyslxdm;
        p.mphmc = a.qhnxxdz;
        p.mpxz = a.dzmc;
        p.mph = a.mlph;
        p.zbx = a.zxdhzb;
        p.zby = a.zxdzzb;
        p.jzwmc=a.jzwmc;
        self.indexPlaceArray.push(p); 
    });
    self.showMarker();//调用显示maker的方法
}