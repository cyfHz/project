var cxOrgan=function (jb,ssfj,sspcs,ssjwq) {
	if(jb==0){
		getOrganise('370100000000',"ssfj_cx",370100000000);
	}else if(jb==1){
		getOrganise('370100000000',"ssfj_cx",370100000000);
	}else if(jb==2){
		getOrganId(ssfj,"ssfj_cx",ssfj);
		$("#ssjwq_cx").combobox('clear');
		$("#ssjwq_cx").combobox('disable');
	$("#sspcs_cx").combobox('clear');
	var data = $("#ssfj_cx").combobox('getValues');
	getOrganise(ssfj,"sspcs_cx");
		//$('#ssfj').combobox('disable');
	}else if(jb==3){
		//$('#ssfj').combobox('disable');
		//$('#ssfj_cx').combobox('disable');
		//getOrganId(sspcs,"sspcs");
		getOrganId(ssfj,"ssfj_cx",ssfj);
		getOrganId(sspcs,"sspcs_cx",sspcs);
		
		$("#ssjwq_cx").combobox('clear');
		$("#ssjwq_cx").combobox('enable');
		getOrganise(sspcs,"ssjwq_cx");
	}else if(jb==4){
		getOrganId(ssfj,"ssfj_cx",ssfj);
		getOrganId(sspcs,"sspcs_cx",sspcs);
		getOrganId(ssjwq,"ssjwq_cx",ssjwq);
	}
}