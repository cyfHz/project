//获取当前视野信息  
function currentSY() {
    var mLine = _MapApp.getBoundsLatLng(); //此为视野的边框
    return mLine.minX.toString() + "," + mLine.minY.toString() + "," + mLine.maxX.toString() + "," + mLine.maxY.toString();
}
//根据元素ID获取元素
function getEleById(id) {
    return document.getElementById(id);
}
//搜索点击事件
function setQueryType(id,name) {
	appConfigQueryType = id;
	 //alert(appConfigQueryType);
    $("#spanQueryValue").html(name);
    $("#QueryTool").css("display", "none");
}
//设置是否视野内搜索
function setisSY() {
    if ($("#isSY").attr("checked") == "checked") {
        isSY = true;
    }
    else {
        isSY = false;
    }
}
//左侧查询结果
function openResults() {
    var L = document.getElementById("left"); // 变量：L代表 id="left" 的标记
    L.className = "resultsnavsx"; // 给 id="left" 的标记 加上class：resultsnavleft（显示）
    $("#slip_ctrl_1").attr("src", urls.msUrl+"/images/lmenui.gif");
}
function showResults() {
    var L = document.getElementById("left"); // 变量：L代表 id="left" 的标记
    if (L.className == "resultsnavzc") // 判断：如果 id="left" 的class值 等于隐藏，将执行下面{}里面的内容
    {
        L.className = "resultsnavsx"; // 给 id="left" 的标记 加上class：resultsnavleft（显示）
        $("#slip_ctrl_1").attr("src", urls.msUrl+"/images/lmenui.gif");
    }
    else // 判断：如果 id="left" 的class值 不等于left的话，将执行下面{}里面的内容
    {
        L.className = "resultsnavzc"; // 给 id="left" 的标记 加上class：resultsnavleft1（隐藏）
        $("#slip_ctrl_1").attr("src", urls.msUrl+"/images/lmenuo.gif");
    }
}
/**
*显示提示
* @param innerMsg 提示内容
* @param timer 时间
*/
function showTips(innerMsg, timer, type) {
    var top = (document.documentElement.offsetHeight - 50) / 2;
    var left = (document.documentElement.offsetWidth - 120) / 2;
    var imgArray = new Array("", urls.msUrl+"/images/loading.gif", urls.msUrl+"/images/icon/ok.gif");
    if (!document.getElementById("tips")) {
        var tips = document.createElement("div");
        tips.id = "tips";
        tips.name = "tips";
        tips.style.width = 100;
        tips.style.height = 30;
        tips.style.filter = "alpha(opacity=90)";
        tips.style.position = "relative";
        tips.style.left = left;
        if (arguments.length != 2) {
            tips.style.top = top;
        } else {
            tips.style.top = top + 150;
        }

        tips.style.position = "absolute";
        tips.style.background = "#F5E5B9";
        tips.style.zIndex = "9999";
        tips.style.cursor = "default";
        tips.style.border = "1px solid #015190";
        tips.innerHTML = "<table style='border:0px;cellspacing:0px;cellpadding:0px; font-size:13px;'><tr><td align='center' v-align='middle'><img src='" + imgArray[arguments.length] + "' style='width:20px;height:20px;'></td><td align='center' nowrap>" + innerMsg + "</td></tr></table>";
        document.body.appendChild(tips);
    } else {
        var tipobj = document.getElementById("tips");
        tipobj.style.left = left;
        tipobj.style.top = top;
    }
    if (arguments.length > 1) {
        window.setTimeout(closeTips, timer * 1000);
    }
}
//隐藏提示
function closeTips() {
    if (document.getElementById("tips")) {
        document.body.removeChild(document.getElementById("tips"));
    }
}
//门楼牌图层的显示控制
function showMlphLayer() {
	var newCenterPoint = _MapApp.getCenterLatLng();
	var newzoomLevel=_MapApp.getZoomLevel();
	//判断当前视野是否改变
	 if (oldCenterPoint.x == newCenterPoint.x && oldCenterPoint.y == newCenterPoint.y && newzoomLevel==oldzoomLevel) {
         return;
     } else {
    	 //视野改变，原来的新视野就是现在的旧视野
         oldCenterPoint = newCenterPoint;
         oldzoomLevel=newzoomLevel;
     }
	 try {
		    //视野改变，先删除原来视野中的图标
			queryMph.removeMarkers();
			
		} catch (e) {
			
		}
		
   //如果是查询模式下，不显示小房子，只显示查询模式下的红色图标，因此不加载下面的方法
	if (isQuery == true) {
		return;
	}
	nowLevel = _MapApp.getZoomLevel();
	nowView = currentSY();//获得当前视野两个极致点
	//如果当前视野小于15，则不显示小房子
	if (nowLevel > 13) {
		//清除新建标注图层
		if(newMarkerLayer!=null && typeof newMarkerLayer !=undefined)
		{
			for(var i=0;i<newMarkerLayer.length;i++)
			{
				try {
					_MapApp.removeOverlay(newMarkerLayer[i]);
				} catch (e) {
					// TODO: handle exception
				}
				
			}
			newMarkerLayer=new Array();
		}
		queryMph.setsyString(nowView);
		queryMph.queryCallByCurrentSY();
		
	} else {
		 
	}
}
//清除痕迹 搜索用 obj备选参数
function sysclearAll(obj)
{
	//将原有坐标重置
	oldzoomLevel=0;
	//设置搜索控制位
	isQuery=false;
	//清除左侧搜索结果
	$("#shijiliebiao").html("");
	$("#tanchuliebiao").html("");
	//清除搜索图层
	
	if(currentLayer!=null && typeof currentLayer !=undefined)
	{
		
		for(var i=0;i<currentLayer.length;i++)
		{
			try{
			currentLayer[i].removeMarkers();
			}catch(e)
			{}
		}
		currentLayer=new Array();
	}
	//清除新建标注图层
	if(newMarkerLayer!=null && typeof newMarkerLayer !=undefined)
	{
		for(var i=0;i<newMarkerLayer.length;i++)
		{
			try {
				_MapApp.removeOverlay(newMarkerLayer[i]);
			} catch (e) {
				// TODO: handle exception
			}
			
		}
		newMarkerLayer=new Array();
	}
	//清除轨迹
	try {
		 
		 
			_MapApp.removeOverlay(guijiQuery);
		 
	} catch (e) {
		// TODO: handle exception
		 
	}
	//缩起左侧
	showResults();
	//加载门楼牌
	 showMlphLayer(); 
	
}
//清除图层 obj备选参数
function sysclear(obj)
{
	//清除搜索图层
	if(currentLayer!=null && typeof currentLayer !=undefined)
	{
		for(var i=0;i<currentLayer.length;i++)
		{
			currentLayer[i].removeMarkers();
		}
		currentLayer=new Array();
	}
	//清除新建标注图层
	if(newMarkerLayer!=null && typeof newMarkerLayer !=undefined)
	{
		for(var i=0;i<newMarkerLayer.length;i++)
		{
			try {
				_MapApp.removeOverlay(k[i]);
			} catch (e) {
				// TODO: handle exception
			}
			
		}
		newMarkerLayer=new Array();
	}
	//清除左侧搜索结果
	//清除轨迹
	try {
		 
		 
			_MapApp.removeOverlay(guijiQuery);
		 
	} catch (e) {
		// TODO: handle exception
		 
	}
}
// 搜索
function searchALL() {
	//清除左侧搜索结果
	$("#shijiliebiao").html("");
	$("#tanchuliebiao").html("");
    //清空建筑物图层
	try {
		queryMph.removeMarkers();
	} catch (e) {
	}
	sysclear();//清除点
	oldsyString = currentSY();
    queryFrame = new QueryFrame(_MapApp, openResults);
    queryFrame.pagenum=1;
    queryFrame.getPagingData(); 
}
function getFwjg(pInfo){
	   var ywlsh = pInfo.dzid;
	   //alert("ywlsh="+ywlsh);
	   $.ajax({
        method: "post",
        dataType: "json",
        url: urls.msUrl+"/dzJzwjbxx/fwjg_Ajax.do",
        data:"ywlsh="+ywlsh,
        success: function (data) {
        	if(data.jzwflag){
            	$("#jzwid").val(data.data.dzbm);
				$("#zxdhzb2").val(data.data.zxdhzb);
				$("#zxdzzb2").val(data.data.zxdzzb);
				$("#jzwmc2").val(data.data.jzwmc);
				$("#dzmc2").val(data.data.dzmc);
				$("#edit-win2").dialog("open");
            }else if(!data.jzwflag){
				var jzwjgid = data.jzwjgid;
				window.open(urls.msUrl+'/dzJzwjbxx/fwjg.do?jzwid='+ywlsh+'&&jzwjgid='+jzwjgid,'title','height=1024px,width=1024px,scrollbars=no,status=no,menubar=no,scrollbars=no,resizable=yes,location=no');
	        }
			},
			error: function (XMLHttpRequest, textStatus, errorThrown) {
			    // 通常 textStatus 和 errorThrown 之中
			    // 只有一个会包含信息
			}
    });

    }
function updateFwjg(pInfo){
	   var ywlsh = pInfo.dzid;
	   $.ajax({
     method: "post",
     dataType: "json",
     url: urls.msUrl+"/dzMlph/getId.do",
     data:"id="+ywlsh,
     success: function (data) {
    	 $("#sszdyjxzqy_mc").val(data.data.sszdyjxzqy_mc);
    	 $("#sszdyjxzqy_dzbm").val(data.data.sszdyjxzqy_dzbm);
    	 $("#ssjlxxq_dzbm").val(data.data.ssjlxxq_dzbm);
    	 //$("#ssjlxxq_jlxxqmc").combobox("setValue",data.data.ssjlxxq_jlxxqmc);
    	 $("#id").val(ywlsh);
    	 $("#mlph").val(data.data.mlph);
    	 $("#jzwmc").val(data.data.jzwmc);
    	 $("#dzmc").val(data.data.dzmc);
    	 $("#sqrxm").val(data.data.sqrxm);
    	 $("#sqrlxdh").val(data.data.sqrlxdh);
    	 $("#sqdwmc").val(data.data.sqdwmc);
    	 $("#sqdwlxdh").val(data.data.sqdwlxdh);
    	 $("#sqrgmsfzhm").val(data.data.sqrgmsfzhm);
    	 $("#lsmlpbs").val(data.data.lsmlpbs);
    	 $("#zxdhzb").val(data.data.zxdhzb);
		 $("#zxdzzb").val(data.data.zxdzzb);
    	 $("#editFormz").show();
    	 $("#edit-winz").dialog("open");
			},
			error: function (XMLHttpRequest, textStatus, errorThrown) {
			    // 通常 textStatus 和 errorThrown 之中
			    // 只有一个会包含信息
			}
 });
}
function deleteMlph(pInfo) {
	var id =  pInfo.dzid;
	$.messager.confirm('确认','您确认想要注销记录吗？',function(r){    
	    if (r){    
	    	$.ajax({
	            method: "post",
	            dataType: "json",
	            url: urls.msUrl+"/dzMlph/delete.do",
	            data:"id="+id,
	            success: function (data) {
	            	$("#edit-winz").dialog('close');
	    			$.messager.alert('提示', '注销成功');
	    			isSY = true;
	    			searchALL();
	    			
	    			},
	    			error: function (XMLHttpRequest, textStatus, errorThrown) {
	    			    // 通常 textStatus 和 errorThrown 之中
	    			    // 只有一个会包含信息
	    			}
	        });
	    }    
	});
	
}
function getJwryDetail(pInfo){
	var jwryid = pInfo.id;
	$.ajax({
        method: "post",
        dataType: "json",
        url: urls.msUrl+"/sySyjwry/getId.do",
        data:"id="+jwryid,
        success: function (data) {
        	$('#jwryzp_lbl,#zp_hide,#img_zp').attr({"src":"../sySyjwry/getImgZp.do?id="+data.data.id});
			/* $('#jwryzp_lbl').width('10%');
			$('#jwryzp_lbl').height('10%'); */
			//alert($('#jwryzp_lbl').width()+"------"+$('#jwryzp_lbl').height());
			$("#jwryid_lbl").html(data.data.jwryid);
			$("#ywm_lbl").html(data.data.ywm);
			$("#zwm_lbl").html(data.data.zwm);
			$("#csrq_lbl").html(data.data.csrq);
			$("#gj_lbl").html(data.data.gj);
			$("#zy_lbl").html(data.data.zy);
			$("#zhgzjgmc_lbl").html(data.data.zhgzjgmc);
			$("#zhgzjgdm_lbl").html(data.data.zhgzjgdm);
			$("#zjzl_lbl").html(data.data.zjzl);
			$("#zjhm_lbl").html(data.data.zjhm);
			$("#qzzl_lbl").html(data.data.qzzl);
			$("#qzbh_lbl").html(data.data.qzbh);
			$("#tlyxq_lbl").html(data.data.tlyxq);
			$("#jwrylxdh_lbl").html(data.data.jwrylxdh);
			$("#ssxqdm_lbl").html(data.data.ssxqdm);
			$("#ssjlxxq_dzbm_lbl").html(data.data.ssjlxxq_dzbm);
			$("#dzbm_lbl").html(data.data.dzbm);
			$("#fjbm_lbl").html(data.data.fjbm);
			$("#fjh_lbl").html(data.data.fjh);
			$("#xxdz_lbl").html(data.data.xxdz);
			$("#fwfzxm_lbl").html(data.data.fwfzxm);
			$("#fzsfzh_lbl").html(data.data.fzsfzh);
			$("#jwrylkrq_lbl").html(data.data.jwrylkrq);
			$("#bz_lbl").html(data.data.bz);
			$("#sdpcs_lbl").html(data.data.sdpcs);
			$("#jwzrq_lbl").html(data.data.jwzrq);
			$("#zxzt_lbl").html(data.data.zxzt);
			$("#zxrq_lbl").html(data.data.zxrq);
			$("#deltag_lbl").html(data.data.deltag);
			$("#deltime_lbl").html(data.data.deltime);
			$("#djr_lbl").html(data.data.djr);
			$("#djdw_lbl").html(data.data.djdw);
			$("#djrmc_lbl").html(data.data.djrmc);
			$("#djdwmc_lbl").html(data.data.djdwmc);
			$("#djsj_lbl").html(data.data.djsj);
			$("#xgr_lbl").html(data.data.xgr);
			$("#xgdw_lbl").html(data.data.xgdw);
			$("#xgrmc_lbl").html(data.data.xgrmc);
			$("#xgdwmc_lbl").html(data.data.xgdwmc);
			$("#gxsj_lbl").html(data.data.gxsj);
			$("#movesign_lbl").html(data.data.movesign);
			$("#sbid_lbl").html(data.data.sbid);
			$("#lrjs_lbl").html(data.data.lrjs);
			$("#lrfs_lbl").html(data.data.lrfs);
			$("#lrwl_lbl").html(data.data.lrwl);
			$("#xzzqh_lbl").html(data.data.xzzqh_dic);
			$("#ywx_lbl").html(data.data.ywx);
			$("#xzzssfjdm_lbl").html(data.data.xzzssfjdm);
			$("#rylb_lbl").html(data.data.rylb);
			$("#gjdm_lbl").html(data.data.gjdm);
			$("#xzzhuid_lbl").html(data.data.xzzhuid);
			$("#cjry_lbl").html(data.data.cjry);
			$("#cjsj_lbl").html(data.data.cjsj);
			$("#rkfl_lbl").html(data.data.rkfl);
			$("#lhsf_lbl").html(data.data.lhsf);
			$("#zwsp_lbl").html(data.data.zwsp);
			$("#rjka_lbl").html(data.data.rjka);
			$("#rjrq_lbl").html(data.data.rjrq);
			$("#qzcs_lbl").html(data.data.qzcs);
			$("#jlqk_lbl").html(data.data.jlqk);
			$("#jlxkhm_lbl").html(data.data.jlxkhm);
			$("#jlsy_lbl").html(data.data.jlsy);
			$("#qfjg_lbl").html(data.data.qfjg);
			$("#gzxxsf_lbl").html(data.data.gzxxsf);
			$("#rzrq_lbl").html(data.data.rzrq);
			$("#lzrq_lbl").html(data.data.lzrq);
			$("#rzfs_lbl").html(data.data.rzfs);
			$("#rzsj_lbl").html(data.data.rzsj);
			$("#zslxfs_lbl").html(data.data.zslxfs);
			$("#jzdxz_lbl").html(data.data.jzdxz);
			$("#sxryqsgx1_lbl").html(data.data.sxryqsgx1);
			$("#sxryzwxm1_lbl").html(data.data.sxryzwxm1);
			$("#sxryywxm1_lbl").html(data.data.sxryywxm1);
			$("#sxryxb1_lbl").html(data.data.sxryxb1);
			$("#sxrycsrq1_lbl").html(data.data.sxrycsrq1);
			$("#sxrydwmc1_lbl").html(data.data.sxrydwmc1);
			$("#sxryqsgx2_lbl").html(data.data.sxryqsgx2);
			$("#sxryzwxm2_lbl").html(data.data.sxryzwxm2);
			$("#sxryywxm2_lbl").html(data.data.sxryywxm2);
			$("#sxryxb2_lbl").html(data.data.sxryxb2);
			$("#sxrycsrq2_lbl").html(data.data.sxrycsrq2);
			$("#sxrydwmc2_lbl").html(data.data.sxrydwmc2);
			$("#cjrylxdh_lbl").html(data.data.cjrylxdh);
			//$("#jwryzp_lbl").html(data.data.jwryzp);
			$("#tjflg_lbl").html(data.data.tjflg);
			$("#xzzhuidgxsj_lbl").html(data.data.xzzhuidgxsj);
			getJwryDic(data.data.gj,"gj_lbl","gj",true);
			getJwryDic(data.data.zjzl,"zjzl_lbl","zjlx",true);
			getJwryDic(data.data.qzzl,"qzzl_lbl","qzzl",true);
			getJwryDic(data.data.jlqk,"jlqk_lbl","jwry_jlqk",true);
			getJwryDic(data.data.rzfs,"rzfs_lbl","jwry_rzfs",true);
			getJwryDic(data.data.jzdxz,"jzdxz_lbl","jwry_jzdxz",true);
			$('#jwrydetail').dialog('open');
			},
			error: function (XMLHttpRequest, textStatus, errorThrown) {
			    // 通常 textStatus 和 errorThrown 之中
			    // 只有一个会包含信息
			}
    });
}

function getJwryDic(showdata,showid,type_code,detail){

	var pram = "type_code="+type_code ;
	if(detail){
		pram=pram+"&dict_code="+showdata
	}
	
	$.ajax({
		url:"../appDictionary/dataList.do?rows=300",
		data:pram,
		dataType:"json",
		type:"post",
		asyn:false,
		success:function(data){
	  		if(detail){
	  			if(data.rows[0])
	  			$("#"+showid).html(data.rows[0].dict_mc)
		  	}else{
	  			$("#"+showid).combobox({
	  				valueField:'dict_code',    
	  				textField:'dict_mc',
	  				editable:false,
	  				data:data.rows
	  			})
	  			$("#"+showid).combobox("setValue",showdata)
			}
		},
		error:function(){		
		}
	})
}
