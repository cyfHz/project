function valiForm() {
	var valiFlag = false;
	// * Email正则表达式
	/**
	 * this可以指向每个遍历的对象，属性可以用this.属性名来获取
	 */
	// $(".email").each(function(index){
	// });
	var regMail = new RegExp(/^[A-Z0-9a-z._]+@[\w]+\.[a-zA-z]{2,6}$/);
	valiFlag = $.each($(".email"), function(index, object) {
		var required = false;
		if (object.required == "true" || object.required == true) {
			required = true;
		}
		if (!required && object.value.length == 0) {
			return true;
		}
		// alert(this.value.length);
		if (!regMail.test(object.value)) {
			$(this).gips({
				'theme' : 'red',
				autoHide : false,
				text : '常用电子邮件格式不正确',
				placement : 'right',
				msg : true
			});
			return false;
		}
		return true;
	})

	// * 手机号码正则
	var regMobile = new RegExp(/^[0-9]{11}$/);
	valiFlag = $.each($(".mobile"), function(index, object) {
		var required = false;
		if (object.required == "true" || object.required == true) {
			required = true;
		}
		if (!required && object.value.length == 0) {
			return true;
		}
		// alert(this.value.length);
		if (!regMobile.test(object.value)) {
			$(this).gips({
				'theme' : 'redd',
				autoHide : false,
				text : '手机号码长度或格式不正确',
				placement : 'right',
				msg : true
			});
			return false;
		}
		return true;
	})

	// * 固定电话正则
	var regTel = new RegExp(/^[0-9]{3,4}-[0-9]{7,8}$/);
	valiFlag = $.each($(".tel"), function(index, object) {
		var required = false;
		if (object.required == "true" || object.required == true) {
			required = true;
		}
		if (!required && object.value.length == 0) {
			return true;
		}
		// alert(this.value.length);
		if (!regTel.test(object.value)) {
			$(this).gips({
				'theme' : 'red',
				autoHide : false,
				text : '固定电话输入不正确<br/>格式：010-82201454',
				placement : 'right',
				msg : true
			});
			return false;
		}
		return true;
	})

	// * 身份证号正则
	if ($(".idcard").length > 0) {
		valiFlag = validId($(".idcard"));
	}
	return valiFlag;
}
//扩展easyui表单的验证
$.extend($.fn.validatebox.defaults.rules, {
    //验证汉子
    CHS: {
        validator: function (value) {
            return /^[\u0391-\uFFE5]+$/.test(value);
        },
        message: '只能输入汉字'
    },
    //移动手机号码验证
    mobile: {//value值为文本框中的值
        validator: function (value) {
            var reg = /^1[3|4|5|8|9]\d{9}$/;
            return reg.test(value);
        },
        message: '输入手机号码格式不准确.'
    },
    //国内邮编验证
    zipcode: {
        validator: function (value) {
            var reg = /^[1-9]\d{5}$/;
            return reg.test(value);
        },
        message: '邮编必须是非0开始的6位数字.'
    },
    //用户账号验证(只能包括 _ 数字 字母) 
    account: {//param的值为[]中值
        validator: function (value, param) {
            if (value.length < param[0] || value.length > param[1]) {
                $.fn.validatebox.defaults.rules.account.message = '用户名长度必须在' + param[0] + '至' + param[1] + '范围';
                return false;
            } else {
                if (!/^[\w]+$/.test(value)) {
                    $.fn.validatebox.defaults.rules.account.message = '用户名只能数字、字母、下划线组成.';
                    return false;
                } else {
                    return true;
                }
            }
        }, message: ''
    }
})