



	<html xmlns:v="urn:schemas-microsoft-com:vml">
	<head>
		<style type="text/css">
        v\:*
        {
            behavior: url(#default#VML);
        }
    </style> 
    <!--[if gte IE 8]> 
    <script type="text/javascript">
        document.namespaces.add('vml', 'urn:schemas-microsoft-com:vml');
        document.createStyleSheet().cssText =
            'vml\\:fill, vml\\:path, vml\\:shape, vml\\:stroke' +
                '{ behavior:url(#default#VML); } ';
    </script>
    <![endif]-->
		
		<meta http-equiv="content-type" content="text/html; charset=utf-8" />
		<!-- <META HTTP-EQUIV="imagetoolbar" CONTENT="no">-->
		<title class="title">标准地址采集</title>

		<!-- 公共资源CSS,JS  -->
		<!--Css -->
		<link rel="stylesheet" type="text/css" href="http://zacloud.pcp.sd:80/js/jquery-easyui-1.3.2/themes/default/easyui.css">
		<link rel="stylesheet" type="text/css" href="http://zacloud.pcp.sd:80/js/jquery-easyui-1.3.2/themes/icon.css">
		<link rel="stylesheet" type="text/css"
			href="http://zaCloud.pcp.sd:80/css/base.css">
		<link rel="stylesheet" type="text/css"
			href="http://zaCloud.pcp.sd:80/css/jsp_form.css">
		<link rel="stylesheet" type="text/css"
			href="http://zaCloud.pcp.sd:80/css/gips.css">
		<!-- ** Javascript ** -->
		<script type="text/javascript"
			src="http://zaCloud.pcp.sd:80/js/commons/jquery.min.js"></script>
		<script type="text/javascript"
			src="http://zaCloud.pcp.sd:80/js/commons/jquery.form.js"></script>
		<script type="text/javascript"
			src="http://zaCloud.pcp.sd:80/js/commons/package.js"></script>
		<script type="text/javascript" src="http://zacloud.pcp.sd:80/js/jquery-easyui-1.3.2/jquery.easyui.min.js"></script>
		<script type="text/javascript"
			src="http://zaCloud.pcp.sd:80/js/commons/urls.js?v=11"></script>
		 <script type="text/javascript" src="http://zaCloud.pcp.sd:80/js/pgis/point.js"></script>
		<script type="text/javascript"
			src="http://zaCloud.pcp.sd:80/js/commons/base.js?v=11"></script>
		<script type="text/javascript"
			src="http://zaCloud.pcp.sd:80/js/commons/YDataGrid.js"></script>
		<script type="text/javascript"
			src="http://zaCloud.pcp.sd:80/js/commons/oldCompareNew.js"></script>
		<script type="text/javascript" src="http://zacloud.pcp.sd:80/js/jquery-easyui-1.3.2/locale/easyui-lang-zh_CN.js"></script>
		<script type="text/javascript" src="http://zaCloud.pcp.sd:80/js/commons/tips.js"></script>
		<script type="text/javascript"
			src="http://zaCloud.pcp.sd:80/js/commons/vali_IDCard.js"></script>
		<script type="text/javascript"
			src="http://zaCloud.pcp.sd:80/js/commons/validForm.js"></script>
		<script type="text/javascript"
			src="http://zaCloud.pcp.sd:80/js/commons/tjOrganization.js"></script>
		<script type="text/javascript"
			src="http://zaCloud.pcp.sd:80/js/commons/cxOrganization.js"></script>
		<script type="text/javascript"
			src="http://zaCloud.pcp.sd:80/js/commons/validateIDCard.js"></script>
		<script type="text/javascript" charset="GB2312" 
			src="http://10.48.1.227:9080/TileMap/js/EzMapAPI.js"></script>
		<script type="text/javascript"
			src="http://zaCloud.pcp.sd:80/js/pgis/ddsmoothmenu.js"></script>
		<script type="text/javascript" src="http://zaCloud.pcp.sd:80/js/commons/base.js"></script>
		<script type="text/javascript"
			src="http://zaCloud.pcp.sd:80/js/pgis/jquery.contextmenu.r2.js"></script>
		<link href="http://zaCloud.pcp.sd:80/js/pgis/ddsmoothmenu-v.css"
			rel="stylesheet" type="text/css" />
		<link href="http://zaCloud.pcp.sd:80/js/pgis/ddsmoothmenu.css" rel="stylesheet"
			type="text/css" />
			<script type="text/javascript"
			src="http://zaCloud.pcp.sd:80/js/pgis/query/dicType.js"></script>
			<script type="text/javascript"
            src="http://zaCloud.pcp.sd:80/js/pgis/query/guiji.js"></script>
			 <script type="text/javascript"
			src="http://zaCloud.pcp.sd:80/js/pgis/query/tool.js"></script>
			<script type="text/javascript"
			src="http://zaCloud.pcp.sd:80/js/pgis/query/model/QueryModel.js"></script>
				<script type="text/javascript"
			src="http://zaCloud.pcp.sd:80/js/pgis/query/QueryMph.js"></script>
            <script type="text/javascript"
			src="http://zaCloud.pcp.sd:80/js/pgis/query/QueryFrame.js"></script>
			<script type="text/javascript"
			src="http://zaCloud.pcp.sd:80/js/pgis/query/QueryFrameType.js"></script>
			<script type="text/javascript"
			src="http://zaCloud.pcp.sd:80/js/pgis/query/QueryFrameCondition.js"></script>
			<script type="text/javascript"
			src="http://zaCloud.pcp.sd:80/js/pgis/query/QueryFramePoints.js"></script>
			<script type="text/javascript"
			src="http://zaCloud.pcp.sd:80/js/pgis/query/QueryFrameMarkers.js"></script>
		 <script type="text/javascript"
			src="http://zaCloud.pcp.sd:80/js/pgis/query/global.js"></script>
					 <script type="text/javascript"
			src="http://zaCloud.pcp.sd:80/js/pgis/pgisInit.js"></script>
		<script reload="true" id="www" type="text/javascript"> 
 	
	 var hengZBArr=new Array();//横坐标
	 var zongZBArr=new Array();//纵坐标
	 var jzwmcarr=new Array();//建筑物名称
	 var ssjzwbmarr=new Array();//所属建筑物编码
	 var mlparr=new Array();//门楼牌bean
	 var ywlsharr=new Array();//每楼牌号主键业务流水号
	 var zuobiaoArray=new Array();//警务区坐标集合 （一个用户可能属于多个警务区）
	 var jwqIdArray=new Array();//警务区ID集合
	 var jwqNameArray=new Array();//警务区名称集合
	 var jwqCenterPointX=new Array();//警务区中心点的X坐标
	 var jwqCenterPointY=new Array();//警务区中心点的Y坐标
	 var childZuobiao=new Array();//分局所属警务区的坐标集合
	 var childMc=new Array();//分局所属警务区的名称集合
	 var childId=new Array();//分局所属警务区id集合
	 var childCenterPointX=new Array();//分局所属警务区的中心点X坐标
	 var childCenterPointY=new Array();//分局所属警务区的中心点Y坐标
	 var myName="山东省公安厅";//分局名称
	 var myZuobiao = new Array();
	 var myCenterPointX = new Array();
	 var myCenterPointY = new Array();
	 //var myCenterPointX="[F@39567531";//分局中心点X坐标
	// var myCenterPointY="[F@5b28015f";//分局中心点Y坐标
	 var myId = "370000000000";//分局Id
	 var queryFrame=null;
	 var queryMph=null;
var	addr = '山东省';
var qhdz = "";
var mlph = "";
var jzwmc = "";
$(function(){
	$("#dzmc").val(addr);
	$("#mlph").change(function(){
		/* var validText = /^[1-9]{1}[0-9]{0,5}$/i.test($("#mlph").val());
		if(!validText){
			$.messager.alert('提示','请填写五位以内的有效整数');  
			$("#mlph").val("");
			$("#mlph").focus();
		} */
		mlph = $("#mlph").val().length>0?$("#mlph").val():'';
		jzwmc = mlph+$('#mlphlxmc').val();
		$("#jzwmc").val(jzwmc);
		$("#qhnxxdz").val(qhdz+jzwmc);
		$("#dzmc").val(addr + qhdz + jzwmc);
	});
	$("#jzwmc").change(function(){
		jzwmc = $("#jzwmc").val();
		$("#dzmc").val(addr + qhdz + jzwmc);
		$("#qhnxxdz").val(qhdz+jzwmc);
	});
})

</script>

	</head>
	<body>
		
		<div id="rightButtonMenu" class="ddsmoothmenu-v"
			style="position: relative; margin-bottom: 1px; display: none;">
			<ul>
				<li>
					<a onclick=show1()>标准地址采集</a>
				</li>
			</ul>
			<br style="clear: left" />
		</div>
		<div id="approlefun-win" class="easyui-dialog" title=""
			data-options="closed:true,iconCls:'icon-edit',modal:true"
			style="width: 400px; height: 200px;">
			<form id="roleFunForm" class="ui-form" method="post" action="">
				<!-- <input class="hidden" type="text" name="bkid" > -->
				<!--<table cellpadding="0" cellspacing="0" class="et">
					<tr>
						<td>
							<input id="" type="hidden"  value="mouseY" />
						</td>
						<td>
							<input type="text" value="mouseX" />
						</td>
					</tr>
				</table>-->
			</form>
		</div>
		<table style="width: 100%; height: 100%;">
			<tr>
				<td style="width: *; height: 600px; border: 2px solid #FF0000">
					<div id="mymap"
						style="width: 100%; margin-top:50px; height: 100%; border: 0px solid #FF0000;"></div>
				</td>
			</tr>
			<div region="center" border="false" display="true">
				<table id="data-list"></table>
			</div>
			


<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<body>
	<!-- Edit Form -->
	<div id="edit-winz" class="easyui-dialog" title="编辑"
		data-options="closed:true,iconCls:'icon-save',modal:true,closable:false"
		style="width: 800px; height: 300px;">
		<form id="editFormz" style="display:none;" class="ui-form"
			method="post">
			<input class="hidden" type="text" name="id" id="id"> <input
				class="hidden" name="deleted"> <input type="hidden"
				name="sqrid">
			<div class="ui-edit">
				<div class="etc">
					<div class="cap">详细信息</div>
					<table cellpadding="0" cellspacing="0" class="et">
						<tr>
							<td><label> 所属最低一级行政区域 </label></td>
							<td><input class="easyui-validatebox" id="sszdyjxzqy_mc"
								name="sszdyjxzqy_mc" /> <input type="hidden"
								name="sszdyjxzqy_dzbm" id="sszdyjxzqy_dzbm" /></td>
							<td><label> 所属街路巷(小区) </label></td>
							
							<td><input name="ssjlxxq_jlxxqmc" id="ssjlxxq_jlxxqmc_text"
								class="easyui-box ui-text" readonly="readonly"
								style="width:150px; " onclick="showJlxDialog()"> <input
								class="hidden" type="text" name="ssjlxxq_dzbm"
								id="ssjlxxq_dzbm_id"></td>
						</tr>
						<tr>
							<td><label> 门(楼)牌号 </label></td>
							<td><input class="easyui-validatebox" name="mlph" id="mlph"
								data-options="required:true" style="width:50px;" /> <input
								class="easyui-combobox" id="mlphlxid" name="mlphlxid"
								style="width:50px;" /> <input type="hidden" name="mlphlxmc"
								id="mlphlxmc" /></td>
							<td><label> 建筑物名称 </label></td>
							<td><input class="easyui-validatebox" name="jzwmc"
								id="jzwmc" /></td>

						</tr>
						<tr>
							<td><label> 中心点横坐标 </label></td>
							<td><input class="easyui-validatebox" type="text"
								id="zxdhzb" name="zxdhzb" readonly="readonly" /></td>
							<td><label> 中心点纵坐标 </label></td>
							<td><input class="easyui-validatebox" type="text"
								id="zxdzzb" name="zxdzzb" readonly="readonly" /></td>
						</tr>
						<tr>
							<td><label> 地址 </label></td>
							<td colspan="3"><input type="text" name="dzmc" id="dzmc"
								style="width:88%; border:0px;color: red;" readonly="readonly" />
							</td>
						</tr>
						<tr>
							<td><label> 区划内详细地址 </label></td>
							<td colspan="3"><input type="text" name="qhnxxdz"
								id="qhnxxdz" style="width:88%; border:0px;color: red;"
								readonly="readonly" /></td>
						</tr>
						<tr>
							<td><label> 申请人_姓名 </label></td>
							<td><input class="easyui-validatebox" name="sqrxm"
								id="sqrxm" data-options="required:true,validType:'length[1,20]'"></td>
							<td><label> 申请人联系电话 </label></td>
							<td><input type="text" name="sqrlxdh" id="sqrlxdh">
							</td>
						</tr>
						<tr>
							<td><label> 申请单位名称 </label></td>
							<td><input name="sqdwmc" id="sqdwmc"></td>
							<td><label> 申请单位电话 </label></td>
							<td><input type="text" name="sqdwlxdh" id="sqdwlxdh">
							</td>
						</tr>
						<tr>
							<td><label> 申请人身份号码 </label></td>
							<td><input class="easyui-validatebox" type="text"
								name="sqrgmsfzhm" id="sqrgmsfzhm"
								data-options="required:true,validType:'length[1,18]'"></td>
							<td><label> 临时门（楼）牌标识 </label></td>
							<td><select name="lsmlpbs" id="lsmlpbs">
									<option value="0">否</option>
									<option value="1">是</option>
							</select></td>
						</tr>
					</table>
				</div>
			</div>
			<input type="hidden" name="sjgsdwdm" id="sjgsdwdm" /> <input
				type="hidden" name="sjgsdwmc" id="sjgsdwmc" />
		</form>
	</div>
</body>
<script type="text/javascript">
	$(function() {
		var formBtns11 = [
				{
					text : '保存',
					handler : function() {
						$('#editFormz').form(
								'submit',
								{
									url : 'http://zaCloud.pcp.sd:80/dzMlph/save.do',
									onSubmit : function() {

									},
									success : function(data) {
										var d = eval("(" + data + ")");
										if (d.success) {
											$("#edit-winz").dialog('close');
											var ppp = $("#mlph").val();
											var sss = $("#jzwmc").val();
											var ddd = null;
											if (null != ppp || null != sss) {
												ddd = ppp + sss;
											} else {
												ddd = "无";
											}
											addMark1(mouseX, mouseY, ddd,
													d.uuid);
											$.messager.alert('提示', '添加成功');
											$("#editFormz").form('clear');
											$("#mlphlxid").combobox("setValue",
													"1");
											$("#mlphlxmc").val(
													$("#mlphlxid").combobox(
															"getText"));
											addr = "";
											qhdz = "";
											mlph = "";
											jzwmc = "";
										}
									}
								});
					}
				},
				{
					text : '注销',
					handler : function() {
						var id = $("#id").val();
						$.ajax({
							method : "post",
							dataType : "json",
							url : 'http://zaCloud.pcp.sd:80/dzMlph/delete.do',
							data : "id=" + id,
							success : function(data) {
								$("#edit-winz").dialog('close');
								$.messager.alert('提示', '注销成功');
								location.reload(true);
							},
							error : function(XMLHttpRequest, textStatus,
									errorThrown) {
								// 通常 textStatus 和 errorThrown 之中
								// 只有一个会包含信息
							}
						});
					}
				}, {
					text : '关闭',
					handler : function() {
						$("#edit-winz").dialog('close');
						$("#sszdyjxzqy_mc").val('');
						$("#sszdyjxzqy_dzbm").val('');
						//$("#ssjlxxq_dzbm").combobox('setValue','');
						$("#editFormz").form('clear');
						$("#mlphlxid").combobox("setValue", "1");
						$("#mlphlxmc").val($("#mlphlxid").combobox("getText"));
						addr = "";
						qhdz = "";
						mlph = "";
						jzwmc = "";
					}
				} ];

		$("#edit-winz").dialog({
			'buttons' : formBtns11
		});
	});
	var tree_id;
	function initJlxId(id){
		tree_id = id;
	}
	
	
	function showJlxDialog(){
		$('#div_dgList_ssjlxxq').empty().append('<table id="dgList_ssjlxxq"></table>');
		searchDatasByJlx('searchId_ssjlxxq','dgList_ssjlxxq');
		getDataByOkJlx('btn_ok_ssjlxxq','dgList_ssjlxxq','ssjlxxq_dzbm_id','ssjlxxq_jlxxqmc_text','ssjlxxq_win');
		$('#ssjlxxq_win').dialog('open');
		getJlxDataList('dgList_ssjlxxq','../dzJlx/queryJlx.do?id='+tree_id);
	}
	
	function searchDatasByJlx(searchId, dgListId) {
		$('#' + searchId).searchbox({
			width : 150,
			prompt : '请输入查询内容...',
			searcher : function(value, name) {
				$('#' + dgListId).datagrid('load', {
					val : value
				});
			}
		});
		$('#' + searchId).searchbox('setValue', '');
	};
	/**
	* @param btnId 确定按钮id
	* @param dgListId 列表id
	* @param cxid 显示id
	* @param cxmc 隐藏id
	* @param win_id 弹窗id
	*/
	function getDataByOkJlx(btnId, dgListId, cxid, cxmc, win_id) {
		$('#' + btnId).unbind();
		$('#' + btnId).bind('click', function() {
			var rows = $('#' + dgListId).datagrid('getChecked');
			if (new YDataGrid().utils.checkSelectOne(rows)) {
				$('#' + cxid).val(rows[0].ssjlxxq_dzbm);
				$('#' + cxmc).val(rows[0].jlxxqmc);
				$('#' + win_id).dialog('close');
				qhdz = rows[0].jlxxqmc;
        		$("#dzmc").val(addr+rows[0].jlxxqmc+jzwmc);
        		$("#qhnxxdz").val(qhdz+jzwmc);
			}
		});
	}
	
	function getJlxDataList(dgListId, _url) {
		$('#' + dgListId).datagrid({
			url : _url,
			fit : true,
			rownumbers : true,
			singleSelect : true,
			pagination : true,
			columns : [ [ {
				field : 'ssjlxxq_dzbm',
				checkbox : true
			}, {
				field : 'jlxxqmc',
				title : '名称',
				width : 220,
				align : 'center'
			} ] ]
		});
	}
</script>
</html>

			


<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<link rel="stylesheet" type="text/css" href="http://zaCloud.pcp.sd:80/css/jzwjbxx.css">
<body>
	<div id="edit-win2" class="easyui-dialog" title="添加建筑物结构"
		data-options="closed:true,iconCls:'icon-save',modal:true"
		style="width: 800px; height: 300px;">
		<form id="editForm2" action="http://zaCloud.pcp.sd:80/dzJzwjbxx/save.do"
			class="ui-form" method="post">
			<input class="hidden" name="jzwid" id="jzwid" />
			<div class="ui-edit">
				<div class="etc">
					<div class="cap" id="jzwjgcap">详细信息</div>
					<table cellpadding="0" cellspacing="0" class="et">

						<tr>
							<td><label> 地址 </label></td>
							<td colspan="3"><input class="easyui-validatebox"
								style="width:514px;border: 0px;color: red;" name="dzmc"
								id="dzmc2" readonly="readonly" /></td>
						</tr>
						<tr>
							<td><label> 中心点横坐标 </label></td>
							<td><input type="text" name="zxdhzb" id="zxdhzb2"
								style="border: 0px;color: red;" readonly="readonly" /></td>
							<td><label> 中心点纵坐标 </label></td>
							<td><input type="text" name="zxdzzb" id="zxdzzb2"
								style="border: 0px;color: red;" readonly="readonly" /></td>
						</tr>

						<tr>
							<td><label> 地(住)址是否存在 </label></td>
							<td><select name="dzzzybz" id="dzzzybz">
									<option value="1">是</option>
									<option value="0">否</option>
							</select></td>
							<td><label> 建筑物名称 </label></td>
							<td><input readonly="readonly" type="text" name="jzwmc"
								id="jzwmc2" style="border: 0px;" /></td>

						</tr>
						<tr>
							<td><label> 地(住)址是否在用 </label></td>
							<td><select name="dzzzybs" id="dzzzybs">
									<option value="1">是</option>
									<option value="0">否</option>
							</select></td>
							<td><label> 单元数/行数 </label></td>
							<td><input class="easyui-validatebox" type="text" name="dys"
								id="dys" data-options="required:true,validType:'length[1,10]'">
							</td>
						</tr>
						<tr>
							<td><label> 单元楼层是否相同 </label></td>
							<td><select name="sflcxt" id="sflcxt">
									<option value="1">是</option>
									<option value="0">否</option>
							</select></td>
							<td><label>楼层数</label></td>
							<td><input class="easyui-validatebox" type="text" name="lcs"
								id="lcs" data-options="required:true,validType:'length[1,10]'">
								<input type="hidden" name="lcsList" id="lcsList" /> <input
								type="button" class="hidden" id="setLcBtn" value="设置楼层" /></td>
						</tr>
						<tr>
							<td><label> 门数是否相同 </label></td>
							<td><select name="sfmsxt" id="sfmsxt">
									<option value="1">是</option>
									<option value="0">否</option>
							</select></td>
							<td><label> 每层房间数 </label></td>
							<td><input class="easyui-validatebox" name="mdyms"
								id="mdyms" data-options="required:true,validType:'length[1,10]'">
								<input type="hidden" name="tslcxh" id="tslcxh" /> <input
								type="hidden" name="tslcfj" id="tslcfj" /></td>
						</tr>
					</table>
				</div>
			</div>
			
			<div id="win_sflcxt" class="easyui-dialog"
				data-options="closed:true,modal:true,closable:false,
				minimizable:false,title:'设置单元楼层'"
				style="width: 500px; height: 300px; padding: 10px;">
				单元楼层设置
				<table id="lccfg">

				</table>
			</div>
			
			<div id="win_sfmsxt" class="easyui-dialog"
				data-options="closed:true,modal:true,closable:false,
				minimizable:false,title:'设置楼层房间'"
				style="width: 700px; height: 400px; padding: 10px;">
				楼层房间设置
				<div id="fjform">
					<table id="fjcfg">
						<!-- <tr>
							<td style="width: 70px; text-align: center;"></td>
							<td>标准层房间数： <input type="text" id="bzcfjs" value="" />
							</td>
							<td><input type="button" value="新增" id="addFjCol" /></td>
						</tr> -->
					</table>
				</div>
			</div>

		</form>
	</div>
</body>
<script type="text/javascript">
	function delTr(o) {
		var selTr = o.parentNode.parentNode.rowIndex;
		document.getElementById("fjcfg").deleteRow(selTr);
	}

	$(function() {
		var lcoperval = $("#sflcxt").val();
		var fjoperval = $("#sfmsxt").val();
		var zzz = '<tr><td style="width: 70px; text-align: center;"></td><td>标准层房间数： <input type="text" id="bzcfjs" value="" /></td><td><input type="button" value="新增" id="addFjCol" /></td></tr>';
		$("#fjcfg").append(zzz);
		var countFjCol = 0;
		var subHtml = '<tr><td><a href="javascript:" onclick="delTr(this)" class="icon-cancel delbtn"></a></td><td>特殊楼层序号：<input type="text" id="tslch'+countFjCol+'" name="_tslcxh" value="" /></td><td><label style="margin-left: 20px;">本楼层房间数：</label><input type="text" id="blcfjs'+countFjCol+'" name="_tslcfj" value="" /></td></tr>';
		$("#addFjCol").click(function() {
			countFjCol++;
			$("#fjcfg").append(subHtml);
		});

		//添加修改时，对单元楼层是否相同操作来弹出详细设置
		$("#edit-win2 select").change(function() {
			switch (this.id) {
			case "sflcxt":
				oper(this);
				if (this.value == 0) {
					$("#dys").val("");
					$("#dys").attr("readOnly", true);

				} else if (this.value == 1) {
					$("#dys").attr("readOnly", false);
					$("#lcs").attr("class", "easyui-validatebox");
					$("#setLcBtn").attr("class", "hidden");
				}
				break;
			case "sfmsxt":
				oper(this);
				break;
			}
		});

		function oper(obj) {
			if (obj.value == 0) {
				$("#win_" + obj.id).dialog("open");
			} else if (obj.value == 1) {
				$("#win_" + obj.id).dialog("close");
			}
		}
		var countDy = "0";
		var lcbar = [
				{
					text : '保存',
					iconCls : 'icon-save',
					handler : function() {
						var DycsArray = document.getElementsByName("Dycs");
						$("#dys").val(DycsArray.length);
						var dylcList = new Array(countDy);
						for (i = 0; i < countDy; i++) {
							dylcList[i] = DycsArray[i].value;
						}
						$("#lcsList").val(dylcList);
						$("#lcs").attr("class", "hidden");
						$("#win_sflcxt").dialog("close");
						$("#setLcBtn").attr("class", "");
						countDy = 0;
					    $("#lccfg").empty();
					}
				},
				{
					text : '新增',
					iconCls : 'icon-add',
					handler : function() {
						countDy++;
						$("#lccfg")
								.append(
										'<tr><td>单元序号</td><td><input type="text" readOnly=true value="'+countDy+'" name="lc"/></td><td>单元层数</td><td><input type="text" id="" name="Dycs"/></td></tr>');
					}
				}, {
					text : '取消',
					iconCls : 'icon-cancel',
					handler : function() {
					    $("#sflcxt").val(lcoperval);
						$("#win_sflcxt").dialog("close");
						countDy = 0;
					    $("#lccfg").empty();
					}
				} ];

		var fjbar = [ {
			text : '保存',
			iconCls : 'icon-save',
			handler : function() {
				$("#mdyms").val($("#bzcfjs").val());
				var tslcxhArr = document.getElementsByName("_tslcxh");
				var lcxhArr = new Array();
				for (i = 0; i < tslcxhArr.length; i++) {
					lcxhArr[i] = tslcxhArr[i].value;
				}
				$("#tslcxh").val(lcxhArr);
				var tslcfjArr = document.getElementsByName("_tslcfj");
				var lcfjArr = new Array();
				for (j = 0; j < tslcfjArr.length; j++) {
					lcfjArr[j] = tslcfjArr[j].value;
				}
				$("#tslcfj").val(lcfjArr);
				$("#win_sfmsxt").dialog("close");
				countFjCol = 0;
			    $("#fjcfg").empty();
			    $("#fjcfg").append(zzz);
			    $("#addFjCol").click(function() {
			          countFjCol++;
			          $("#fjcfg").append(subHtml);
		                });
			}
		}, {
			text : '注销',
			handler : function() {
				var id = $("#jzwid").val();
				$.ajax({
			        method: "post",
			        dataType: "json",
			        url: 'http://zaCloud.pcp.sd:80/dzJzwjg/delete.do',
			        data:"id="+jzwid,
			        success: function (data) {
			            countFjCol = 0;
			            $("#win_sfmsxt").dialog('close');
			            $("#fjcfg").empty();
			            $("#fjcfg").append(zzz);
			            $("#addFjCol").click(function() {
			                     countFjCol++;
			                     $("#fjcfg").append(subHtml);
		                });
						$.messager.alert('提示', '注销成功');
						//location.reload(true);
						},
						error: function (XMLHttpRequest, textStatus, errorThrown) {
						    // 通常 textStatus 和 errorThrown 之中
						    // 只有一个会包含信息
						}
			    });
			}
		},{
			text : '取消',
			iconCls : 'icon-cancel',
			handler : function() {
			    $("#win_sfmsxt").dialog("close");
			    countFjCol = 0;
			    $("#fjcfg").empty();
			    $("#fjcfg").append(zzz);
			    $("#addFjCol").click(function() {
			      countFjCol++;
			     $("#fjcfg").append(subHtml);
		        });
			}
		}];

		$("#win_sflcxt").dialog({
			'toolbar' : lcbar
		});
		$("#win_sfmsxt").dialog({
			'toolbar' : fjbar
		});

		$("#setLcBtn").click(function() {
			$("#win_sflcxt").dialog("open");
		});

		var mainform = {
			detail : $("#edit-win2")
		}
		var formBtns = [{
			text : '保存',
			handler : function() {
				$('#editForm2').form('submit', {
					url : 'http://zaCloud.pcp.sd:80/dzJzwjbxx/save.do',
					onSubmit : function() {

					},
					success : function(data) {
						var d = eval("(" + data + ")");
						if (d.success) {
							mainform.detail.dialog('close');
							$.messager.alert('提示', '添加成功');
						}
						;
					}
				});
			}
		}, {
			text : '关闭',
			handler : function() {
				mainform.detail.dialog('close');
			}
		} ];

		$("#edit-win2").dialog({
			'buttons' : formBtns
		});
	});
</script>
</html>

			

<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
  <body>
	<div id="jwrydetail" class="easyui-dialog" title="明细"
		data-options="closed:true,iconCls:'icon-detail',modal:true"
		style="width:800px;height:500px;">
		<form id="jwryForm" class="ui-form" method="post">
			<div class="ui-edit">
				<div class="etc">
					<table cellpadding="0" cellspacing="0" class="et">
						<tr><td colspan="4"><div class="cap">详细信息</div></td></tr>
						<tr>
							<td><label>英文姓 </label></td>
							<td><label id="ywx_lbl"></label></td>
							<td rowspan="3"><label>境外人员照片</label></td>
							<td rowspan="3">
								<img alt="单击可查看原图片" id="jwryzp_lbl" width="50%">
								<img alt="境外人员照片" id="zp_hide" style="display: none;">
							</td>
						</tr>
						<tr>
							<td><label>英文名</label></td>
							<td><label id="ywm_lbl"></label></td>
						</tr>
						<tr>
							<td><label>中文名</label></td>
							<td><label id="zwm_lbl"></label></td>
						</tr>
						<tr>
							<td><label>出生日期</label></td>
							<td><label id="csrq_lbl"></label></td>
							<td><label>国籍</label></td>
							<td><label id="gj_lbl"></label></td>
						</tr>
						<tr>
							<td><label>职业</label></td>
							<td colspan="3"><label id="zy_lbl"></label></td>
						</tr>
						<tr>
							<td><label>在华工作机构名称</label></td>
							<td colspan="3"><label id="zhgzjgmc_lbl"></label></td>
						</tr>
						<tr>
							<td><label>在华工作机构代码</label></td>
							<td colspan="3"><label id="zhgzjgdm_lbl"></label></td>
						</tr>
						<tr>
							<td><label>证件种类</label></td>
							<td><label id="zjzl_lbl"></label></td>
							<td><label>证件号码</label></td>
							<td><label id="zjhm_lbl"></label></td>
						</tr>
						<tr>
							<td><label>签证种类</label></td>
							<td><label id="qzzl_lbl"></label></td>
							<td><label>签证编号</label></td>
							<td><label id="qzbh_lbl"></label></td>
						</tr>
						<tr>
							<td><label>入境口岸</label></td>
							<td><label id="rjka_lbl"></label></td>
							<td><label>入境日期</label></td>
							<td><label id="rjrq_lbl"></label></td>
						</tr>
						<tr>
							<td><label>停留有效期</label></td>
							<td><label id="tlyxq_lbl"></label></td>
							<td><label>境外人员联系电话</label></td>
							<td><label id="jwrylxdh_lbl"></label></td>
						</tr>
						<tr>
							<td><label>现居住地详细地址</label></td>
							<td colspan="3"><label id="xxdz_lbl"></label></td>
						</tr>
						<tr>
							<td><label>房屋房主姓名</label></td>
							<td><label id="fwfzxm_lbl"></label></td>
							<td><label>房主身份证号</label></td>
							<td><label id="fzsfzh_lbl"></label></td>
						</tr>
						<tr>
							<td><label>境外人员离开日期</label></td>
							<td colspan="3"><label id="jwrylkrq_lbl"></label></td>
						</tr>
						<tr>
							<td><label>省市县（区）</label></td>
							<td colspan="3"><label id="ssxqdm_lbl"></label></td>
						</tr>
						<tr>
							<td><label>所属街路巷(小区)_地址编码</label></td>
							<td><label id="ssjlxxq_dzbm_lbl"></label></td>
							<td><label>地址编码</label></td>
							<td><label id="dzbm_lbl"></label></td>
						</tr>
						<tr>
							<td><label>房间编码</label></td>
							<td><label id="fjbm_lbl"></label></td>
							<td><label>房间号</label></td>
							<td><label id="fjh_lbl"></label></td>
						</tr>
						<tr>
							<td><label>备注</label></td>
							<td colspan="3"><label id="bz_lbl"></label></td>
						</tr>
						<tr>
							<td><label>属地派出所</label></td>
							<td><label id="sdpcs_lbl"></label></td>
							<td><label>警务责任区</label></td>
							<td><label id="jwzrq_lbl"></label></td>
						</tr>
						<tr>
							<td><label>现住址区划</label></td>
							<td colspan="3"><label id="xzzqh_lbl"></label></td>
							
						</tr>
						<tr>
							<td><label>人员类别 </label></td>
							<td><label id="rylb_lbl"></label></td>
							<td><label>人口分类</label></td>
							<td><label id="rkfl_lbl"></label></td>
						</tr>
						<tr>
							<td><label>国家代码 </label></td>
							<td><label id="gjdm_lbl"></label></td>
							<td><label>现住址户编码</label></td>
							<td><label id="xzzhuid_lbl"></label></td>
						</tr>
						<tr>
							<td><label>来华身份</label></td>
							<td><label id="lhsf_lbl"></label></td>
							<td><label>中文水平</label></td>
							<td><label id="zwsp_lbl"></label></td>
						</tr>
						<tr>
							<td><label>签证次数 </label></td>
							<td colspan="3"><label id="qzcs_lbl"></label></td>
						</tr>
						<tr>
							<td><label>居留情况</label></td>
							<td><label id="jlqk_lbl"></label></td>
							<td><label>居留许可号码</label></td>
							<td><label id="jlxkhm_lbl"></label></td>
						</tr>
						<tr>
							<td><label>居留事由</label></td>
							<td colspan="3"><label id="jlsy_lbl"></label></td>
						</tr>
						<tr>
							<td><label>签发机关</label></td>
							<td colspan="3"><label id="qfjg_lbl"></label></td>
						</tr>
						<tr>
							<td><label>工作学习身份 </label></td>
							<td><label id="gzxxsf_lbl"></label></td>
							<td><label>任职日期</label></td>
							<td><label id="rzrq_lbl"></label></td>
						</tr>
						<tr>
							<td><label>离职日期</label></td>
							<td><label id="lzrq_lbl"></label></td>
							<td><label>入住方式</label></td>
							<td><label id="rzfs_lbl"></label></td>
						</tr>
						<tr>
							<td><label>入住时间</label></td>
							<td><label id="rzsj_lbl"></label></td>
							<td><label>住所联系方式</label></td>
							<td><label id="zslxfs_lbl"></label></td>
						</tr>
						<tr>
							<td><label>居住地性质 </label></td>
							<td colspan="3"><label id="jzdxz_lbl"></label></td>
						</tr>
						<tr><td colspan="4"><div class="cap">随行人员信息</div></td></tr>
						<tr>
							<td><label>随行人员亲属关系1</label></td>
							<td><label id="sxryqsgx1_lbl"></label></td>
							<td><label>随行人员中文姓名1</label></td>
							<td><label id="sxryzwxm1_lbl"></label></td>
						</tr>
						<tr>
							<td><label>随行人员英文姓名1</label></td>
							<td><label id="sxryywxm1_lbl"></label></td>
							<td><label>随行人员性别1</label></td>
							<td><label id="sxryxb1_lbl"></label></td>
						</tr>
						<tr>
							<td><label>随行人员出生日期1</label></td>
							<td colspan="3"><label id="sxrycsrq1_lbl"></label></td>
						</tr>
						<tr>
							<td><label>随行人员单位名称1</label></td>
							<td colspan="3"><label id="sxrydwmc1_lbl"></label></td>
						</tr>
						<tr>
							<td><label>随行人员亲属关系2</label></td>
							<td><label id="sxryqsgx2_lbl"></label></td>
							<td><label>随行人员中文姓名2</label></td>
							<td><label id="sxryzwxm2_lbl"></label></td>
						</tr>
						<tr>
							<td><label>随行人员英文姓名2</label></td>
							<td><label id="sxryywxm2_lbl"></label></td>
							<td><label>随行人员性别2</label></td>
							<td><label id="sxryxb2_lbl"></label></td>
						</tr>
						<tr>
							<td><label>随行人员出生日期2</label></td>
							<td colspan="3"><label id="sxrycsrq2_lbl"></label></td>
						</tr>
						<tr>
							<td><label>随行人员单位名称2</label></td>
							<td colspan="3"><label id="sxrydwmc2_lbl"></label></td>
						</tr>
						<tr><td colspan="4"><div class="cap">采集人信息</div></td></tr>
						<tr>
							<td><label>采集人员</label></td>
							<td><label id="cjry_lbl"></label></td>
							<td><label>采集时间</label></td>
							<td><label id="cjsj_lbl"></label></td>
						</tr>
						<tr>
							<td><label>采集人员联系电话</label></td>
							<td colspan="3"><label id="cjrylxdh_lbl"></label></td>
						</tr>
						<!-- <tr>
							<td><label>填报人</label></td>
							<td><label id="djr_lbl"></label></td>
							<td><label>填报时间</label></td>
							<td><label id="djsj_lbl"></label></td>
						</tr>
						<tr>
							<td><label>填报单位</label></td>
							<td colspan="3"><label id="djdw_lbl"></label></td>
						</tr> -->
						<!-- <tr>
							<td><label>英文名</label></td>
							<td><label id="ywm_lbl"></label></td>
							<td><label>中文名</label></td>
							<td><label id="zwm_lbl"></label></td>
						</tr>
						<tr>
							<td><label>出生日期</label></td>
							<td><label id="csrq_lbl"></label></td>
							<td><label>国籍</label></td>
							<td><label id="gj_lbl"></label></td>
						</tr>
						<tr>
							<td><label>职业</label></td>
							<td><label id="zy_lbl"></label></td>
							<td><label>在华工作机构名称</label></td>
							<td><label id="zhgzjgmc_lbl"></label></td>
						</tr>
						<tr>
							
							<td><label>证件种类</label></td>
							<td><label id="zjzl_lbl"></label></td>
						</tr>
						<tr>
							<td><label>证件号码</label></td>
							<td><label id="zjhm_lbl"></label></td>
							<td><label>签证种类</label></td>
							<td><label id="qzzl_lbl"></label></td>
						</tr>
						<tr>
							<td><label>签证编号</label></td>
							<td><label id="qzbh_lbl"></label></td>
							<td><label>停留有效期</label></td>
							<td><label id="tlyxq_lbl"></label></td>
						</tr>
						<tr>
							<td><label>境外人员联系电话</label></td>
							<td><label id="jwrylxdh_lbl"></label></td>
						</tr>
						<tr>
							<td><label>现居住地详细地址</label></td>
							<td><label id="xxdz_lbl"></label></td>
							<td><label>房屋房主姓名</label></td>
							<td><label id="fwfzxm_lbl"></label></td>
						</tr>
						<tr>
							<td><label>房主身份证号</label></td>
							<td><label id="fzsfzh_lbl"></label></td>
							<td><label>境外人员离开日期</label></td>
							<td><label id="jwrylkrq_lbl"></label></td>
						</tr>
						<tr>
							<td><label>注销日期</label></td>
							<td><label id="zxrq_lbl"></label></td>
							<td><label>删除标记（0-未删除，1-已删除）</label></td>
							<td><label id="deltag_lbl"></label></td>
						</tr>
						<tr>
							<td><label>删除时间</label></td>
							<td><label id="deltime_lbl"></label></td>
							<td><label>登记人</label></td>
							<td><label id="djr_lbl"></label></td>
						</tr>
						<tr>
							<td><label>登记单位</label></td>
							<td><label id="djdw_lbl"></label></td>
							<td><label>登记人名称</label></td>
							<td><label id="djrmc_lbl"></label></td>
						</tr>
						<tr>
							<td><label>登记单位名称</label></td>
							<td><label id="djdwmc_lbl"></label></td>
							<td><label>登记时间</label></td>
							<td><label id="djsj_lbl"></label></td>
						</tr>
						<tr>
							<td><label>修改人</label></td>
							<td><label id="xgr_lbl"></label></td>
							<td><label>修改单位</label></td>
							<td><label id="xgdw_lbl"></label></td>
						</tr>
						<tr>
							<td><label>修改人名称</label></td>
							<td><label id="xgrmc_lbl"></label></td>
							<td><label>修改单位名称</label></td>
							<td><label id="xgdwmc_lbl"></label></td>
						</tr>
						<tr>
							<td><label>更新时间</label></td>
							<td><label id="gxsj_lbl"></label></td>
							<td><label>MOVESIGN</label></td>
							<td><label id="movesign_lbl"></label></td>
						</tr>
						<tr>
							<td><label>设备ID</label></td>
							<td><label id="sbid_lbl"></label></td>
							<td><label>录入角色(民警0,社会积极力量1)</label></td>
							<td><label id="lrjs_lbl"></label></td>
						</tr>
						<tr>
							<td><label>录入方式(后台系统0,移动终端1)</label></td>
							<td><label id="lrfs_lbl"></label></td>
							<td><label>录入网络(互联网E,公安网A)</label></td>
							<td><label id="lrwl_lbl"></label></td>
						</tr>
						<tr>
							<td><label>现住址所属分局代码 </label></td>
							<td><label id="xzzssfjdm_lbl"></label></td>
							
						</tr>
						<tr>
							
							<td><label>统计标志 0 未统计 1 统计</label></td>
							<td><label id="tjflg_lbl"></label></td>
						</tr>
						<tr>
							<td><label>null</label></td>
							<td><label id="xzzhuidgxsj_lbl"></label></td>
						</tr> -->
					</table>
				</div>
			</div>
		</form>
	</div>
	</body>
</html>				
			<div id="jlxTree" class="easyui-dialog" title="最低级别行政区域"
				data-options="closed:true,modal:true"
				style="width: 300px; height: 400px;">
				<ul id="treegroup" class="easyui-tree"
					data-options="method:'get',animate:true">
				</ul>
			</div>
			
			<div id="ssjlxxq_win" class="easyui-dialog" title="所属街路巷(小区)"
				data-options="closed:true,iconCls:'icon-edit',modal:true"
				style="width: 500px; height: 400px;">
				<div class="easyui-layout" data-options="fit:true">
					<div id="div_north" data-options="region:'north'"
						style="height: 50px; padding: 10px;">
						<div id="dlg-toolbar_ssjlxxq">
							<input id="searchId_ssjlxxq"></input>&nbsp;&nbsp;&nbsp;&nbsp; <input
								type="button" id="btn_ok_ssjlxxq" class="btn" value="确定" />
						</div>
					</div>
					<div id="div_dgList_ssjlxxq" data-options="region:'center'"></div>
				</div>
			</div>
		</table>
		<div class="topbar">
			<ul class="func">
				<li id="liQuery"><a href="#" onclick="$('#QueryTool').show();">
				<span id="spanQueryValue">查询模式</span></a><input id="texQuery" type="text" />
				<input id="isSY" type="checkbox" onclick="setisSY();" />视野&nbsp;<a href="#" onclick="searchALL();">搜索</a>
                    <div id="QueryTool">
                        <div class="sdgsd" onclick="$('#QueryTool').hide();">
                            <img src="../images/pgis/5.gif" alt="隐藏" width="10px" height="5px" />
                        </div>
                        <div id="Div2">
                            <ul class="toolmenu" id="toolmenu">
                               
                                <li class="gjkjtj"><span></span>
                                    <a href="#" onclick="setQueryType(dic.mlph,'门楼牌号');">门楼牌号</a>
                                    <a href="#" onclick="setQueryType(dic.jyz,'加油站');">加油站</a> 
                                    <a href="#" onclick="setQueryType(dic.dw,'单位');">单位</a> 
                                    <a href="#" onclick="setQueryType(dic.bw,'保卫');">保卫</a> 
                                    <a href="#" onclick="setQueryType(dic.jwry,'境外人员');">境外人员</a> 
                                   
                                </li>
                                <!-- 
                                 <li class="gjkjtj"><span></span>
                                   
                                    <a href="#" onclick="setQueryType('');">监控</a>
                                    <a href="#" onclick="setQueryType('');">重点人员</a> 
                                    <a href="#" onclick="setQueryType('');">警员定位</a>     
                                 </li>
                                 -->
                               
                            </ul>
                        </div>
                    </div>
                </li>
				<li class="fangda"><a href="#" onclick="_MapApp.zoomIn();">放大</a></li>
                <li class="suoxiao"><a href="#" onclick="_MapApp.zoomOut();">缩小</a></li>
				<!-- <li id="gongju"><a href="#" onclick="showHideMenuPanel();">空间查询</a>
                    工具面板
                    <div id="menutool" style="width: 100px; position: absolute; top: 33px; z-index: 9999;
                        display: none;">
                        <div class="sdgsd" onclick="$('#menutool').css('display','none');">
                            <img src="img/5.gif" alt="隐藏" width="10px" height="5px" />
                        </div>
                        <div id="menudiv" style="width: 100%; background: #F7F7F7; filter: alpha(opacity=90);">
                            <ul class="toolmenu" style="padding-left: 2px">
                                <li class="gjkjtj" onmouseover="overChange(this);" onmouseout="outChange(this);"
                                    onclick="spatialCount(1);">矩形统计</li>
                                <li class="gjkjtj" onmouseover="overChange(this);" onmouseout="outChange(this);"
                                    onclick="spatialCount(2);">圆统计</li>
                                <li class="gjkjtj" onmouseover="overChange(this);" onmouseout="outChange(this);"
                                    onclick="spatialCount(3);">多边形统计</li>
                            </ul>
                        </div>
                    </div>
                </li> -->
                
                <li id="qingchu"><a href="#" onclick="sysclearAll(); ">清除痕迹</a></li>
			</ul>
			</div>
	
	    <div id="left" class="resultsnavzc">
                <img id="slip_cop_1" style="left: 0px; top:0px; position: absolute; border:none;"
                    
                    src="http://zaCloud.pcp.sd:80/images/menutop.gif" width="260" height="6" />
                <img style="position: absolute; cursor: hand; top: 0px; left: 242px" id="slip_ctrl_1"
                    
                    border="0" src="http://zaCloud.pcp.sd:80/images/lmenuo.gif" width="18" onclick="showResults()" height="70">
                <div style="border: #000000 1px solid; position: absolute; filter: alpha(opacity=90);
                    width: 240px; background: #eef8fd; height: 493px;
                    overflow-x: hidden; overflow-x: hidden!important; overflow-y: auto; overflow-y: auto!important;
                    top: 8px; left: 1px; z-index: 400" id="resultsContect">
                    <p class="shijiliebiao" id="shijiliebiao">
                       
                    </p>
                    <p class="sp">
                        <div id="divLeftSearch" style="display: block;">
                        </div>
                        <input type="text" id="search" style="display: none;" /><input type="button" style="display: none;"
                            class="btn57x23" value="搜索" />
                    </p>
                    <ul class="tanchuliebiao" style="z-index: 305" id="tanchuliebiao">
                        <!-- <li> <a href="#">山东大学威海分校-海洋学院<br />
                  <span>文化西路180号山东大学威海分校</span></a></li> -->
                    </ul>
                </div>
                
            </div>
	</body>
	<script type="text/javascript">
	function setHt() {
	    $("#resultsContect").css("height", $(document).height() - 42);
	}	
  var jlxTree = {
			detail : $("#jlxTree")
		}
		var treeBtns = [
		    		    {
		    				text:'保存',
		    				handler:function(){
		    				    // 此处保存的是添加标准地址Form的行政区划Tree
		    				    jlxTree.detail.dialog('close');
		    					var notchecknodes = $('#treegroup').tree('getSelected');
		    					$("#sszdyjxzqy_mc").val(notchecknodes.text);
		    					$("#sszdyjxzqy_dzbm").val(notchecknodes.id);
		    					//$("#zzjgTree").tree({url:'http://zaCloud.pcp.sd:80/dzXzqh/queryXZQ.do'});
		    					
		    					addr = $("#sszdyjxzqy_mc").val();
		    					$("#dzmc").val(addr);
		    					$("#qhnxxdz").val("");
		    					qhdz = "";
		    					$("#jlxTree").dialog('close');
    							initJlxId(notchecknodes.id);
		    		    	}
		    			},{
		    				text:'关闭',
		    				handler:function(){
		    					jlxTree.detail.dialog('close');
		    				}
		    			}
		    		];
  //方法功能：点击右键通过controletr弹出新页面
  
	function show1() {
		var jwqXinXi = new Array();
		if("null" !=myZuobiao && ""!=myZuobiao){
		   /* if ("null" != childZuobiao && "" != childZuobiao) {//警务区以上单位进行坐标判断
			var flag = isPermissionbyPoint(childZuobiao, mouseX, mouseY);
			jwqXinXi=getJWQByPoint(childZuobiao,mouseX,mouseY,childMc,childId);
			if (flag) {
				$("#zxdhzb").val(mouseX);
				$("#zxdzzb").val(mouseY);
				$("#sjgsdwmc").val(jwqXinXi[0]);//0为name
	            $("#sjgsdwdm").val(jwqXinXi[1]);//1为id
	            $("#editFormz").show();
				$("#edit-winz").dialog("open");
			} else {
				alert("没有权限！！！");
			}
		 }else{ */
			 var flag=isPermissionbyPoint(myZuobiao, mouseX, mouseY);
			 if(flag){
				    $("#zxdhzb").val(mouseX);
					$("#zxdzzb").val(mouseY);
					$("#sjgsdwmc").val(myName);
		            $("#sjgsdwdm").val(myId);
		            $("#editFormz").show();
					$("#edit-winz").dialog("open");
			 }else{
				 alert("没有权限！！！");
			 }
		 //}
		}else if("null"!=zuobiaoArray && ""!=zuobiaoArray){//警务区单位进行坐标判断
			var flag=isPermissionbyPoint(zuobiaoArray,mouseX,mouseY);
		      jwqXinXi=getJWQByPoint(zuobiaoArray,mouseX,mouseY,jwqNameArray,jwqIdArray);
	         if(flag){
	               $("#zxdhzb").val(mouseX);
	               $("#zxdzzb").val(mouseY);
	               $("#sjgsdwmc").val(jwqXinXi[0]);//0为name
	               $("#sjgsdwdm").val(jwqXinXi[1]);//1为id
	               $("#editFormz").show();
	               $("#edit-winz").dialog("open");
	         }else{
	              
	              alert("没有权限！！！");    
	         }
		}else if("null"==zuobiaoArray || ""==zuobiaoArray){
			alert("还未划分行政区域！！！");
		}else if("null"==myZuobiao || ""==myZuobiao){
			alert("还未划分行政区域！！！");
		}

	}

	$("#sszdyjxzqy_mc").click(function() {
		$("#jlxTree").dialog( {
			'buttons' : treeBtns
		});
		$("#treegroup").tree( {
			url : 'http://zaCloud.pcp.sd:80/dzXzqh/queryXZQ.do'
		});
		$("#jlxTree").dialog("open");
	});

	//打开页面时，页面加载时添加需要显示的信息的方法
	window.onload = function() {
		
		//开始接受坐标
  
myZuobiao[0]='117.67456,37.41943,116.95495,36.84814,117.20764,36.09008,118.61938,36.04614,118.50952,36.78771,117.67456,37.41943';myCenterPointX[0]='117.77344';myCenterPointY[0]='36.76849';
 
  		 onLoad();
  		queryMph=new QueryMph(_MapApp); 
		queryFrame = new QueryFrame(_MapApp);
  	  	oldCenterPoint=_MapApp.getCenterLatLng();
  		oldzoomLevel=_MapApp.getZoomLevel();
  	    _MapApp.addMapChangeListener(function (){
  	        showMlphLayer();
  	        });
		//根据后台传来的警务区以上的用户的坐标画出
 
		for(var m=0;m<childZuobiao.length;m++){
			//alert(childZuobiao.length);
               if("null"!=childZuobiao[m] && ""!=childZuobiao[m]){
                   //alert("m:::"+m);
            	   var	pPolyline=addLine(childZuobiao[m]);
            	   var mbr= pPolyline.getMBR();
            	   var centerZuobiao=new Point(childCenterPointX[m],childCenterPointY[m]);
            	   var tit=new Title(childMc[m],13,0,"宋体","black","white","#46a3ff","1");
            	   tit.setPoint(centerZuobiao);
            	   _MapApp.addOverlay(tit);
                   }

			}
		//根据后台传来的警务区上级的自身范围坐标画范围
		if(myZuobiao.length !=0){
			for(var i = 0;i< myZuobiao.length;i++){
				if("null"!=myZuobiao[i] && ""!=myZuobiao[i]){
					var pPolygon=addLine(myZuobiao[i]);
		            var mbr= pPolygon.getMBR();
		            var centerZuobiao=new Point(myCenterPointX[i]*1,myCenterPointY[i]*1);
		            var tit=new Title(myName,13,0,"宋体","black","white","#46a3ff","1");
		            tit.setPoint(centerZuobiao);
		            _MapApp.centerAtMBR(mbr);
		            _MapApp.addOverlay(tit);
					}
			}
		}
		
  		//根据后台传来的警务区坐标集合画出警务区范围 				
  			for(var m=0;m<zuobiaoArray.length;m++){
  				if("null"!=zuobiaoArray[m] && ""!=zuobiaoArray[m]){ 
  				var	pPolyline=addLine(zuobiaoArray[m]);
  				var mbr= pPolyline.getMBR();
  				_MapApp.centerAtMBR(mbr);
  				 var centerZuobiao=new Point(jwqCenterPointX[m],jwqCenterPointY[m]);
  				var tit=new Title(jwqNameArray[m],13,0,"宋体","black","white","#46a3ff","1");
  				 tit.setPoint(centerZuobiao);
  				_MapApp.addOverlay(tit);
  	  				}
  	  	  	} 		                                             
  	}
  	//生成行政区域范围线的方法
  	function addLine(zuobiao){
		var pPolyline=new Polyline(zuobiao,"#ae0000", 4,0.7,"#46a3ff");
		_MapApp.addOverlay(pPolyline);
		return pPolyline;
	}
  	//右单击事件
 $(document).ready(function () {       
        	setHt();
        	ddsmoothmenu.init({
                mainmenuid: "rightButtonMenu", //Menu DIV id
                orientation: 'v', //Horizontal or vertical menu: Set to "h" or "v"
                classname: 'ddsmoothmenu-v', //class added to menu's outer DIV
                //customtheme: ["#804000", "#482400"],
                contentsource: "markup" //"markup" or ["container_id", "path_to_menu_file"]
            });
	          
            $("#mymap").contextMenu('rightButtonMenu', {
          
                //重写onContextMenu和onShowMenu事件
                onContextMenu: function (e) {                   
                    if ($(e.target).attr('id') == 'dontShow') return false;
                    else return true;
                },
                onShowMenu: function (e, menu) {
                   // alert('onshowmenu');
                   mouseX=_MapApp.getMouseMapX();//获得右单击时坐标的
                   mouseY=_MapApp.getMouseMapY();
                    return menu;
                }
            }); 
           	$.ajax({
           		method: "post",
                dataType: "json",
                url: urls.msUrl+"/appDictionary/getMlphLx.do",
                success: function (data) {
                	$("#mlphlxid").combobox({
                       	data : data.mlphlxList,
                        valueField : 'dict_code',
                		textField : 'dict_mc'
                    });
                	$("#mlphlxid").combobox("setValue","1");
                	$("#mlphlxmc").val($("#mlphlxid").combobox("getText"));
                }
           	});
            $("#mlphlxid").combobox({
            	onSelect:function(record){
            		$("#mlphlxmc").val(record.dict_mc);
            		mlph = $("#mlph").val().length>0?$("#mlph").val():'';
            		jzwmc = mlph+$("#mlphlxmc").val();
            		$("#jzwmc").val(jzwmc);
            		$("#qhnxxdz").val(qhdz+jzwmc);
            		$("#dzmc").val(addr + qhdz + jzwmc);
            	}
            });
            
 });
 editBtn();
 function editBtn() {
		var editWin = {
			edit : $("#edit-win")
		}
		if (editWin.edit && editWin.edit[0]) {
			//判断页面是否设置buttons，如果没有设置默认按钮
			var btns = editWin.edit.attr("buttons");
			if (!btns) {
				//设置 保存,关闭按钮
				editWin.edit.dialog( {
					buttons : [
							{
								text : '保存',
								id : 'authorizebtn',
								handler : function() {
								    var pp=new Point(mouseX,mouseY);
								    var sss=$("#mlph").val();
								    save();
								}
							}, {
								text : '关闭',
								handler : function() {
									editWin.edit.dialog('close');
								}
							} ]
				});
			}
		}
	}	
 var Form = {edit:$("#editForm")}
		//此方法中含有框架中提交form表单的方法
		function save(){
			if(Form.edit.form('validate')){
		    	var fl = false;
		    	var jlxxqmc = $('#ssjlxxq_jlxxqmc_text').val();
		    	
		    	if(jlxxqmc != null && jlxxqmc != ''){
	    			fl = true ;
	    		}
		    	if(!fl){
		    		$.messager.alert('提示','请选择列表中的街路巷小区');
		    		return;
		    	}
				
							//sdwangge.progress();
							Form.edit.attr('action','http://zaCloud.pcp.sd:80/dzMlph/save.do');
 							sdwangge.saveForm(Form.edit,function(data){//提交form的方法
								$("div[class='window-shadow']").hide();
								$("div[class='window-mask']").hide();
								$('#edit-win').dialog('close');
							    //Events.refresh();
							     //回调函数
							     var ppp= $("#mlph").val();
							     var sss = $("#jzwmc").val();
							     var ddd;
							     if(null != ppp || null !=sss){
							    	 ddd = ppp + sss;
							     }else{
							    	 ddd = "无";
							     }
							     addMark1(mouseX,mouseY,ddd,data.uuid);
							     Form.edit.resetForm();
							     $("div[class='panel window messager-window']").hide();
							     sdwangge.closeProgress();
							    //window.location.reload()
							});
						 }
		}
 
 function getFwjg1(ywlsh){
	  $.ajax({
      method: "post",
      dataType: "json",
      url: urls.msUrl+"/dzJzwjbxx/fwjg_Ajax.do",
      data:"ywlsh="+ywlsh,
      success: function (data) {
      	if(data.jzwflag){
          	$("#jzwid").val(data.data.dzbm);
				$("#zxdhzb2").val(data.data.zxdhzb);
				$("#zxdzzb2").val(data.data.zxdzzb);
				$("#jzwmc2").val(data.data.jzwmc);
				$("#dzmc2").val(data.data.dzmc);
				$("#edit-win2").dialog("open");
          }else if(!data.jzwflag){
				var jzwjgid = data.jzwjgid;
				window.open(urls.msUrl+'/dzJzwjbxx/fwjg.do?jzwid='+ywlsh+'&&jzwjgid='+jzwjgid,'title','height=1024px,width=1024px,scrollbars=no,status=no,menubar=no,scrollbars=no,resizable=yes,location=no');
	        }
			},
			error: function (XMLHttpRequest, textStatus, errorThrown) {
			    // 通常 textStatus 和 errorThrown 之中
			    // 只有一个会包含信息
			}
  });

  }
 function addMark1(pX,pY,NewName,ywlsh1){
	 var qq = new Point(pX*1,pY*1);
	 var t =new Title(NewName,13,0,"宋体","black","white","#46a3ff","1");
	 var ic = new Icon();
	 var imgAddr1 = urls.msUrl + "/js/pgis/address.gif";
	 var height1 = 16;
	 var width1 = 16;
	 var topOffset1 = -4;
	 var leftOffset1 = 2; 
	 ic.image = imgAddr1;
	 ic.height = height1;
	 ic.width = width1;
	 ic.topOffset = topOffset1;
	 ic.leftOffset = leftOffset1;
	 var mkr = new Marker(qq,ic,t);
	 mkr.addListener("click", function(){
	    	getFwjg1(ywlsh1);
	    });
	 _MapApp.addOverlay(mkr);
	 //加入到marker数组中
	 try {
		  
		 newMarkerLayer.push(mkr);
	} catch (e) {
		// TODO: handle exception
		
	}
 }
	</script>
</html>

