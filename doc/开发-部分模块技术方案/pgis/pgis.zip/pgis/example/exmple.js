


<html xmlns:v="urn:schemas-microsoft-com:vml">
<head>
<style type="text/css">
v\:* {
	behavior: url(#default#VML);
}
</style>
<head>
<meta http-equiv="content-type" content="text/html; charset=utf-8" />
<!-- <META HTTP-EQUIV="imagetoolbar" CONTENT="no">-->
<title class="title">栅格地图图片引擎服务系统--示例</title>
<script type="text/javascript" src="http://zaCloud.pcp.sd:80/js/commons/jquery.min.js"></script>
<script type="text/javascript" src="http://zaCloud.pcp.sd:80/js/commons/jquery.form.js"></script>

<script type="text/javascript" charset="GB2312"
	src="http://10.48.1.227:9080/TileMap/js/EzMapAPI.js"></script>
<script reload="true" id="www" type="text/javascript"> 
 var organ_id = "29e1d8e2-30bc-4bf1-aa69-4725804f6ffa";
_MapApp=null;
g_overlay=null;
g_edit=false;
var strPoints="";
var strArea=0;
var isDraw=false;
var pPolygon2;
function onLoad() {
	if(typeof EzMap =="undefined"){
		window.setTimeout("onLoad()",10);
		return;
	}
 
  	if(_compatIE()){
	  	/*rg = new Bs_ResizeGrip("map");
			rg.gripIcon = 'images/components/windows/resizeWindow.gif'; 
			rg.draw();
			*/
		//EzMap.registerProx("/ezprox/servlet/com.map.service.XmlHttpProxy");
		_MapApp = new EzMap(document.getElementById("map"));
		
		//_MapApp.centerAndZoom(new Point(118.39459,35.09203), 1);
		var pOverview=new OverView();
		//pOverview.width=200;
		//pOverview.height=200;
		pOverview.minLevel=8;
		pOverview.maxLevel=10;
		_MapApp.addOverView(pOverview);
 
		//_MapApp.zoomTo("2");
		_MapApp.showMapControl();
		//_MapApp.showSmallMapControl();
		_MapApp.showMapServer();
		_MapApp.switchMapServer(0);
		//_MapApp.map.enableMouseScroll();
		//_MapApp.editOverlay();
		//gotoCoord();
	}else if(_MapApp==null){
		var pEle=document.getElementById("map");
		//pEle.innerHTML="<p>目前EzMap地图引擎不支持你使用的浏览器，我们当前支持如下浏览器类型:</p><ul><li><a href='http://www.microsoft.com/windows/ie/downloads/default.asp'>IE</a> 5.5+ (Windows)</li>";
	}
		   
	
}
 
//按钮清除实现功能的方法
function clearIcon() {
	  _MapApp.clear();
	  strPoints= null;
	  
}
function callback(str){
	//alert("调用回调函数！"+dataInputx.toString()+":"+dataInputy.toString());
	//alert("调用回调函数！"+dataInputx.value);
    //alert("调用回调函数,获取坐标:"+str);
	//getMapApp().pan();
}
</script>


</head>





<body>



	<!--  
  <OBJECT id="min" type="application/x-oleobject" classid="clsid:adb880a6-d8ff-11cf-9377-00aa003b7a11">
	<PARAM name="Command" value="Minimize">
  </OBJECT>
  <OBJECT id="max" type="application/x-oleobject" classid="clsid:adb880a6-d8ff-11cf-9377-00aa003b7a11">
	<PARAM name="Command" value="Maximize">
  </OBJECT>
 -->

	<!--<div id="map" style="border-style:solid; border-width:1px; top:100px;right:20px;width:300px;height:300px; position:absolute; padding-left:4px; padding-right:4px; padding-top:1px; padding-bottom:1px"></div>
-->

	<input type="hidden" id="orgna_id" name="orgna_id">
	<table style="width: 100%">
		<tr>


			<td></td>


			<!--  style="width:100%"-->















			<td align="right"><input type="button" onclick="drawBianjie();"
				value="管辖规划" title="点击"></input> <input type="button"
				onclick="clearIcon();" value="清除"></input> <!--   <input type="button" style="width:100%" onclick="_MapApp.changeDragMode('drawPolyline',dataInputx,dataInputy,callback);" value="画线" title="点击拖动"></input>-->
				<input type="hidden" id="dataInputy" value=""></input> <input
				type="button" onclick="save();" value="提交"></input> <input
				type="button" value="关闭" onclick="closed();"></input> <input
				type="hidden" id="dataInputx" value=""></input></td>



		</tr>

		<tr>
			<td style="width: 100%; height: 770px; border: 2px solid #FF0000"
				colspan="2">
				<div id="map"
					style="width: 100%; height: 100%; border: 0px solid #FF0000;"></div>

			</td>
		</tr>

		<!--  style="width: 250px"-->

		<!-- 
							<tr>
								<td style="width: 100%">
								</td>

							</tr> -->

	</table>



</body>


<script type="text/javascript"> 
    var myName="null";//选中行的name
    var Pzuobiao="null";//父坐标
    var Pname="null";//父组织的名称
    var brotherName=new Array();//兄弟组织名称
    var brotherZuobiao=new Array();//兄弟坐标
  
    var myCenterPointX = new Array();
    var myCenterPointY = new Array();
    var zuobiao = new Array();
    var pCenterPointX="null";//父组织中心坐X标
    var pCenterPointY="null";//父组织中心Y坐标
	var brotherCenterPointX = new Array();//兄弟组织的中心X坐标
	var brotherCenterPointY = new Array();//兄弟组织的中心Y坐标
	var pPolygon2;
	var _bgColor = [ "#3D96AE", "#4572A7", "#AA4643", "#89A54E", "#80699B",
			"#DB843D", "#92A8CD", "#A47D7C", "#B5CA92", "#996699", "#33CC00",
			"#999999", "#669966", "#FF9999", "#99FF33", "#99ACDD", "#32C092",
			"#666699", "#69238B", "#0099CC" ];
brotherZuobiao[0]='null';brotherName[0]='null';brotherCenterPointX[0]='0.0';brotherCenterPointY[0]='0.0';brotherZuobiao[1]='null';brotherName[1]='null';brotherCenterPointX[1]='0.0';brotherCenterPointY[1]='0.0';brotherZuobiao[2]='117.26737,36.41661,117.29521,36.37853,117.28337,36.35362,117.26396,36.34459,117.24052,36.34496,117.22111,36.36083,117.20939,36.39342,117.21244,36.4232,117.21256,36.42406,117.24064,36.42601,117.26737,36.41661';brotherName[2]='历下区趵突泉派出所山东大学西校区东村警务责任区';brotherCenterPointX[2]='117.24673';brotherCenterPointY[2]='36.389317';brotherZuobiao[3]='null';brotherName[3]='null';brotherCenterPointX[3]='0.0';brotherCenterPointY[3]='0.0';brotherZuobiao[4]='null';brotherName[4]='null';brotherCenterPointX[4]='0.0';brotherCenterPointY[4]='0.0';brotherZuobiao[5]='null';brotherName[5]='null';brotherCenterPointX[5]='0.0';brotherCenterPointY[5]='0.0';brotherZuobiao[6]='null';brotherName[6]='null';brotherCenterPointX[6]='0.0';brotherCenterPointY[6]='0.0';brotherZuobiao[7]='null';brotherName[7]='null';brotherCenterPointX[7]='0.0';brotherCenterPointY[7]='0.0';
	// alert("brotherCenterPointX:"+brotherCenterPointX);
	// alert("P"+Pzuobiao);
	//alert("b"+brotherZuobiao);
	window.onload = function() {

		onLoad();
		if ("null" != Pzuobiao & "" != Pzuobiao) {
			var pPolygon = addLine(Pzuobiao);
			//var mbr= pPolygon.getMBR();
			//alert(pCenterPointX);
			//alert(pCenterPointY);
			var centerZuobiao = new Point(pCenterPointX * 1, pCenterPointY * 1);
			var tit = new Title(Pname, 13, 0, "宋体", "black", "white",
					"#46a3ff", "1");
			tit.setPoint(centerZuobiao);
			//_MapApp.centerAtMBR(mbr);
			_MapApp.addOverlay(tit);
		}
		// alert(brotherZuobiao.length);
		if (brotherZuobiao.length != 0) {
			for (var i = 0; i <= brotherZuobiao.length; i++) {
				if ("null" != brotherZuobiao[i] & "" != brotherZuobiao[i]
						& undefined != brotherZuobiao[i]) {
					var pPolygon = addLygon(brotherZuobiao[i], _bgColor[i]);
					var centerZuobiao = new Point(brotherCenterPointX[i],
							brotherCenterPointY[i]);
					var tit = new Title(brotherName[i], 13, 0, "宋体", "black",
							"white", "#46a3ff", "1");
					tit.setPoint(centerZuobiao);
					_MapApp.addOverlay(tit);
				}
			}
		}
		if (zuobiao.length != 0) {
			for(var i = 0;i<zuobiao.length;i++){
				 pPolygon2 = new Polygon(zuobiao[i], "#ae0000", 4, 0.3, "#46a3ff");
				_MapApp.addOverlay(pPolygon2);
				pPolygon2.enableEdit(); //将划线改成可修改的方法
				var mbr1 = pPolygon2.getMBR();
				_MapApp.centerAtMBR(mbr1);//根据myZuobiao居中
				var centerZuobiao = new Point(myCenterPointX[i] * 1,
						myCenterPointY[i] * 1);
				var tit = new Title(myName, 13, 0, "宋体", "black", "white",
						"#46a3ff", "1");
				tit.setPoint(centerZuobiao);
				_MapApp.addOverlay(tit);
			}
			
			// alert("centerZuobiao::::"+centerZuobiao);
		}

		// _MapApp.changeDragMode('drawPolyline',dataInputx,dataInputy,callback);                                

	}
	function drawBianjie() {
		_MapApp.changeDragMode('drawPolygon', dataInputx, dataInputy, function(
				points) {
			var sss = points;
			if(null !=strPoints && ""!=strPoints){
				strPoints =strPoints+ ";"+sss;
			}else{
				strPoints = sss;
			}
			isDraw = true;
		});

	}
	function addLine(zuobiao) {
		//alert("zuobiao="+zuobiao);
		var pPolygon = new Polyline(zuobiao, "#ae0000", 4, 0.7, "#46a3ff");
		_MapApp.addOverlay(pPolygon);
		return pPolygon;

	}
	function addLygon(zuobiao, color) {
		//alert("zuobiao="+zuobiao);
		var pPolygon = new Polygon(zuobiao, "#ae0000", 4, 0.3, color);
		_MapApp.addOverlay(pPolygon);
		return pPolygon;

	}
	function closed() {
		window.close();
	}
	function save() {
		if (isDraw == false) {
			strPoints = pPolygon2.getPoints();
			
		}
		if ("" == strPoints) {

			alert("你还没有划分区域！！");

			return;
		}
		$.ajax({
			url : "../entJwq/save.do",
			data : "jwqid=" + organ_id + "&bjzbz=" + strPoints,
			dataType : "json",
			type : "post",
			success : function(data) {
				alert("成功");
				closed();
			},
			error : function() {
				alert("失败");
			}
		})

	}
</script>
<script>
	var xc = 0;
	var yc = 0;
	if (window.screen) {
		var ah = screen.availHeight - 30;
		var aw = screen.availWidth - 10;
		xc = (aw - 810) / 2;
		yc = (ah - 582) / 2;
		if (xc < 0)
			xc = -7;
		if (yc < 0)
			yc = -5;
	}
	window.resizeTo(screen.availWidth, screen.availHeight)
	window.moveTo(0, 0);
</script>

</html>

