
<HTML xmlns="http://www.w3.org/1999/xhtml" xmlns:v =
"urn:schemas-microsoft-com:vml">
  <head>
	<meta http-equiv="content-type" content="text/html; charset=GB2312"/>
	<!-- <META HTTP-EQUIV="imagetoolbar" CONTENT="no">-->
	<title class="title">栅格地图图片引擎服务系统--示例</title>
<SCRIPT language="javascript" src="js/EzMapAPI.js"></SCRIPT>

<script reload="true" id="www" type="text/javascript">

_MapApp=null;
g_overlay=null;
g_edit=false;
function onLoad() {
	if(typeof EzMap =="undefined"){
		window.setTimeout("onLoad()",10);
		return;
	}

  	if(_compatIE()){
	  	/*rg = new Bs_ResizeGrip("map");
			rg.gripIcon = 'images/components/windows/resizeWindow.gif'; 
			rg.draw();
			*/
		//EzMap.registerProx("/ezprox/servlet/com.map.service.XmlHttpProxy");
		_MapApp = new EzMap(document.getElementById("map"));
		
		//_MapApp.centerAndZoom(new Point(118.39459,35.09203), 1);
		var pOverview=new OverView();
		//pOverview.width=200;
		//pOverview.height=200;
		pOverview.minLevel=8;
		pOverview.maxLevel=10;
		_MapApp.addOverView(pOverview);

		//_MapApp.zoomTo("2");
		_MapApp.showMapControl();
		//_MapApp.showSmallMapControl();
		_MapApp.showMapServer();
		//_MapApp.map.enableMouseScroll();
		//_MapApp.editOverlay();
		//gotoCoord();
	}else if(_MapApp==null){
		var pEle=document.getElementById("map");
		//pEle.innerHTML="<p>目前EzMap地图引擎不支持你使用的浏览器，我们当前支持如下浏览器类型:</p><ul><li><a href='http://www.microsoft.com/windows/ie/downloads/default.asp'>IE</a> 5.5+ (Windows)</li>";
	}
		   
	
}

function getRandPoints(){
      var bounds = getMapApp().getBoundsLatLng();
      var width = bounds.maxX - bounds.minX;
      var height = bounds.maxY - bounds.minY;
      points=new Array();
      for (var i = 0; i < 5; i++) {
        points.push(new Point(bounds.minX + width * Math.random(),
                              bounds.minY + height * Math.random()));
      }
      points.sort(function(p1, p2) { return p1.x - p2.x; });
      return points; 
}
function getRandPolygon(){
	var pPoints=getRandPoints();
	var pPoint=pPoints.shift();
	pPoints.push(pPoint);
	pPoints.unshift(pPoint);
	

	
	return pPoints;
}

function gotoCoord(){
		if(_MapSpanScale==1){
			_MapApp.centerAtMBR(new MBR(116.12401,39.72557,116.62987,40.13377));
		}else{
			_MapApp.centerAndZoom(new Point(503558,303451), 5);
		}
}
function showBorder() {
	var pPoints=getRandPolygon();
	var strPoints=pPoints.join(",");
	_MapApp.centerAndZoomToBorder(strPoints);
}
function showInfo() {
	var strHTML="wwwww<SELECT  name=orgName> <OPTION selected>--请选择--</OPTION> <OPTION>分局领导</OPTION> <OPTION>指挥中心</OPTION> <OPTION>北京站派出所</OPTION> <OPTION>警卫处</OPTION> <OPTION>人口处</OPTION> <OPTION>信通处</OPTION></SELECT>";
  	_MapApp.openInfoWindow(_MapApp.getCenterLatLng(),strHTML);
	//var pEle=document.createElement("select");
	//_MapApp.openInfoWindow(_MapApp.getCenterLatLng(),pEle);

  
}
var iIndex=0;

function initStatus(){
    var pEle=document.getElementById("overlayPlay"); 
    pEle.value="运动效果";
    var pEle=document.getElementById("overlayEdit"); 
    pEle.value="可以编辑";
}
function overlayPlay(pEle){
    if(pEle.value=="运动效果"){
        if(g_overlay !=null){
            g_overlay.play();
            g_overlay.disableEdit();
            
        }
        pEle.value="停止";
        
    }else{
        if(g_overlay !=null)g_overlay.stop();
        pEle.value="运动效果"
    }
}
function overlayEdit(pEle){
    if(pEle.value=="可以编辑"){
        if(g_overlay !=null)
        {
            g_overlay.stop();
            g_overlay.enableEdit();
            
        }
        
        pEle.value="不可编辑";
    }else{
        if(g_overlay !=null)g_overlay.disableEdit();
        pEle.value="可以编辑";
    }
    
}

//marker=null;
function addIcon(iPos) {
	//var pOld =new Date();
	//for(var iIndex=0;iIndex<1000;iIndex++){
	  var pIcon=new Icon();
	  pIcon.image="images/gpsstatus/vehicle_motor_active.gif";
	  //pIcon.image="http://127.0.0.1:8888/testEzServer/EzMap?Service=getImage&Type=RGB&Col=300&Row=1&Zoom=14&V=0.3";
	  //pIcon.image="http://127.0.0.1:8888/legendServer/xuany_trans.gif";
	  pIcon.height=32;//getMap().viewSize.height;
	  pIcon.width=32;//getMap().viewSize.width;
	  pIcon.topOffset=0;
	  pIcon.leftOffset=0;
	  var strMsg="msg"+iIndex;
	  iIndex++;
	  if(typeof iPos =="undefined" || iPos==null)iPos=7;
	  
	  //strMsg="你好呜呜呜呜呜<SELECT  name=orgName> <OPTION selected>--请选择--</OPTION> <OPTION>分局领导</OPTION> <OPTION>指挥中心</OPTION> <OPTION>北京站派出所</OPTION> <OPTION>警卫处</OPTION> <OPTION>人口处</OPTION> <OPTION>信通处</OPTION> <OPTION>刑侦支队</OPTION> <OPTION>巡警支队</OPTION></SELECT>啊";
  	  var marker = new Marker(_MapApp.getCenterLatLng(),pIcon,new Title("京A001"+iIndex,12,iPos,"宋体",null,null,"red","2"));
	  _MapApp.addOverlay(marker,false);
	  //marker.div.style.filter="Chroma(Color='#000000')";
	  //增加动画
	  var strPath=getRandPoints().join(",");
	  marker.setPath(0,100,strPath);
	  marker.setExtendStatus(5,100,4,10);
	  marker.addDispStatus('1','50','1');
	  marker.addDispStatus('51','100','1');
	  marker.addDispStatus('101','200','3');
	  g_overlay=marker;
	  
	  marker.enableEdit();

	return marker;
}

function addText(iPos){
			if(typeof iPos =="undefined" || iPos==null)iPos=7;
  	  var pTitle = new Title("火灾蔓延",14,iPos,"宋体",null,null,"red",1);
  	  pTitle.setPoint(_MapApp.getCenterLatLng());
  	  var strMsg="<table><tr><td>名字</td><td>公安部一所</td></tr><tr><td>详细地址</td><td>白石桥</td></tr></table>";
  	  //pTitle.addListener("mouseover",function(){pTitle.openInfoWindowHtml(strMsg);});
  	  //pTitle.addListener("mouseout",function(){iOverLay.closeInfo();});
	  _MapApp.addOverlay(pTitle);
	  g_overlay=pTitle;

}
function clearIcon() {
  	  
	  _MapApp.clear();
}
function addMonitor(){
	var pMonitor=new Monitor("","京A25364"+iIndex,_MapApp.getCenterLatLng().x,_MapApp.getCenterLatLng().y,null);
	iIndex++;
	_MapApp.addOverlay(pMonitor);
	pMonitor.addListener("click",function(){pMonitor.openInfoWindowHtml();});

}
//var pVideo=null;
function addVideo(iStat){
	var pVideo=new Video("","北京火车站001",_MapApp.getCenterLatLng().x,_MapApp.getCenterLatLng().y,null);
	if(typeof iStat =="undefined" || isNaN(iStat) ){
		iStat=0;
	}
	pVideo.videoStatus=iStat;
	pVideo.belongorg="东城分局";
	_MapApp.addOverlay(pVideo);
	pVideo.addListener("click",function(){pVideo.openInfoWindowHtml();});
	//pVideo.scaleImg(1);
	//pVideo.hideTitle();
	//pVideo.scaleImg(1);
	
}

function addPolylin(){
	var strPoint=getRandPoints().join(",");
	//var strPoint="116.47363,39.69628,116.87597,39.46386";
	var pLine=new Polyline(strPoint,"#ff0000", 5,0.7,1);
	//pLine.setBgColor("blue");
	pLine.setColor("blue");
	pLine.setDashStyle("dash");	
	var strMsg="长度:"+pLine.getLength()+",面积:"+pLine.getArea();
	pLine.addListener("click",function(){pLine.openInfoWindowHtml(strMsg);});

	_MapApp.addOverlay(pLine);
	if(g_edit)	pLine.enableEdit();
	g_overlay=pLine;
	
    //pLine.doRotate();

/*
	var strMsg="长度:"+pLine.getLength()+",面积:"+pLine.getArea();
	pLine.addListener("click",function(){pLine.openInfoWindowHtml(strMsg);});

*/
	  pLine.setPath(1,120);
	  pLine.addDispStatus(2,10,1);
	  pLine.addDispStatus(11,20,2);
	  pLine.addDispStatus(21,100,3);
	  
	  pLine.setExtendStatus(1,100,0.1,10);
		
	  pLine.setInterval(500);
	  pLine.setRepeat(true);
	  
	  //pLine.play();
	/*  pLine.startMove(
	  function(e){
	  	alert("移动后坐标:"+_CurentOverLay.toString());
	  	;});
	
		pLine.flash();*/
}
function addPolygon(){
	var pPoints=getRandPolygon();
	var strPoints=pPoints.join(",");
	var pPolygon=new Polygon(strPoints,"#ff00FF", 3,0.5,"blue");
	
	
	iIndex++;
	//pPolygon.addListener("click",function(){pPolygon.openInfoWindowHtml(strMsg);});
	//alert(pPolygon.name);
	//pPolygon.show();
	_MapApp.addOverlay(pPolygon);
	var strMsg="长度:"+pPolygon.getLength()+",面积:"+pPolygon.getArea();
	pPolygon.addListener("click",function(){pPolygon.openInfoWindowHtml(strMsg);});
	pPolygon.flash();
	  pPolygon.setExtendStatus(1,100,1,2);
 	  pPolygon.setInterval(500);
	  pPolygon.setRepeat(true);
	  
	  //pPolygon.play();
	if(g_edit)	pPolygon.enableEdit();
	   g_overlay=pPolygon;		

}
function addCircle(){
	//var pOld =new Date();
	//for(var iIndex=0;iIndex<1000;iIndex++){
		 var pPoint=_MapApp.getCenterLatLng().toString();
	     var bounds = _MapApp.getBoundsLatLng();
	     var width = bounds.maxX - bounds.minX;
	     var height = bounds.maxY - bounds.minY;
		 var strRadius=Math.min(width,height)/3;
		 var pPoints=pPoint+","+strRadius;

		//var pPoints="116.38481,39.95996,0.03";
		var pCircle=new Circle(pPoints,"#ff00FF", 2,0.5,"green");
		_MapApp.addOverlay(pCircle);

	if(g_edit)	pCircle.enableEdit();
	g_overlay=pCircle;

	  pCircle.setExtendStatus(1,100,0.2,2);
 	  pCircle.setInterval(500);
	  pCircle.setRepeat(true);
	  
	  //pCircle.play();
      //pCircle.doRotate();
}
function addRectangle(){
   var bounds = _MapApp.getBoundsLatLng();
	 bounds.scale(0.5);
	 pPoints=bounds.toString();
	//var pPoints="116.38481,39.95996,116.39481,39.98996";
	var pRectangle=new Rectangle(pPoints,"red", 2,0.5,"green");

	var strMsg="长度:"+pRectangle.getLength()+",面积:"+pRectangle.getArea();
	iIndex++;
	_MapApp.addOverlay(pRectangle);
	pRectangle.addListener("click",function(){pRectangle.openInfoWindowHtml(strMsg);});
	
	if(g_edit)	pRectangle.enableEdit();
	g_overlay=pRectangle;
	
	
		//pRectangle.setPath(1,120,"116.38481,39.95996,116.40288,39.95898,116.40483,39.9707,116.42192,39.95898");
		pRectangle.addDispStatus(1,10,3);
	  pRectangle.addDispStatus(11,20,2);
	  pRectangle.addDispStatus(21,100,1);
		pRectangle.setExtendStatus(1,100,0.1,10);
}
function addMutiFeat(){
	
	var pPoints=getRandPolygon();
	var strPoints=pPoints.join(",");

	pPoints=getRandPolygon();
	var strPoints2=pPoints.join(",");	
	
	strPoints+=";"+strPoints2
	
	var pMultiFeat=new MultiFeat(strPoints,"#ff00FF", 3,0.5,"blue");
	

	_MapApp.addOverlay(pMultiFeat);
	
	pMultiFeat.enableEdit();
	
	}

var _subFields="MC:名称";
var _table="GIS370000000000.DW_GAJG_PT";
var _layerName="测试1";
var _dispField="MC";
var _where="";
//var _where="DM='130302000000'";

var _subFields_2="MC:名称";
var _table_2="GIS370000000000.DW_GAJG_PT";
var _layerName_2="测试2";
var _dispField_2="MC";
var _where_2="";

var _imgURL="images/tack.gif";
var _imgURL_2="images/tack1.gif";

function getfuzyQuery(){
	var pQuery=new QueryObject();
	pQuery.queryType=6;
	pQuery.tableName=_table;
	pQuery.where=_dispField+" like '%北%' or "+_dispField +" like '%京%'"
	pQuery.dispField=_dispField;
	pQuery.addSubFields(_subFields);
	pQuery.imgURL=_imgURL;
	_MapApp.clearLayers();
	_MapApp.query(pQuery,drawFeatureObject);
}
function getIdentify(){
	var pQuery=new QueryObject();
	pQuery.queryType=1;
	pQuery.tableName=_table;
	pQuery.dispField=_dispField;
	pQuery.coords=_MapApp.getCenterLatLng().toString();
	pQuery.addSubFields(_subFields);
	pQuery.imgURL=_imgURL;
	_MapApp.clearLayers();
	_MapApp.query(pQuery,drawFeatureObject);
}
function getRect(){
	var pQueryArray=new Array();
	var pQuery=new QueryObject();
	pQuery.queryType=2;
	pQuery.tableName=_table;
	pQuery.layerName=_layerName;
	pQuery.dispField=_dispField;
	pQuery.coords=_MapApp.getBoundsLatLng().toString();
	pQuery.addSubFields(_subFields);
	pQuery.imgURL=_imgURL;
	pQuery.where=_where;
	
	var pQuery2=new QueryObject();
	pQuery2.queryType=2;
	pQuery2.tableName=_table_2;
	pQuery2.layerName=_layerName_2;
	pQuery2.dispField=_dispField_2;
	pQuery2.coords=_MapApp.getBoundsLatLng().toString();
	pQuery2.addSubFields(_subFields_2);
	pQuery2.imgURL=_imgURL_2;
	pQuery2.where=_where_2;
	
	_MapApp.clearLayers();
	
	pQueryArray.push(pQuery);
	pQueryArray.push(pQuery2);
	
	_MapApp.query(pQueryArray,drawFeatureObject);
}
function getCircle(){
	var pQuery=new QueryObject();
	pQuery.queryType=3;
	pQuery.tableName=_table;
	pQuery.layerName=_layerName;
	pQuery.dispField=_dispField;
	var pPoint=_MapApp.getCenterLatLng();
	var pMBR=_MapApp.getBoundsLatLng();
	var strCoords=pPoint.toString()+","+pMBR.getSpanX()/2;
	pQuery.coords=strCoords;
	pQuery.addSubFields(_subFields);
	pQuery.imgURL=_imgURL;
	pQuery.where=_where;

	_MapApp.clearLayers();
	_MapApp.query(pQuery,drawFeatureObject);
}
function getpolygon(){
	var pQuery=new QueryObject();
	pQuery.queryType=4;
	pQuery.tableName=_table;
	pQuery.layerName=_layerName;
	pQuery.dispField=_dispField;
	var pPoints=getRandPolygon();
	var strPoints=pPoints.join(",");
	pQuery.coords=strPoints;
	//pQuery.coords="119.54626,39.9779,119.56237,39.97863,119.55285,39.96545,119.54431,39.96569,119.54626,39.9779;119.57873,39.9801,119.5863,39.95788,119.6156,39.9635,119.59631,39.98986,119.57873,39.9801";

	pQuery.addSubFields(_subFields);
	pQuery.imgURL=_imgURL;
	_MapApp.clearLayers();
	_MapApp.query(pQuery,drawFeatureObject);
}
function getpointaround(){
	var pQuery=new QueryObject();
	pQuery.queryType=5;
	pQuery.tableName=_table;
	pQuery.layerName=_layerName;
	pQuery.dispField=_dispField;
	var pPoint=_MapApp.getCenterLatLng();
	pQuery.coords=pPoint.toString();
	pQuery.radius="1000";
	pQuery.unit="meter";
	pQuery.coordsType="multipoint";
	pQuery.addSubFields(_subFields);
	pQuery.imgURL=_imgURL;
	pQuery.imgHeight=38;
	pQuery.imgWidth=39;
	pQuery.leftOffset=19;
	pQuery.topOffset=-19;
	_MapApp.clearLayers();
	_MapApp.query(pQuery,drawFeatureObject);
}
function getlinearound(){
	var pQuery=new QueryObject();
	pQuery.queryType=5;
	pQuery.tableName=_table;
	pQuery.layerName=_layerName;
	pQuery.dispField=_dispField;
	var strPoint=getRandPoints().join(",");
	pQuery.coords=strPoint;
	pQuery.coordsType="polyline";
	pQuery.radius="1000";
	pQuery.unit="meter";
	pQuery.addSubFields(_subFields);
	pQuery.imgURL=_imgURL;
	_MapApp.clearLayers();
	_MapApp.query(pQuery,drawFeatureObject);
}
function EditCallBack(bIsOK){
	alert("更新状态:"+bIsOK);

}
var iTime=0;
var strValue="";
function addFeature(){
	var pEdit=new EditObject("add","MULTIPOINT",_table);
	var pDate=new Date();
	iTime=pDate.getTime();
	strValue="测试"+iTime;
	pEdit.addField(_dispField,strValue);
	//pEdit.addField("shape","116.4002,39.9");
	var strShape=getMapApp().getCenterLatLng().toString();
	pEdit.addField("shape",strShape);
	//pEdit.addField("caseconten","2006-04-12 鼎钧大厦5001室");
	_MapApp.edit(pEdit,EditCallBack);
}
function delFeature(){
	var pEdit=new EditObject("del","MULTIPOINT",_table);
	//pEdit.where="mapcaseid='00000001'";
	pEdit.where=_dispField+"='"+strValue+"'";
	_MapApp.edit(pEdit,EditCallBack);

}
function delTestFeature(){
	var pEdit=new EditObject("del","MULTIPOINT",_table);
	pEdit.where=_dispField+" like '*测试*' ";
	alert(pEdit.toxml());
	_MapApp.edit(pEdit,EditCallBack);

}

function updateFeature(){
	var pEdit=new EditObject("update","MULTIPOINT",_table);
	//pEdit.addField("mapcaseid","00000002");
	//pEdit.addField("shape","116.4902,39.9");
	//pEdit.addField("caseconten","2006-04-12 鼎钧大厦5001室");
	var strShape=getMapApp().getCenterLatLng().toString();
	pEdit.addField("shape",strShape);

	pEdit.where=_dispField+"='"+strValue+"'";
	_MapApp.edit(pEdit,EditCallBack);

}

function callback(str){
	//alert("调用回调函数！"+dataInputx.toString()+":"+dataInputy.toString());
	//alert("调用回调函数！"+dataInputx.value);
	alert("调用回调函数,获取坐标:"+str);
	//getMapApp().pan();
}

function ArcImgFunc(){
    this.imgUrl="";
	this.QueryBuffer=null;
	this.marker=null;
	this.blurQueryObj=new Array();//定义查询对象缓存
	var pMe=this;
	this.isProcess=false;
	this.listener=false;


};

/**
*this.QueryBuffer 查询对象缓存
*/
ArcImgFunc.prototype.redraw=function(){
	alert("ddd");
};

var _ArcImg=new ArcImgFunc();

function addMapStateChangeFunc(){
	//_MapApp.addMapChangeListener(testMapChange);
	getMapApp().addMapChangeListener(_ArcImg.hander);
}
function delMapStateChangeFunc(){
	getMapApp().removeMapChangeListener(_ArcImg.hander);
	//_MapApp.removeMapChangeListener(testMapChange);
}



function testMapChange(){
	alert("地图状态变化！");
}


function testFunc(){
	var pEle=document.getElementById("function_name");
	if(pEle !=null){
		var strFunc=pEle.value;
		//strFunc="try{\n"+strFunc+"\n}catch(e){alert(e.message)}";
		
		eval(strFunc);
	}
	

}
function testRoute(){
	var pRoute=new RouteObject("ga_china","PointQuery","116.36799976083711","39.231426754032145","PointQuery","116.16799976083711","39.931426754032145");
	//pRoute.search();
	_MapApp.query(pRoute,drawRoutePath);
	
}
function testRoute1(){
	var pRoute=new RouteObject("ga_china","StartName","北京朝阳","北京朝阳","EndName","山西阳泉","山西阳泉");
	//pRoute.search();
	_MapApp.query(pRoute,preccessRouteXML);
}

function testSearch(){
	var pGeoCode=new GeoCodeObject("0","朝阳区");
	//pGeoCode.search();
	_MapApp.query(pGeoCode,drawGeoCode);
}

function redrawL(){
	if(_LegendFunc!=null) _LegendFunc.redraw();
}


function addMark() {
	//var pOld =new Date();
	//for(var iIndex=0;iIndex<1000;iIndex++){
	  var pIcon=new Icon();
	  pIcon.image="images/gpsstatus/vehicle_motor_active.gif";
	  pIcon.height=32;//getMap().viewSize.height;
	  pIcon.width=32;//getMap().viewSize.width;
	  pIcon.topOffset=0;
	  pIcon.leftOffset=0;
	  if(typeof iPos =="undefined" || iPos==null)iPos=7;
	  
  	  var marker = new Marker(_MapApp.getCenterLatLng(),pIcon,new Title("京A001"+iIndex,12,iPos,"宋体",null,null,"red","2"));
	  return marker;
}
gw={
	dbList:[],//所有记录
	mapDbList:{},//所有记录
	mapMapList:[],
	mapList:[]//奥运场馆的所有marker的集合
};
gw.addMark=addMark;
gw.init=function(){
    var pMark=this.addMark();
	this.mapMapList.push(pMark);
}

//在地图上显示所有奥运岗位图标
gw.display=function(){
	var obj=this.mapMapList;
	for(var id=0;id<obj.length;id++){
	   var pMarker=obj[id];
	   if(pMarker !=null){
		getMapApp().addOverlay(pMarker);
	   }
	}
};
//取消显示所有岗位
gw.unDisplay=function(){
	var obj=this.mapMapList;
	for(var id=0;id<obj.length;id++){
	   
	   var pMarker=obj[id];
		getMapApp().removeOverlay(pMarker);
	}
};


_LegendFunc=null;
function showLegend(pEle){
	if(pEle.value=="显示专题图"){
		pEle.value="隐藏专题图";
		_LegendFunc=new LegendFunc();
		 //_LegendFunc.format="http://172.26.15.43/BJMAPV2/servlet/XmlHttpProxy?url=http%3A%2F%2F172.26.15.7%2Fservice%2FGovEMap%2Fwms%3FBBOX%3DEZBOX%26WIDTH%3D787%26HEIGHT%3D258%26SRS%3DEPSG%3ANONE%26layers%3D293%26version%3D1.0.0%26service%3Dwms_service%26FORMAT%3DGIF%26TRANSPARENT%3DTRUE%26request%3Dgetmap%26ServiceName%3Dwms_service%26username%3Dtpengine%26password%3Dtpengine";
		// _LegendFunc.format="http://172.24.120.75:8888/wms_connector/com.esri.wms.Esrimap?BBOX=EZBOX&WIDTH=EZWIDTH&HEIGHT=EZHEIGHT&SRS=EPSG:NONE&layers=13,3,11,16,6,9&version=1.0.0&service=WMS&FORMAT=PNG&TRANSPARENT=TRUE&request=getmap&ServiceName=yj"
		 _LegendFunc.format="http://10.48.1.239:2087/SDGAJG/wms?SERVICE=WMS&VERSION=1.3.0&SERVICE=WMS&REQUEST=GetMap&LAYERS=GIS370000000000.FQ_SDGAJG_PT&BBOX=EZBOX&WIDTH=EZWIDTH&HEIGHT=EZHEIGHT&FORMAT=image/png&TRANSPARENT=TRUE&BGCOLOR=0x000000&CRS=epsg:4267"
		_LegendFunc.open();

	}else{
		pEle.value="显示专题图";
		_LegendFunc.close();
		_LegendFunc=null;
	}
}
function addLine(pPoints){
	var pLine=new Polyline(pPoints.toString(),"#ff0000", 5,0.7,1);
	pLine.setColor("blue");
	pLine.setDashStyle("dash");	
	var strMsg="长度:"+pLine.getLength()+",面积:"+pLine.getArea();
	pLine.addListener("click",function(){pLine.openInfoWindowHtml(strMsg);});

	_MapApp.addOverlay(pLine);
}
</script>  


  </head>
  


  <body >
  <OBJECT id="min" type="application/x-oleobject" classid="clsid:adb880a6-d8ff-11cf-9377-00aa003b7a11">
	<PARAM name="Command" value="Minimize">
  </OBJECT>
  <OBJECT id="max" type="application/x-oleobject" classid="clsid:adb880a6-d8ff-11cf-9377-00aa003b7a11">
	<PARAM name="Command" value="Maximize">
  </OBJECT>

  <!--
<div id="map" style="border-style:solid; border-width:1px; top:100px;right:20px;width:300px;height:300px; position:absolute; padding-left:4px; padding-right:4px; padding-top:1px; padding-bottom:1px"></div>
-->
  	<table style="width:100%;height:100%">
  	<tr >
  <td style="width:*;height:600px;border: 2px solid #FF0000" >
	<div id="map" style="width:100%; height:100%;border: 0px solid #FF0000;" ></div>

	</td>
		
	<td style="width:250px" valign="top">


	<table>

		<tr>
		<td style="width:100%">
		<fieldset class=fieldstyle>
		<legend>地图操作</legend>
		<table style="width:100%">
		<tr>
			<td ><input type="button" style="width:100%" onclick="_MapApp.zoomIn();" value="放大"></input></td>
			<td ><input type="button" style="width:100%" onclick="_MapApp.zoomOut();" value="缩小"></input></td>
			<td ><input type="button" style="width:100%" onclick="_MapApp.fullExtent();" value="全图"></input></td>
		</tr><tr>
			<td ><input type="button" style="width:100%" onclick="_MapApp.gotoCenter();" value="对中"></input></td>
			<td ><input type="button" style="width:100%" onclick="_MapApp.changeDragMode('measure');//_MapApp.measureLength();" value="测量"></input></td>		
			<td ><input type="button" style="width:100%" onclick="clearIcon();" value="清除"></input></td>
		
		</table>

		</fieldset>
		
		</td>

		</tr>
		<tr>
		<td style="width:100%">
		<fieldset class=fieldstyle>
		<legend>绘制模式</legend>
		<table style="width:100%">
		<tr>
			<td ><input type="button" style="width:100%" onclick="_MapApp.changeDragMode('pan');" value="平移"></input></td>
			<td ><input type="button" style="width:100%" onclick="_MapApp.changeDragMode('drawPoint',dataInputx,dataInputy,callback);" value="获取坐标" title="点击获取坐标"></input></td>
			<td ><input type="button" style="width:100%" onclick="_MapApp.changeDragMode('drawPolyline',dataInputx,dataInputy,callback);" value="画线" title="点击拖动"></input></td>
		</tr>
		<tr>
			<td ><input type="button" style="width:100%" onclick="_MapApp.changeDragMode('drawCircle',dataInputx,dataInputy,callback);" value="画圆形" title="点击拖动"></input></td>
			<td ><input type="button" style="width:100%" onclick="_MapApp.changeDragMode('drawRect',dataInputx,dataInputy,callback);" value="画矩形" title="点击拖动"></input></td>
			<td ><input type="button" style="width:100%" onclick="_MapApp.changeDragMode('drawPolygon',dataInputx,dataInputy,callback);" value="画多边形" title="点击"></input></td>
		
		</tr>
		<tr>
			<td ><input type="button" style="width:100%" onclick="_MapApp.zoomInExt();" value="拉筐放大" title="拉筐放大"></input></td>
			<td ><input type="button" style="width:100%" onclick="_MapApp.zoomOutExt()" value="拉筐缩小" title="拉筐缩小"></input></td>
			<td ><input type="button" style="width:100%" onclick="alert(_MapApp.getDragMode());" value="获取当前模式" title="获取当前模式"></input></td>
		
		</tr>

		</table>

		</fieldset>
		
		</td>
		

		</tr>

		<tr>
		<td style="width:100%">
		<fieldset class=fieldstyle>
		<legend>叠加信息操作</legend>
		<table style="width:100%">
		<tr>
		<td width="10%"><input type="button" style="width:100%" onclick="addIcon();" value="加入图标"></input></td>
		<td width="10%"><input type="button" style="width:100%" onclick="addPolylin();" value="加入线"></input></td>
		<td width="10%"><input type="button" style="width:100%" onclick="addPolygon();" value="加入面"></input></td>

		</tr><tr>

		<td width="10%"><input type="button" style="width:100%" onclick="addRectangle();" value="加矩形"></input></td>
		<td width="10%"><input type="button" style="width:100%" onclick="addCircle();" value="加入圆"></input></td>
		<td width="10%"><input type="button" style="width:100%" onclick="addText();" value="加入文本"></input></td>
		</tr>
        
		
        <tr>
    <td width="10%"><input type="button" style="width:100%" onclick="addMutiFeat();" value="复杂对象"></input></td>
		<td width="10%"><input type="button" style="width:100%" onclick="addMonitor();" value="加入警力"></input></td>
		<td width="10%"><input type="button" style="width:100%" onclick="showBorder();" value="显示边界"></input></td>		
		
		</tr>
		</table>

		</fieldset>
		
		</td>

		
		</tr>

		<tr>
		<td style="width:100%">
		<fieldset class=fieldstyle>
		<legend>其他控件操作</legend>
		<table style="width:100%">
		<tr>
			<td ><input type="button" style="width:100%" onclick="_MapApp.showOverView();" value="显示鹰眼" title="显示鹰眼"></input></td>
			<td ><input type="button" style="width:100%" onclick="_MapApp.hideOverView();" value="隐藏鹰眼" title="隐藏鹰眼"></input></td>
		</tr><tr>
			<td ><input type="button" style="width:100%" onclick="_MapApp.showMapControl();" value="显示控件" title="点击"></input></td>
			<td ><input type="button" style="width:100%" onclick="_MapApp.hideMapControl();" value="隐藏控件" title="点击"></input></td>
		
		</tr>
		</table>

		</fieldset>
		
		</td>


		</tr>

		<tr>
		<td style="width:100%">
		<fieldset class=fieldstyle>
		<legend>坐标信息</legend>
		<table style="width:100%">
		<tr>
		<td>
		<input type="text"  style="width:100%" id="dataInputx" value=""></input>
		</td>		
		</tr><tr>

		<td>
		<input type="text"  style="width:100%" id="dataInputy" value=""></input>
		</td>
		
		</tr>
		</table>

		</fieldset>
		
		</td>

		</tr>

		<tr>
		<td style="width:100%">
		<fieldset class=fieldstyle>
		<legend>查询操作</legend>
		<table style="width:100%">
		<tr>
		<td ><input type="button"   style="width:100%" onclick="getIdentify();" value="点查询"></input></td>
		<td ><input type="button"   style="width:100%" onclick="getRect();" value="拉筐查询"></input></td>		
		<td ><input type="button"   style="width:100%" onclick="getCircle();" value="圆形查询"></input></td>
	
		</tr><tr>
	
		<td ><input type="button"   style="width:100%" onclick="getpolygon();" value="多边形查询"></input></td>
		<td ><input type="button"   style="width:100%" onclick="getpointaround();" value="点周边查询"></input></td>
		<td ><input type="button"   style="width:100%" onclick="getlinearound();" value="线周边查询"></input></td>
		
		</tr><tr>
	
		<td ><input type="button"   style="width:100%" onclick="addFeature();" value="信息增加"></input></td>
		<td ><input type="button"   style="width:100%" onclick="delFeature();" value="信息删除"></input></td>
		<td ><input type="button"   style="width:100%" onclick="updateFeature();" value="信息修改"></input></td>
		
		</tr>

		<tr>
		<td ><input type="button"   style="width:100%" onclick="testRoute();" value="路径分析"></input></td>
		<td ><input type="button"   style="width:100%" onclick="testSearch();" value="地址编码"></input></td>
		<td ><input type="button"   style="width:100%" onclick="showLegend(this);" value="显示专题图"></input></td>
		</tr>

		</table>

		</fieldset>
		
		</td>

		</tr>
		<tr>
		<td style="width:100%">
		<fieldset class=fieldstyle>
		<legend>其他</legend>
		<table style="width:100%">
		<tr>
		<td ><input type="button"   style="width:100%" onclick="addMapStateChangeFunc();" value="加入事件"></input></td>
		<td ><input type="button"   style="width:100%" onclick="delMapStateChangeFunc();" value="删除事件"></input></td>		
		<td ><input type="button"   style="width:100%" onclick="testFunc();" value="测试函数"></input></td>
		</tr>
			
		<tr>
		<td colspan=3><textarea name="function_name" name="function_name" rows=4 cols=30 ></textarea></td>		
	
		</tr>
		</table>

		</fieldset>
		
		</td>

		</tr>
	</table>

	</td>
	</tr>
	<table>

  </body>
  
  <script>
  	window.onload=function(){
  			onLoad();

  	}

  	
  </script>
  
</html>
