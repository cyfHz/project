function getData(){
	var posArray=new Array();
	$("#container div.tdx").each(function(index,element){
		var left=$(this).position().left;
		 var top = $(this).position().top;
		  var width =$(this).width();
		  var height = $(this).height();
		 var posibj= new PositionObj(left,top,width,height);
		 posArray.push(posibj);
	 });
	return posArray;
}