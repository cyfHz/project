function addLouceng(){
	var lcs=jzwjgdata.lcs;
	 $("#container div.tdx").each(function(index,element){
		 
	 }
}
function addDanyuan(){
	
}