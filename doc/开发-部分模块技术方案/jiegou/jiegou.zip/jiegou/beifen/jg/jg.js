//
function addLouceng(lcs){
	for(var i=0;i<lcs;i++){
		var name=(lcs-(i))+"F";
		var left=-35;
		var top=100*i;
		var hei=100;
		var wit=30;
		var bordera="bordera";
		$("#container").append("<div id=\""+name+"\" class=\""+bordera+"\" style=\"left: "+left+"px;top:"+top+"px;width: "+wit+"px; height:"+hei+"px; \">"+name+"</div>");
	}
}
function addDanyuan(dys,mdyms){
	for(var i=0;i<dys;i++){
		var name=(i+1)+"单元";
		var left=(100*mdyms)*i;
		var top=-30;
		var hei=25;
		var wit=100*mdyms;
		var bordera="bordera";
		$("#container").append("<div id=\""+name+"\" class=\""+bordera+"\" style=\"left: "+left+"px;top:"+top+"px;width: "+wit+"px; height:"+hei+"px; \">"+name+"</div>");
	}
}
//---------------------------------------------------------------------------------
function PositionObj(left, top, width, height) {
	this.left = left; //
	this.top = top;//
	this.width = width;//
	this.height = height;//
	return this;
}

var globleWidth=100;

var golbleHeight=100;

$(function (){
	 // init();
  });

function init(){
	$("#container div").each(function(index,element){
		$(this).unbind("click", function(){});
	});
	  $("#container div").click(function(){
		  if($(this).hasClass("tdx")){
			  removeSelectedCss($(this));
		  }else{
			  addSelectedCss($(this));
		  }
	  });
}


function showA(){
	var cssA=new Array();
	cssA.push("bordera");
	cssA.push("borderb");
	var clz="";
	var index=0;
	var lcs=$("#lcs").val();
	var dys=$("#dys").val();
	var fjs=$("#fjs").val();
	var index=0;
	for(var d=0;d<dys;d++){
		for(var c=0;c<lcs;c++){
			for(var f=0;f<fjs;f++){
				var wit=100;
				var hei=100;
				var left=((fjs*d)+f)*wit;
				var top=(lcs-(c+1))*hei;
				var name=(c+1)+"-"+(d+1)+"-"+(c+1)+"0"+(f+1);
				if(c%2==0){//偶数行
					if(((fjs*d)+f)%2==0){//偶数列
						clz=cssA[0];
					}else{//奇数 列
						clz=cssA[1];
					}
				}else{//奇数行
					if(((fjs*d)+f)%2==0){//偶数列
						clz=cssA[1];
					}else{//奇数 列
						clz=cssA[0];
					}
				}
				$("#container").append("<div id=\""+name+"\" class=\""+clz+"\" style=\"left: "+left+"px;top:"+top+"px;width: "+wit+"px; height:"+hei+"px; \">"+name+"</div>");
			}
		}
	}
	
	 init();
}


function hebingx(){
	var check=checkHeBing();
	if(!check){
		return;
	}
	var PositionObj=getAfterHeBingDivInfo();
	 var top=getHeBingTop();
	 var left=getHeBingLeft();
	 var wit=getHeBingW();
	 var hei=getHeBingH();
	 
	var targetIdArray=new Array();
	 $("#container div").each(function(index,element){
		  if($(this).hasClass("tdx")){
			  var id=$(this).attr("id");
			  targetIdArray.push(id);
			 // $(this).attr({id:"lili"});
		  }
	  });
	 var showinfo=""+top+","+left+","+wit+","+hei+"";
		
	 var url="heBing";
	 
	 var jzwfjView={"oldJzwfjIds":targetIdArray,"jzwfjInfoList":[{"key":basekeyPrefix,"fjxh":"","fjmc":"","showInfo":showinfo}]};
	 KMAJAX.ajaxTodoJson(url,  JSON.stringify(jzwfjView), function(data){
		 if(data.statusCode!=200){
			 alertMsg.error(data.message);
			 return;
		 }else{
			 alertMsg.info(data.message);
			 return ;
		 }
	 });
	 /**/
	 

//	 alert("top="+top+" left="+left+" wit="+wit+" h="+hei);
	 var divv=$("<div id=\"2-1-x\" class=\"bordera\" style=\"left: "+left+"px;top:"+top+"px;width: "+wit+"px; height:"+hei+"px; \">2-x1</div>");
	 $("#container").append(divv);
	 divv.click(function(){
		  if($(this).hasClass("tdx")){
			  removeSelectedCss($(this));
		  }else{
			  addSelectedCss($(this));
		  }
	  });
	  $("#container div.tdx").each(function(index,element){
		 if($(this).attr("id")=="lili"){
			 $(this).remove();
		 }
	  });  
}




function isHorizontal(){
	posArray=getData();
	for(var i=0;i<posArray.length-1;i++){
		if(posArray[i].top!=posArray[i+1].top){
			return false;
		}
	}
	return true;
}
function isVertical(){
	posArray=getData();
	for(var i=0;i<posArray.length-1;i++){
		if(posArray[i].left!=posArray[i+1].left){
			return false;
		}
	}
	return true;
}
function getData(){
	var posArray=new Array();
	$("#container div.tdx").each(function(index,element){
		var left=$(this).position().left;
		 var top = $(this).position().top;
		  var width =$(this).width();
		  var height = $(this).height();
		 var posibj= new PositionObj(left,top,width,height);
		 posArray.push(posibj);
	 });
	return posArray;
}
function checkHeBing(){
	var posArray=new Array();
	posArray=getData();
	if(!posArray||posArray.length<2){
		 alert("请至少选择两个房屋进行合并");
			return false;
	}
	//var divs=$("#container div.tdx");
	if(isVertical()){
		//竖直方向
		for(var i=0;i<posArray.length-1;i++){
			if(posArray[i].left!=posArray[i+1].left){
				alert("检测到位置不正确");
				return false;
			}
			if(posArray[i].width!=posArray[i+1].width){
				alert("检测到房间跨越宽度不同，不可合并");
				return false;
			}
			posArray.sort(function(p1, p2) { return p1.top - p2.top; });
			if(posArray[i].top+posArray[i].height!=posArray[i+1].top){
				alert("检测到房间位置不连续，不可合并");
				return false;
			}
		}
		return true;
	}else if(isHorizontal()){
		//水平
		for(var i=0;i<posArray.length-1;i++){
			if(posArray[i].top!=posArray[i+1].top){
				alert("检测到位置不正确");
				return false;
			}
			if(posArray[i].height!=posArray[i+1].height){
				alert("检测到房间跨越宽度不同，不可合并");
				return false;
			}
			posArray.sort(function(p1, p2) { return p1.left - p2.left; })
			if(posArray[i].left+posArray[i].width!=posArray[i+1].left){
				alert("检测到房间位置不连续，不可合并");
				return false;
			}
		}
		return true;
	}else{
		alert("方向不正确"); return false;
	}
	return true;
	
}

//---------------------------------------------------------------------------------------------------------------------
function checkChaiFen(){
	var inxx=0;
	$("#container div.tdx").each(function(index,element){
		inxx++;
	});
	if(inxx>1){
		alert("拆分房间数超过一个"); 
		return false;
	}
	return true;
	/*	 var dir=$("#dir").val();
	 var count=$("#count").val();
	 $("#container div.tdx").each(function(index,element){
		    var Tleft =$(this).position().left;
		    var Ttop = $(this).position().top;
		    var Twidth =$(this).width();
		    var Theight = $(this).height();
		    if(dir==0){//
				var ecery=Twidth/count;
				if(ecery<10){
					alert("拆分个数太多");
				}
			 }else{
				 var ecery=Theight/count;
					if(ecery<10){
						alert("拆分个数太多");
					}
			 }
		});*/
	
}
function chaifenk(){
	var check=checkChaiFen();
	if(!check){
		return;
	}
	 $("#container div.tdx").each(function(index,element){
			  $(this).attr({id:"lili"});
			//  $(this).remove();
	  });
	 var dir=$("#dir").val();
	 var count=$("#count").val();
	    var Tleft = $("#lili").position().left;
	    var Ttop = $("#lili").position().top;
	    var Twidth =$("#lili").width();
	    var Theight = $("#lili").height();
	    var posArray=new Array();
	 if(dir==0){//
		 posArray=caculateW(Tleft,Ttop,Twidth,Theight,count);
	 }else{
		  posArray=caculateH(Tleft,Ttop,Twidth,Theight,count);
	 }
	 for(var i=0;i<posArray.length;i++){
		  var sd=posArray[i];
		   var left = sd.left; //
		   var top = sd.top;//
		   var width = sd.width;//
		   var height = sd.height;//
		   //var cal=(i%2==0)?"bordera":"borderb";
		   var divv=$("<div id=\"2-1-zx\" class=\"bordera\" style=\"left: "+left+"px;top:"+top+"px;width: "+width+"px; height:"+height+"px; \">2-x1</div>");
		   $("#container").append(divv);
		   divv.click(function(){
				  if($(this).hasClass("tdx")){
					  removeSelectedCss($(this));
				  }else{
					  addSelectedCss($(this));
				  }
			  });
	 }
	  $("#container div.tdx").each(function(index,element){
		  if($(this).attr("id")=="lili"){
			$(this).remove();
		}
	 });
}
/* 
 * 
 */function caculateW(initLeft,initTop,Mwidth,Mheigth,count){
	var posArray=new Array();
	if(Mwidth%count==0){
		var everyW=Mwidth/count;
		for(var i=0;i<count;i++){
			var posibj= new PositionObj(initLeft+i*everyW,initTop,everyW,Mheigth);
			posArray.push(posibj);
		}
	}else{
		var mod=Mwidth%count;
		var everyWA=(Mwidth-mod)/count;
		var everyWB=everyWA+mod;
		for(var i=0;i<count;i++){
			var positibj= new PositionObj(initLeft+i*everyWA,initTop,(i<count-1)?everyWA:everyWB,Mheigth);
			posArray.push(positibj);
		}
	}
	return posArray;
}
	function caculateH(initLeft,initTop,Mwidth,Mheigth,count){
		var posArray=new Array();
		if(Mheigth%count==0){
			var everyH=Mheigth/count;
			for(var i=0;i<count;i++){
				var posij=new PositionObj(initLeft,initTop+i*everyH,Mwidth,everyH);
				posArray.push(posij);
			}
		}else{
			var mod=Mheigth%count;
			var everyHA=(Mwidth-mod)/count;
			var everyHB=everyHA+mod;
			for(var i=0;i<count;i++){
				var ponObj=new PositionObj(initLeft,initTop+i*everyHA,Mwidth,(i<count-1)?everyHA:everyHB);
				posArray.push(ponObj);
			}
		}
		return posArray;
} 
	
//-------------------------------------------------------------------------------------------------------------------
	
	function getSelectedDivIds(){
		var targetIdArray=new Array();
		 $("#container div").each(function(index,element){
			  if($(this).hasClass("tdx")){
				  var id=$(this).attr("id");
				  targetIdArray.push(id);
			  }
		  });
		 return targetIdArray;
	}
	
	function getAfterHeBingDivInfo(){
		var minLeft=9999999999;
		var minTop=9999999999;
		var width=0;
		var height=0;
		 $("#container div.tdx").each(function(index,element){
			 //left
			 var Y = $(this).position().left; 
			  if(minLeft>Y){
				  minLeft=Y;
			 }
			  //top
			  var X = $(this).position().top; 
			  if(minTop>X){
				  minTop=X;
			 }
			  //width
			 if(isHorizontal()){
				 width+=$(this).width();
			  }else{
				  width=$(this).width();
			  }
			// height
			  if(isVertical()){
				  height+=$(this).height();
			  }else{
				  height=$(this).height();
			  }
		  });
		 var posibj= new PositionObj(minLeft,minTop,width,height);
		return posibj;
	}
//-----------------------------------------------------
	
	function addClickClass(domId){
		$(domId).click(function(){
			  if($(this).hasClass("tdx")){
				  removeSelectedCss($(this));
			  }else{
				  addSelectedCss($(this));
			  }
		  });
	}
	 function addSelectedCss(domId){
		  $("#container div").each(function(index,element){
			  if($(this).attr("id")==domId.attr("id")){
				  $(this).addClass("tdx");
			  }
		  });
	}
	function removeSelectedCss(domId){
		 $("#container div").each(function(index,element){
			  if($(this).attr("id")==domId.attr("id")){
				  $(this).removeClass("tdx");
			  }
		  });
	}
	
	function remveDivByIds(targetIdArray){
		var idArray=new Array();
		idArray=targetIdArray;
		for( var i=0;i<idArray.length;i++){
			 var id=idArray[i];
			 $("#"+id+"").remove();
		 }
	}